"""Verify the five current guarded-next rewrites against the sealed receipt origin."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path.cwd()
OUT = ROOT / 'reports/final-findings/receipt-witness-delta-review.json'
ORIGIN = '1d6b2884c1935d0afe6f92c33584581c33ff20dc'
ARCHIVE = ROOT / 'exchange_executor/certifications/reviews/findings-1d6b288-evidence.tar.gz'
ARCHIVE_HASH = '71fee5907f772e6b63f2686b5b0eb0e3066e59e19f43c5053e5195a0d81f7db1'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda node: ast.dump(node, include_attributes=False)
if sha(ARCHIVE.read_bytes()) != ARCHIVE_HASH:
    raise ValueError('Prior archive changed')
with tarfile.open(ARCHIVE) as archive:
    parity = json.loads(archive.extractfile('review/reports/findings-review/final-v9-receipt-parity-supplement.json').read())

class GuardedNext(ast.NodeTransformer):
    def __init__(self):
        self.changed = []

    def visit_Try(self, node):
        if len(node.body) != 1 or len(node.handlers) != 1 or node.orelse or node.finalbody:
            return self.generic_visit(node)
        handler = node.handlers[0]
        if not isinstance(handler.type, ast.Name) or handler.type.id != 'StopIteration' or handler.name or len(handler.body) != 1:
            return self.generic_visit(node)
        fail = handler.body[0]
        if not isinstance(fail, ast.Expr) or not isinstance(fail.value, ast.Call) or dump(fail.value.func) != dump(ast.parse('self.fail').body[0].value) or len(fail.value.args) != 1 or fail.value.keywords:
            return self.generic_visit(node)
        statement = node.body[0]
        if not isinstance(statement, (ast.Assign, ast.Return)):
            return self.generic_visit(node)
        value = statement.value
        if not isinstance(value, ast.Call) or not isinstance(value.func, ast.Name) or value.func.id != 'next' or len(value.args) != 1 or value.keywords:
            return self.generic_visit(node)
        if isinstance(statement, ast.Assign) and (len(statement.targets) != 1 or not isinstance(statement.targets[0], ast.Name)):
            return self.generic_visit(node)
        name = statement.targets[0].id if isinstance(statement, ast.Assign) else 'page'
        replacement = ast.parse(f'missing = object()\n{name} = next(source, missing)\nself.assertIsNot({name}, missing, "placeholder")' + (f'\nreturn {name}' if isinstance(statement, ast.Return) else '')).body
        replacement[1].value.args[0] = copy.deepcopy(value.args[0])
        replacement[2].value.args[2] = copy.deepcopy(fail.value.args[0])
        self.changed.append({'baselineLine': node.lineno, 'selectedValue': name,
                             'selectionAstSha256': sha(dump(value.args[0]).encode()),
                             'failureMessageAstSha256': sha(dump(fail.value.args[0]).encode()),
                             'behavior': 'A unique local sentinel cannot equal a real selected value. Missing selection raises AssertionError with the same explicit message; successful selection and subsequent assertions are unchanged.'})
        return replacement

paths = {}
for row in parity['rows']:
    for witness in row['witnessBindings']:
        if sha((ROOT / witness['path']).read_bytes()) != witness['sha256']:
            paths[witness['path']] = witness['sha256']
expected = {'exchange_executor/tests/test_execution_constraints.py', 'exchange_executor/tests/test_history_coverage.py',
            'exchange_executor/tests/test_history_pagination.py', 'exchange_executor/tests/test_recovery_schedule.py'}
if set(paths) != expected:
    raise ValueError('Changed witness set needs an additional individual review')
reviews = []
for relative, digest in sorted(paths.items()):
    old = subprocess.check_output(['git', 'show', f'{ORIGIN}:{relative}'])
    current = (ROOT / relative).read_bytes()
    if sha(old) != digest:
        raise ValueError('Sealed witness does not match its Git origin')
    transform = GuardedNext()
    normalized = transform.visit(ast.parse(old))
    if dump(normalized) != dump(ast.parse(current)):
        raise ValueError(f'Additional unreviewed change in {relative}')
    reviews.append({'path': relative, 'previousSha256': digest, 'currentSha256': sha(current), 'reviewed': True,
                    'wholeFileAstEquivalentUnderExplicitGuardedNextRewrite': True,
                    'changes': transform.changed,
                    'rationale': 'Only the listed guarded next() statements change. The iterator/filter expression and exact failure message remain identical. assertIsNot preserves explicit fixture failure without catching StopIteration. All other syntax, assertions, async boundaries and test cases match the prior reviewed source.'})
if sum(len(row['changes']) for row in reviews) != 5:
    raise ValueError('Unexpected guarded-next transformation count')
report = {'schemaVersion': 1, 'baselineRevision': ORIGIN, 'priorArchive': {'path': ARCHIVE.relative_to(ROOT).as_posix(), 'sha256': ARCHIVE_HASH},
          'method': 'Independent source diff review plus whole-file Python AST comparison with exactly the documented guarded-next transform; no normalization of unrelated assertions or async callbacks.',
          'changedWitnessFiles': len(reviews), 'changedGuardedNextSites': 5, 'reviews': reviews,
          'executionStatus': 'Fresh full Python branch-coverage run is still required at frozen source; this is not an execution claim.',
          'providerAcceptanceVerified': False}
raw = (json.dumps(report, indent=2) + '\n').encode()
if OUT.exists() and OUT.read_bytes() != raw:
    raise ValueError('Refusing to overwrite different witness evidence')
if not OUT.exists():
    OUT.write_bytes(raw)
print(json.dumps({'path': OUT.relative_to(ROOT).as_posix(), 'sha256': sha(raw), 'files': 4, 'guardedNextSites': 5}))
