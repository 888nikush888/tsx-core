"""Seal new review evidence deterministically; never change receipt or authority."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

from receipt_renewal_safety_candidate import plain_local, historical_archive_for_queue

ROOT = Path.cwd().resolve()
OUT = ROOT / 'reports/final-findings'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def local(relative):
    return plain_local(ROOT, relative)

def historical(binding):
    a = local(binding['archive']['path'])
    require(sha(a.read_bytes()) == binding['archive']['sha256'], 'Historical archive changed')
    with tarfile.open(a) as archive:
        item = archive.getmember(binding['member'])
        require(item.isfile() and not item.issym() and not item.islnk(), 'Historical reference is not an ordinary member')
        raw = archive.extractfile(item).read()
    require(sha(raw) == binding['sha256'], 'Historical member changed')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tag', required=True)
    args = parser.parse_args()
    require(re.fullmatch('[A-Za-z0-9_-]+', args.tag), 'Invalid evidence tag')
    state_path = OUT / f'{args.tag}-receipt-candidate-state.json'
    review_path = OUT / f'{args.tag}-independent-receipt-review.json'
    approval_path = OUT / f'{args.tag}-receipt-adoption-approval.json'
    state, review, approval = [json.loads(local(p).read_bytes()) for p in (state_path, review_path, approval_path)]
    require(review['candidate'] == approval['candidate'] == state['candidate'], 'Review and approval do not bind this candidate')
    require(review['revision'] == approval['revision'] == state['revision'], 'Review revision mismatch')
    require(review['referenceClosure']['unresolvedReferences'] == 0 and review['checks']['productionPythonValidation'] == 'PASS', 'Independent runtime/reference review missing')
    comparison = review['checks']['productionNodeComparison']
    require(comparison['buildInputsMatch'] is True and comparison['implementationVerified'] is False, 'Production comparison missing or authority overstated')
    require(approval['approved'] is True, 'Explicit bounded root adoption approval missing')
    require(state['operativeReceiptApproved'] is False and state['operativeReceiptOrPinsChanged'] is False, 'Candidate authority status invalid')
    queue = [state_path, review_path, approval_path, Path(__file__).absolute(), Path(__file__).with_name("receipt_renewal_safety_candidate.py").absolute()]
    included, inherited, references = {}, {}, {}

    def walk(value):
        if isinstance(value, list):
            for child in value:
                walk(child)
        elif isinstance(value, dict):
            if isinstance(value.get('archive'), dict) and isinstance(value.get('member'), str) and isinstance(value.get('sha256'), str):
                historical(value)
                opaque = historical_archive_for_queue(ROOT, OUT, value)
                if opaque is not None:
                    queue.append(opaque)
                key = value['archive']['path'] + ':' + value['member']
                inherited[key] = value
                return  # Preserve sealed historical context; never rebind old source to current files.
            if isinstance(value.get('path'), str) and re.fullmatch('[a-f0-9]{64}', str(value.get('sha256', ''))):
                p = local(value['path'])
                require(sha(p.read_bytes()) == value['sha256'], 'Current reference changed: ' + value['path'])
                references[value['path']] = {'path': value['path'], 'sha256': value['sha256']}
                if p.is_relative_to(OUT):
                    queue.append(p)
            if isinstance(value.get('log'), str) and isinstance(value.get('logSha256'), str):
                walk({'path': value['log'], 'sha256': value['logSha256']})
            for child in value.values():
                walk(child)

    while queue:
        p = local(queue.pop())
        require(p.is_relative_to(OUT), 'Only new ignored report evidence may be included')
        relative = p.relative_to(ROOT).as_posix()
        if relative in included:
            continue
        raw = p.read_bytes()
        included[relative] = raw
        if p.suffix == '.json':
            walk(json.loads(raw))

    manifest = {'schemaVersion': 1, 'sourceRevision': state['revision'],
        'scope': 'New offline execution/review evidence; tracked source remains bound to the frozen Git revision. Prior archive members keep their historical context.',
        'files': [{'path': p, 'member': 'review/' + p, 'sha256': sha(raw), 'bytes': len(raw)} for p, raw in sorted(included.items())],
        'verifiedCurrentReferences': list(references.values()), 'inheritedExactReferences': list(inherited.values()),
        'unresolvedReferences': [], 'providerAcceptanceVerified': False, 'operativeReceiptOrPinsChanged': False}
    manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
    payload = {'manifest.json': manifest_raw, **{'review/' + p: b for p, b in sorted(included.items())}}

    def pack():
        plain = io.BytesIO()
        with tarfile.open(fileobj=plain, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name, raw in payload.items():
                item = tarfile.TarInfo(name)
                item.size, item.mode = len(raw), 0o444
                item.uid = item.gid = item.mtime = 0
                item.uname = item.gname = ''
                archive.addfile(item, io.BytesIO(raw))
        compressed = io.BytesIO()
        with gzip.GzipFile(filename='', fileobj=compressed, mode='wb', mtime=0, compresslevel=9) as handle:
            handle.write(plain.getvalue())
        return compressed.getvalue()

    raw = pack()
    require(raw == pack(), 'Archive is not reproducible byte-for-byte')
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        require(len(archive.getmembers()) == len(payload), 'Archive member inventory mismatch')
        for member in archive.getmembers():
            require(member.isfile() and member.mtime == 0 and archive.extractfile(member).read() == payload[member.name], 'Archive read-back mismatch')
    for p, content in included.items():
        require(local(p).read_bytes() == content, 'Evidence changed during archive creation')
    for binding in references.values():
        require(sha(local(binding['path']).read_bytes()) == binding['sha256'], 'Current reference changed during archive creation')
    for binding in inherited.values():
        historical(binding)
    output = OUT / f'{args.tag}-receipt-evidence.tar.gz'
    manifest_path = OUT / f'{args.tag}-receipt-evidence-manifest.json'
    require(not output.exists() and not manifest_path.exists(), 'Refusing to overwrite an evidence archive')
    with output.open('xb') as handle:
        handle.write(raw)
    with manifest_path.open('xb') as handle:
        handle.write(manifest_raw)
    print(json.dumps({'archive': output.relative_to(ROOT).as_posix(), 'sha256': sha(raw), 'manifest': manifest_path.relative_to(ROOT).as_posix(),
        'manifestSha256': sha(manifest_raw), 'files': len(included), 'doubleBuildByteIdentical': True, 'everyMemberReadBack': True, 'unresolvedReferences': 0,
        'operativeReceiptOrPinsChanged': False}))

if __name__ == '__main__':
    main()
