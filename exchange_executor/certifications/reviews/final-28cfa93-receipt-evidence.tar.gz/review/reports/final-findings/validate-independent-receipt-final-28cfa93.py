"""Future independent receipt review only. Never installs a receipt or changes pins.
Fixed28cfa93 target; refuses before all eight complete passing groups and candidate.
"""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
from receipt_renewal_safety_candidate import plain_local, check_command_inventory, check_group_inventory

ROOT=Path.cwd().resolve();OUT=ROOT/'reports/final-findings'
TAG='final-28cfa93';REVISION='28cfa93870323f835458bd00e8ce6932b7d06853'
SOURCE_REVIEW_HASH='70d97cb298e257191f977fc5724eb961afe18f9dbfbe58c499024775ea4923be'
ORIGINAL_RECEIPT_HASH='1427d769cda61eae1dfb5ec4cb145deff190f465a7d161f66a9f7973ac0aae8f'
ORIGINAL_AUTHORITY_HASH='2c5ded8064cf5cf0f716604bf148556450ae88d09be3650b6a82a7ee30751ed1'
NODE='C:/Users/nikla/AppData/Local/Programs/node22/node-v22.23.2-win-x64/node.exe'
PYTHON=str(ROOT.parent/'tsx-security-python-env/Scripts/python.exe')
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def require(ok,reason):
 if not ok:raise ValueError(reason)
def unique(pairs):
 result={}
 for key,value in pairs:
  require(key not in result,'Duplicate JSON key');result[key]=value
 return result
def parse(raw):
 def bad(value):raise ValueError('Nonfinite JSON value: '+value)
 return json.loads(raw.decode('utf-8-sig'),object_pairs_hook=unique,parse_constant=bad)
def file_bytes(path):
 p=plain_local(ROOT,path);require(p.stat().st_size<=256*1024*1024,'Evidence file budget exceeded');return p.read_bytes()
def read(path):return parse(file_bytes(path))
def ref(path):
 p=plain_local(ROOT,path);return {'path':p.relative_to(ROOT).as_posix(),'sha256':sha(file_bytes(p))}
def bound(binding):
 require(ref(ROOT/binding['path'])==binding,'Current reference binding differs');return ROOT/binding['path']
def time(value):return datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
def head():return subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def check_operative_unchanged():
 require(sha(file_bytes(ROOT/'exchange_executor/certifications/hyperliquid.json'))==ORIGINAL_RECEIPT_HASH,'Operative receipt changed before review')
 require(sha(file_bytes(ROOT/'exchange_executor/ccxt_implementation_reviews.py'))==ORIGINAL_AUTHORITY_HASH,'Operative approval pins changed before review')

def reference_closure(state_path):
 queue=[plain_local(ROOT,state_path)];visited={};current={};historical={};opaque={}
 def walk(value):
  if isinstance(value,list):
   for child in value:walk(child)
  elif isinstance(value,dict):
   if isinstance(value.get('archive'),dict) and isinstance(value.get('member'),str) and isinstance(value.get('sha256'),str):
    archive=bound(value['archive']);member=value['member'];member_path=PurePosixPath(member)
    require(not member_path.is_absolute() and '..' not in member_path.parts and '\\' not in member,'Invalid historical member path')
    with tarfile.open(archive,'r:*') as handle:
     members=handle.getmembers();require(len(members)<=20000 and len({m.name for m in members})==len(members),'Historical archive ambiguous or over budget')
     item=handle.getmember(member);require(item.isfile() and not item.issym() and not item.islnk() and item.size<=64*1024*1024,'Invalid historical member')
     raw=handle.extractfile(item).read();require(sha(raw)==value['sha256'],'Historical member hash differs')
    historical[value['archive']['path']+':'+member]=value
    if archive.is_relative_to(OUT):opaque[value['archive']['path']]=value['archive']
    return # Old embedded source paths stay in their sealed historical context.
   if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
    require(len(value['sha256'])==64 and all(c in '0123456789abcdef' for c in value['sha256']),'Invalid SHA reference')
    binding={'path':value['path'],'sha256':value['sha256']};p=bound(binding);current[binding['path']]=binding
    if p.is_relative_to(OUT):queue.append(p)
   if isinstance(value.get('log'),str) and isinstance(value.get('logSha256'),str):walk({'path':value['log'],'sha256':value['logSha256']})
   for child in value.values():walk(child)
 while queue:
  p=queue.pop();relative=p.relative_to(ROOT).as_posix()
  if relative in visited:continue
  require(len(visited)<20000,'Current reference graph exceeds budget');raw=file_bytes(p);visited[relative]=sha(raw)
  if p.suffix=='.json':walk(parse(raw))
 for relative,digest in visited.items():require(sha(file_bytes(ROOT/relative))==digest,'Evidence changed during reference walk')
 for binding in current.values():bound(binding)
 for binding in opaque.values():bound(binding)
 return {'unresolvedReferences':0,'currentReports':len(visited),'currentReferences':len(current),'historicalMembers':len(historical),'verifiedCurrentReferences':list(current.values()),'inheritedExactReferences':list(historical.values()),'opaqueIgnoredArchivesToInclude':list(opaque.values()),'historicalContextRebound':False}

def check_execution_groups(execution):
 require(execution['revision']==REVISION and execution['providerAcceptanceVerified'] is False and execution['pythonExecutionInheritance'] is False,'Execution scope differs')
 groups=execution['groups'];check_group_inventory(groups)
 before=read(bound(execution['beforeContext']));after=read(bound(execution['afterContext']))
 require(before['revision']==after['revision']==REVISION and before['inputs']==after['inputs'],'Final contexts differ')
 require(before['runtime']==after['runtime']==execution['runtime'],'Runtime context differs')
 require(all(c['rawEqualsGit'] and c['allInputsSingleLink'] and c['sourceStableDuringCapture'] for c in [before,after]),'Incomplete source proof')
 for group in groups:
  actual=read(bound(group['report']));check_command_inventory(actual,ROOT,NODE)
  require(actual['group']==group['group'] and actual.get('completedAt') and actual['observedInputsUnchanged'] is True,'Group missing completion/source stability')
  require(actual['allCommandsPassed'] is True and all(type(c['exitCode']) is int and c['exitCode']==0 and c.get('signal') is None and not c.get('error') for c in actual['commands']),'All eight selected groups must be terminal green')
  require(actual['revision']==actual['revisionAfter']==REVISION and actual['inputsBefore']==actual['inputsAfter']==before['inputs'],'Group source differs')
  require(actual['runtime']['node']==before['runtime']['node'] and actual['runtime']['ccxt']==before['runtime']['ccxt'] and actual['runtime']['python']=='Python '+before['runtime']['python'].split()[0],'Group runtime differs')
  require(time(before['observedAt'])<=time(actual['startedAt'])<=time(actual['completedAt'])<=time(after['startedAt']),'Group outside frozen window')
  require(not group['reviewedReplacements'],'This final review requires eight directly passing selected groups; replacement needs separate explicit review')
  for c in actual['commands']:
   bound({'path':c['log'],'sha256':c['logSha256']});require(time(actual['startedAt'])<=time(c['startedAt'])<=time(c['completedAt'])<=time(actual['completedAt']),'Command time outside group')
 return before['inputs']

PYTHON_CODE=r'''
import json,sys
from pathlib import Path
root=Path(sys.argv[1]);candidate=Path(sys.argv[2]);pin=sys.argv[3]
sys.path.insert(0,str(root/'exchange_executor'))
import ccxt
from ccxt_certification_evidence import read_receipt,validate_receipt
from ccxt_profiles import PROFILES
value=read_receipt(candidate,(pin,)) # Ephemeral review-only comparison pin, never approval-root installation.
validate_receipt(value,'hyperliquid',ccxt.__version__,PROFILES['hyperliquid'],root/'exchange_executor',Path(ccxt.__file__).parent)
print(json.dumps({'validation':'PASS','implementationVerified':False,'providerAcceptanceVerified':False,'operativeReceiptOrPinsChanged':False}))
'''

def main():
 require(head()==REVISION,'Wrong frozen HEAD');check_operative_unchanged()
 state_path=OUT/f'{TAG}-receipt-candidate-state.json'
 require(state_path.exists(),'No candidate exists; no review or authority output created')
 state=read(state_path);require(state['revision']==REVISION and state['operativeReceiptApproved'] is False and state['operativeReceiptOrPinsChanged'] is False,'Candidate already claims authority')
 review_path=bound(state['completeSourceReview']);require(state['completeSourceReview']['sha256']==SOURCE_REVIEW_HASH,'Wrong root source approval')
 approval=read(review_path);require(approval['reviewed'] is True and approval['sourceReviewComplete'] is True and approval['rootApprovalPending'] is False,'Source semantics approval missing')
 execution=read(bound(state['execution']));inputs=check_execution_groups(execution)
 parity=read(bound(state['parity']));require(parity['revision']==REVISION and parity['providerAcceptanceVerified'] is False,'Parity scope differs')
 rows=parity['rows'];require(len(rows)==62 and len({(r['category'],r['check']) for r in rows})==62 and sum(len(r['witnessBindings']) for r in rows)==97,'Requirement/witness inventory differs')
 for row in rows:require(row['completeSourceReview']==state['completeSourceReview'] and row['currentExecution']==state['execution'],'Requirement review/execution binding differs')
 candidate_path=bound(state['candidate']);candidate=read(candidate_path);prior=read(ROOT/'exchange_executor/certifications/hyperliquid.json')
 require(candidate['sourceRevision']==REVISION and candidate['parityEvidenceHash']==state['parity']['sha256'] and candidate['executionReportHash']==state['execution']['sha256'],'Candidate evidence commitments differ')
 for key in ['schemaVersion','kind','exchange','ccxtVersion','profileVersion','profileHash','scope','providerAcceptanceVerified']:require(candidate[key]==prior[key],'Receipt scope/identity expanded')
 closure=reference_closure(state_path)
 py=subprocess.run([PYTHON,'-I','-B','-c',PYTHON_CODE,str(ROOT),str(candidate_path),state['candidate']['sha256']],capture_output=True,text=True,check=True)
 py_result=parse(py.stdout.encode());require(py_result['validation']=='PASS' and py_result['implementationVerified'] is False,'Unexpected Python result')
 js="import fs from 'node:fs';import {compareBuildReceipt} from './scripts/verify_exchange_implementation.js';const r=compareBuildReceipt(fs.readFileSync("+json.dumps(str(candidate_path))+"),{root:process.cwd(),exchange:'hyperliquid',profileVersion:"+str(prior['profileVersion'])+",approvedReceiptHashes:["+json.dumps(state['candidate']['sha256'])+"]});console.log(JSON.stringify(r));"
 node=subprocess.run([NODE,'--input-type=module','-e',js],cwd=ROOT,capture_output=True,text=True,check=True);comparison=parse(node.stdout.encode())
 require(comparison['buildInputsMatch'] is True and comparison['sourceTreeHash']==inputs['sourceTreeHash'] and all(comparison[k] is False for k in ['implementationVerified','providerAcceptanceVerified','runtimeReceiptVerified','performedGateExecution']),'Build comparison overclaims verification')
 check_operative_unchanged();require(head()==REVISION,'HEAD changed during review');closure_after=reference_closure(state_path);require(closure==closure_after,'Reference graph changed during validation')
 result={'revision':REVISION,'candidate':state['candidate'],'completeSourceReview':state['completeSourceReview'],'reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{'productionPythonValidation':'PASS','productionNodeComparison':comparison,'eightTerminalGreenGroups':True,'scopeUnchanged':True},'referenceClosure':closure,'reviewValidator':ref(Path(__file__).absolute()),'comparisonOnlyPin':{'candidateHash':state['candidate']['sha256'],'scope':'Explicit trusted-call test comparison only; not installed in operative approval root.'},'implementationVerified':False,'providerAcceptanceVerified':False,'operativeReceiptOrPinsChanged':False,'operativeReceiptApproved':False,'remaining':['Explicit bounded root adoption approval','Reviewed deterministic archive','Actual post-adoption production implementation gate and bridge regressions']}
 out=OUT/f'{TAG}-independent-receipt-review.json';require(not out.exists(),'Review evidence already exists')
 with out.open('x',encoding='utf-8',newline='\n') as handle:json.dump(result,handle,ensure_ascii=False,indent=2);handle.write('\n')
 print(json.dumps({'review':ref(out),'operativeReceiptOrPinsChanged':False,'implementationVerified':False,'providerAcceptanceVerified':False}))
if __name__=='__main__':main()
