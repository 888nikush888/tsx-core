"""Prepare review data or an unapproved candidate from actual terminal executions."""
import argparse
import copy
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

from receipt_renewal_safety_candidate import plain_local, check_command_inventory, check_group_inventory

ROOT = Path.cwd().resolve()
OUT = ROOT / 'reports/final-findings'
NODE = 'C:/Users/nikla/AppData/Local/Programs/node22/node-v22.23.2-win-x64/node.exe'
ARCHIVE = ROOT / 'exchange_executor/certifications/reviews/findings-1d6b288-evidence.tar.gz'
ARCHIVE_HASH = '71fee5907f772e6b63f2686b5b0eb0e3066e59e19f43c5053e5195a0d81f7db1'
PRIOR_RECEIPT_HASH = '1427d769cda61eae1dfb5ec4cb145deff190f465a7d161f66a9f7973ac0aae8f'
GROUPS = ['foundation', 'backend', 'python', 'frontend', 'build', 'browser', 'mutations', 'dependencies']
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(plain_local(ROOT, p).read_bytes())
stamp = lambda s: datetime.datetime.fromisoformat(s.replace('Z', '+00:00'))

def require(condition, message):
    if not condition:
        raise ValueError(message)

def ref(p):
    p = plain_local(ROOT, p)
    require(p.is_relative_to(ROOT), 'Evidence path leaves repository')
    return {'path': p.relative_to(ROOT).as_posix(), 'sha256': sha(p.read_bytes())}

def save(name, value):
    p = OUT / name
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    require(not p.exists() or p.read_bytes() == raw, f'Refusing to overwrite prior evidence: {name}')
    if not p.exists():
        p.write_bytes(raw)
    return ref(p)

def archived(name):
    require(sha(ARCHIVE.read_bytes()) == ARCHIVE_HASH, 'Prior sealed archive changed')
    member = 'review/reports/findings-review/' + name
    with tarfile.open(ARCHIVE) as archive:
        item = archive.getmember(member)
        require(item.isfile() and not item.issym() and not item.islnk(), 'Non-ordinary archive member')
        raw = archive.extractfile(item).read()
    return json.loads(raw), {'archive': ref(ARCHIVE), 'member': member, 'sha256': sha(raw)}

def actual_inputs():
    return json.loads(subprocess.check_output([NODE, '--input-type=module', '-e',
        "import {collectBuildInputs} from './scripts/verify_exchange_implementation.js';console.log(JSON.stringify(collectBuildInputs(process.cwd())));"], text=True))

def check_binding(binding):
    if isinstance(binding.get('archive'), dict):
        archive_path = ROOT / binding['archive']['path']
        require(ref(archive_path) == binding['archive'], 'Historical evidence archive changed')
        with tarfile.open(archive_path) as archive:
            member = archive.getmember(binding['member'])
            require(member.isfile() and not member.issym() and not member.islnk(), 'Historical evidence member is not ordinary')
            raw = archive.extractfile(member).read()
        require(sha(raw) == binding['sha256'], 'Historical evidence member changed')
        return
    require(ref(ROOT / binding['path']) == binding, 'Review evidence bytes changed')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tag', required=True)
    parser.add_argument('--revision', required=True)
    parser.add_argument('--candidate', action='store_true')
    parser.add_argument('--source-review', type=Path)
    parser.add_argument('--before', default='receipt-context-final-before.json')
    parser.add_argument('--after', default='receipt-context-final-after.json')
    parser.add_argument('--verification-resolution', type=Path)
    parser.add_argument('--execution-selection', type=Path)
    parser.add_argument('--execution-tag', default='')
    args = parser.parse_args()
    require(re.fullmatch('[A-Za-z0-9_-]+', args.tag), 'Invalid output tag')
    require(not args.execution_tag or re.fullmatch('[A-Za-z0-9_-]+', args.execution_tag), 'Invalid execution tag')
    require(re.fullmatch('[a-f0-9]{40}', args.revision), 'Expected exact frozen revision')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    require(head == args.revision, 'Frozen HEAD changed')
    prior = read(ROOT / 'exchange_executor/certifications/hyperliquid.json')
    require(sha((ROOT / 'exchange_executor/certifications/hyperliquid.json').read_bytes()) == PRIOR_RECEIPT_HASH, 'Operative receipt changed')
    state, state_ref = archived('final-v9-receipt-candidate-state.json')
    prior_context, prior_context_ref = archived('context-final-v9-after.json')
    prior_parity, prior_parity_ref = archived('final-v9-receipt-parity-supplement.json')
    require(state['candidate']['sha256'] == PRIOR_RECEIPT_HASH and prior_parity_ref['sha256'] == prior['parityEvidenceHash'], 'Historical receipt/parity commitments differ')
    require(prior_context['inputs']['sourceTreeHash'] == prior['sourceTreeHash'], 'Historical context is not the operative receipt source')
    inputs = actual_inputs()
    old = {r['path']: r['sha256'] for r in prior_context['inputs']['files']}
    current = {r['path']: r['sha256'] for r in inputs['files']}
    deltas = [{'path': p, 'beforeSha256': old.get(p), 'currentSha256': current.get(p),
               'status': 'modified' if p in old and p in current else 'added' if p in current else 'removed'}
              for p in sorted(set(old) | set(current)) if old.get(p) != current.get(p)]
    delta_ref = save(f'{args.tag}-receipt-source-deltas.json', {'revision': head, 'priorContext': prior_context_ref,
        'counts': {'priorInputs': len(old), 'currentInputs': len(current), 'changedAddedRemoved': len(deltas)}, 'deltas': deltas})
    if not args.candidate:
        draft = {'revision': head, 'deltas': delta_ref, 'reviewed': False, 'providerAcceptanceVerified': False,
                 'reviews': [{**row, 'reviewed': False, 'rationale': '', 'evidence': []} for row in deltas]}
        draft_ref = save(f'{args.tag}-receipt-source-review-draft.json', draft)
        print(json.dumps({'prepared': [delta_ref, draft_ref], 'counts': {'currentInputs': len(current), 'sourceDeltas': len(deltas)}, 'candidateCreated': False}))
        return

    require(args.source_review is not None, 'Explicit complete source review required')
    review_path = plain_local(ROOT, args.source_review)
    review = read(review_path)
    require(review['revision'] == head and review['deltas'] == delta_ref and review['reviewed'] is True, 'Source review not finalized for exact delta set')
    reviews = {row['path']: row for row in review['reviews']}
    require(len(reviews) == len(review['reviews']) == len(deltas) and set(reviews) == {d['path'] for d in deltas}, 'Complete source-delta review missing')
    for row in deltas:
        checked = reviews[row['path']]
        require(all(checked[k] == row[k] for k in ('beforeSha256', 'currentSha256', 'status')), 'Source review binding mismatch')
        require(checked['reviewed'] is True and checked['rationale'].strip() and checked['evidence'], 'Individual source review lacks evidence')
        for binding in checked['evidence']:
            check_binding(binding)
    before_path, after_path = OUT / args.before, OUT / args.after
    before, after = read(before_path), read(after_path)
    require(before['revision'] == after['revision'] == head and before['inputs'] == after['inputs'] == inputs, 'Final contexts or current source differ')
    require(before['runtime'] == after['runtime'], 'Runtime changed across execution window')
    require(all(c['rawEqualsGit'] and c['allInputsSingleLink'] and c['sourceStableDuringCapture'] for c in (before, after)), 'Context lacks source proof')
    runtime = before['runtime']
    executions = []
    logs = {}
    resolution_path = plain_local(ROOT, args.verification_resolution) if args.verification_resolution else None
    resolution = read(resolution_path) if resolution_path else {'resolvedFailures': []}
    if resolution_path:
        require(resolution['revision'] == head and resolution['reviewed'] is True, 'Execution resolution requires root review at the frozen revision')
    resolved = {(r['group'], r['commandName']): r for r in resolution['resolvedFailures']}
    require(len(resolved) == len(resolution['resolvedFailures']), 'Duplicate failure resolution')
    used_resolutions = set()
    selection_path = plain_local(ROOT, args.execution_selection) if args.execution_selection else None
    selection = read(selection_path) if selection_path else {'selections': []}
    if selection_path:
        require(selection['revision'] == head and selection['reviewed'] is True, 'Attempt selection requires root review at exact frozen source')
    selections = {r['group']: r for r in selection['selections']}
    require(len(selections) == len(selection['selections']) and set(selections) <= set(GROUPS), 'Duplicate or unknown selected verification group')

    def check_execution(execution, label, allow_native=False):
        check_command_inventory(execution, ROOT, NODE, allow_native)
        require(execution.get('completedAt') and execution['observedInputsUnchanged'], f'Group not terminal/source-stable: {label}')
        require(execution['revision'] == execution['revisionAfter'] == head and execution['inputsBefore'] == execution['inputsAfter'] == inputs, f'Group source differs: {label}')
        require(execution['runtime']['node'] == runtime['node'] and execution['runtime']['ccxt'] == runtime['ccxt'] and execution['runtime']['python'] == 'Python ' + runtime['python'].split()[0], f'Group runtime differs: {label}')
        require(stamp(before['observedAt']) <= stamp(execution['startedAt']) <= stamp(execution['completedAt']) <= stamp(after['startedAt']), f'Group outside context window: {label}')
        require(execution['commands'], 'Empty execution group')
        require(execution['allCommandsPassed'] is all(c['exitCode'] == 0 for c in execution['commands']), 'Execution aggregate does not match command exits')

    for group in GROUPS:
        execution_suffix = '-' + args.execution_tag if args.execution_tag else ''
        execution_path = OUT / f'verification-{group}{execution_suffix}.json'
        earlier_attempts = []
        if group in selections:
            chosen = selections[group]
            require(chosen['reviewed'] is True and len(chosen['rationale'].strip()) >= 40 and chosen['previousExecutions'], 'Attempt selection lacks review/provenance')
            check_binding(chosen['selectedExecution'])
            execution_path = plain_local(ROOT, chosen['selectedExecution']['path'])
            require(execution_path.is_relative_to(OUT), 'Selected execution must be ignored current-run evidence')
            for binding in chosen['previousExecutions']:
                check_binding(binding)
                previous = read(ROOT / binding['path'])
                check_execution(previous, f'preserved previous {group} attempt')
                require(previous['group'] == group, 'Previous attempt group differs')
                prior_logs = []
                for c in previous['commands']:
                    log_path = ROOT / c['log']
                    require(sha(log_path.read_bytes()) == c['logSha256'], 'Earlier attempt log changed')
                    prior_logs.append(ref(log_path))
                earlier_attempts.append({'execution': binding, 'logs': prior_logs, 'originalAllCommandsPassed': previous['allCommandsPassed']})
        execution = read(execution_path)
        require(execution['group'] == group, 'Selected execution group differs')
        check_execution(execution, group)
        bindings = []
        replacements = []
        for command in execution['commands']:
            log_path = ROOT / command['log']
            require(sha(log_path.read_bytes()) == command['logSha256'], 'Terminal log bytes differ')
            require(stamp(execution['startedAt']) <= stamp(command['startedAt']) <= stamp(command['completedAt']) <= stamp(execution['completedAt']), 'Command outside group window')
            logs[command['name']] = log_path.read_text(encoding='utf-8-sig')
            bindings.append(ref(log_path))
            if command['exitCode'] != 0:
                key = (group, command['name'])
                require(key == ('foundation', 'quality-monitoring') and key in resolved, 'Unresolved failed verification command')
                r = resolved[key]
                require(r['failedExecution'] == ref(execution_path) and r['failedLog'] == ref(log_path), 'Resolution does not bind original failure')
                require(r['reviewed'] is True and len(r['rationale'].strip()) >= 40 and r['requiredChecks'] and r['equivalentRequiredChecks'] is True, 'Replacement lacks individual equivalence review')
                check_binding(r['replacementExecution'])
                replacement = read(ROOT / r['replacementExecution']['path'])
                check_execution(replacement, 'reviewed native monitoring replacement', allow_native=True)
                require(replacement['allCommandsPassed'], 'Replacement did not pass every actual command')
                replacement_logs = []
                for replacement_command in replacement['commands']:
                    p = ROOT / replacement_command['log']
                    require(sha(p.read_bytes()) == replacement_command['logSha256'], 'Replacement log changed')
                    require(stamp(replacement['startedAt']) <= stamp(replacement_command['startedAt']) <= stamp(replacement_command['completedAt']) <= stamp(replacement['completedAt']), 'Replacement command outside group window')
                    replacement_logs.append(ref(p))
                require(set(r['requiredChecks']) <= {c['name'] for c in replacement['commands']}, 'Required monitoring checks absent from replacement')
                replacements.append({'resolution': ref(resolution_path), 'failedCommand': command['name'], 'replacementExecution': r['replacementExecution'], 'replacementLogs': replacement_logs,
                                     'originalFailureRetained': True, 'rationale': r['rationale']})
                used_resolutions.add(key)
        executions.append({'group': group, 'report': ref(execution_path), 'logs': bindings, 'freshAtFrozenRevision': True,
                           'originalAllCommandsPassed': execution['allCommandsPassed'], 'reviewedReplacements': replacements,
                           'preservedEarlierAttempts': earlier_attempts, 'attemptSelection': ref(selection_path) if group in selections else None})
    check_group_inventory(executions)
    require(used_resolutions == set(resolved), 'Unused or stale verification resolution')
    python_count = re.search(r'^Ran (\d+) tests? in ', logs['python-coverage'], re.M)
    frontend_count = re.search(r'Tests\s+(\d+) passed', logs['frontend-coverage'])
    frontend_files = re.search(r'Test Files\s+(\d+) passed', logs['frontend-coverage'])
    backend_files = re.search(r'ALL (\d+) TEST FILES PASSED', logs['backend-module-coverage'])
    require(python_count and re.search(r'^OK\s*$', logs['python-coverage'], re.M), 'Python summary missing')
    require(frontend_count and frontend_files and backend_files and 'Module coverage ratchet passed.' in logs['backend-module-coverage'], 'Suite success summaries missing')
    execution_ref = save(f'{args.tag}-receipt-execution-supplement.json', {'revision': head,
        'beforeContext': ref(before_path), 'afterContext': ref(after_path), 'runtime': runtime, 'groups': executions,
        'observedCounts': {'pythonTests': int(python_count[1]), 'frontendTests': int(frontend_count[1]), 'frontendFiles': int(frontend_files[1]), 'backendModuleTestFiles': int(backend_files[1])},
        'pythonExecutionInheritance': False, 'providerAcceptanceVerified': False, 'operativeReceiptApproved': False})
    witness_review_path = OUT / 'receipt-witness-delta-review.json'
    witness_review = read(witness_review_path)
    reviewed_witnesses = {r['path']: r for r in witness_review['reviews']}
    rows = []
    changed_refs = 0
    category_review = {
        'lifecycle': 'Existing lifecycle witnesses are byte-identical. TradingEngine projection annotations and private static helper extraction preserve queries, awaited dispatch and ownership boundaries; current full Node execution rechecks stop, cancel, drain, kill and late-fill behavior.',
        'moneyRisk': 'Money witnesses are byte-identical. Native fill proof now rejects malformed originals before identity comparison while retaining sanitized unresolved economics; account-log day filtering is a runtime-equivalent chained comparison. Full current Node/Python execution rechecks the original ledger and risk witnesses.',
        'crossLayer': 'Original workflow fallback, emergency and restart witness files are byte-identical; their dependencies have separately reviewed changes. Native Hyperliquid emergency fixture IDs now satisfy the existing decimal-ID proof. Workflow raw-byte witnesses retain historical persisted digests, with separate hydrated-path integrity and canonical equivalent-resource checks. New compatibility regressions supplement the original isolation/restart witnesses in the current full Node execution.',
        'identitySecrets': 'Identity/secret witnesses either remain byte-identical or have the individually reviewed guarded-next rewrite only. Boundary type guards exclude structured values without weakening authenticated identity, credential-generation or redaction requirements; current full execution is required.',
        'symbolProduct': 'All original symbol/product witness bytes remain unchanged. Structured paper-symbol inputs are rejected before coercion; exact-resolution, product, precision, settlement and quantity fixtures still run in the current full suites.',
        'accountModeAdmission': 'The mode-readback witness has only the reviewed scripted-page sentinel rewrite; other original witnesses are byte-identical. No execution profile, account mode or scope is changed, and current full tests recheck the admission matrix.',
        'entryProtection': 'Original entry/protection witness files are byte-identical. The restored truthiness guard rejects malformed truthy entry requests before credentials or transport; new submission-boundary regressions cover this separately. Native asynchronous adapter boundaries and independent reduce-only protection remain; current full suites recheck correlation, IDs, batches and unknown outcomes.',
        'ownershipReconciliation': 'Original ownership/reconciliation witnesses are byte-identical. New primitive-only native fill identity proof intentionally refuses ambiguous/coercible originals; direct/live/backfill regressions supplement the existing namespace and unknown-evidence witnesses without rewriting archived originals.',
        'history': 'Original history witness files are either byte-identical or differ only in reviewed missing-selection assertions using unique sentinels. Their changed history-reader dependency restores eager validation of every listed row: an early match cannot hide malformed later evidence. New iteration regressions supplement current full Python/Node execution of completeness, time, retention, pagination and budget contracts.',
        'errorsStreams': 'Original pagination/recovery witness files have only reviewed guarded-next rewrites; other stream/error witness files are byte-identical. Separately reviewed eager listed-evidence validation restores failure on malformed later identity evidence without issuing an unnecessary lookup. Native Promise/coroutine boundaries remain; current full tests recheck retry/error classification and REST/stream authority.',
    }
    for prior_row in prior_parity['rows']:
        bindings = []
        for witness in prior_row['witnessBindings']:
            p = witness['path']
            require(old[p] == witness['sha256'] and p in current, 'Prior witness or current witness inventory invalid')
            binding = {'path': p, 'sha256': current[p]}
            if current[p] != witness['sha256']:
                checked = reviewed_witnesses[p]
                require(checked['previousSha256'] == witness['sha256'] and checked['currentSha256'] == current[p] and checked['reviewed'] is True, 'Changed witness requires exact individual review')
                binding.update({'previousSha256': witness['sha256'], 'review': ref(witness_review_path), 'lookup': p, 'rationale': checked['rationale']})
                changed_refs += 1
            bindings.append(binding)
        key = (prior_row['category'], prior_row['check'])
        supplemental = []
        if key in {('ownershipReconciliation', 'namespaces'), ('ownershipReconciliation', 'ambiguousUnknownEvidence'), ('moneyRisk', 'replayIdempotency'), ('moneyRisk', 'unknownBlocksEntryNotProtection')}:
            supplemental = [ref(ROOT / p) for p in ('tests/test_exchange_fill_identity.js', 'tests/test_trading_fill_identity_backfill.js', 'docs/testing/final-fill-identity-independent-review-2026-09-17.json')]
        if prior_row['category'] == 'entryProtection':
            supplemental.extend(ref(ROOT / p) for p in ('src/exchange_entry_deadline.ts', 'tests/test_entry_deadline_transport.js'))
        if prior_row['category'] in ('history', 'errorsStreams'):
            supplemental.extend(ref(ROOT / p) for p in ('exchange_executor/history_reader.py', 'exchange_executor/tests/test_history_reader_iteration.py'))
        if prior_row['category'] == 'crossLayer':
            supplemental.extend(ref(ROOT / p) for p in ('tests/test_workflow_hash_compatibility.js', 'tests/test_workflow_builder.js', 'tests/fixtures/trading_emergency_fixture.js'))
        rows.append({'category': prior_row['category'], 'check': prior_row['check'], 'witnessBindings': bindings,
            'sealedPriorRow': {'evidence': prior_parity_ref, 'lookup': {'category': prior_row['category'], 'check': prior_row['check']}},
            'completeSourceReview': ref(review_path), 'currentExecution': execution_ref,
            'currentDeltaAssessment': category_review[prior_row['category']], 'supplementalCurrentEvidence': supplemental,
            'scope': 'Offline implementation requirement; no provider execution or scope expansion.'})
    require(len(rows) == 62 and len({(r['category'], r['check']) for r in rows}) == 62 and sum(len(r['witnessBindings']) for r in rows) == 97, 'Requirement inventory changed')
    parity_ref = save(f'{args.tag}-receipt-parity-supplement.json', {'revision': head, 'priorParity': prior_parity_ref,
        'counts': {'requirements': 62, 'witnessReferences': 97, 'changedWitnessReferences': changed_refs, 'unchangedWitnessReferences': 97-changed_refs},
        'method': 'Preserve every unchanged path/hash pair exactly. Prior row rationale remains in the sealed archive; changed witnesses have individual source/AST review. All current execution evidence is fresh, including Python.',
        'rows': rows, 'providerAcceptanceVerified': False, 'operativeReceiptApproved': False})
    candidate = copy.deepcopy(prior)
    for key in ('sourceTreeHash', 'nodeSourcesHash', 'testSourcesHash', 'fixturesHash'):
        candidate[key] = inputs[key]
    for key in ('executorTreeHash', 'sdkTreeHash', 'profileHash'):
        candidate[key] = runtime[key]
    candidate.update({'sourceRevision': head, 'parityEvidenceHash': parity_ref['sha256'], 'executionReportHash': execution_ref['sha256'],
                      'reviewedAt': datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')})
    sys.path.insert(0, str(ROOT / 'exchange_executor'))
    import ccxt
    from ccxt_certification_evidence import validate_receipt
    from ccxt_profiles import PROFILES
    validate_receipt(candidate, 'hyperliquid', ccxt.__version__, PROFILES['hyperliquid'], ROOT / 'exchange_executor', Path(ccxt.__file__).parent)
    require(all(candidate[k] == prior[k] for k in ('schemaVersion', 'kind', 'exchange', 'ccxtVersion', 'profileVersion', 'profileHash', 'scope', 'providerAcceptanceVerified')), 'Receipt scope or identity expanded')
    candidate_ref = save(f'{args.tag}-hyperliquid-receipt-candidate.json', candidate)
    state = {'revision': head, 'candidate': candidate_ref, 'execution': execution_ref, 'parity': parity_ref,
        'completeSourceReview': ref(review_path), 'priorReceiptState': state_ref,
        'reproducibilityHelpers': [ref(OUT / p) for p in ('prepare-receipt-renewal.py', 'collect-receipt-context.mjs', 'receipt-runtime-snapshot.py', 'review-receipt-witnesses.py', 'run-verification.mjs', 'receipt_renewal_safety_candidate.py')],
        'operativeReceiptOrPinsChanged': False, 'operativeReceiptApproved': False,
        'remaining': ['Independent production comparator/runtime validation and reference-graph review', 'Deterministic reviewed archive', 'Explicit root adoption', 'Real post-adoption implementation gate and bridge regressions']}
    state_ref = save(f'{args.tag}-receipt-candidate-state.json', state)
    print(json.dumps({'candidate': candidate_ref, 'state': state_ref, 'operativeReceiptApproved': False}))

if __name__ == '__main__':
    main()
