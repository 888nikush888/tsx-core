import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createWriteStream, readFileSync, writeFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { collectBuildInputs } from '../../scripts/verify_exchange_implementation.js';

const root = process.cwd();
const python = path.resolve(root, '../tsx-security-python-env/Scripts/python.exe');
const node = process.execPath;
const npm = path.join(path.dirname(node), 'node_modules/npm/bin/npm-cli.js');
const out = path.join(root, 'reports/final-findings');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const stamp = () => new Date().toISOString();
const env = { ...process.env, TSX_TEST_PYTHON: python, PATH: `${path.dirname(python)};${path.dirname(node)};${process.env.PATH ?? ''}` };
const observe = (command, args) => {
  const result = spawnSync(command, args, { cwd: root, env, encoding: 'utf8', windowsHide: true });
  if (result.status !== 0) throw new Error(`Cannot observe runtime: ${path.basename(command)}`);
  return result.stdout.trim();
};
const npmTask = script => [node, [npm, 'run', script]];
const jobs = {
  foundation: ['lint', 'lint:frontend', 'lint:python', 'typecheck', 'quality:architecture',
    'quality:complexity', 'quality:frontend', 'quality:release', 'quality:risk-acceptances',
    'quality:monitoring', 'quality:build-context', 'quality:licenses', 'quality:dependencies',
    'quality:duplicates'].map(name => [name.replaceAll(':', '-'), ...npmTask(name)]),
  backend: [['backend-coverage', ...npmTask('test:coverage')], ['backend-module-coverage', ...npmTask('test:coverage:modules')]],
  python: [['python-coverage', python, ['-B', '-m', 'coverage', 'run', '--branch', '--source=exchange_executor', '-m', 'unittest', 'discover', '-s', 'exchange_executor/tests', '-v']],
    ['python-coverage-report', python, ['-m', 'coverage', 'report', '--fail-under=60']],
    ['python-coverage-xml', python, ['-m', 'coverage', 'xml', '-o', 'exchange_executor/coverage.xml']]],
  frontend: [['frontend-coverage', node, [npm, '--prefix', 'frontend', 'run', 'test:coverage']]],
  build: [['build', ...npmTask('build')]],
  browser: [['browser', node, [npm, '--prefix', 'frontend', 'run', 'test:e2e', '--', '--workers=2']]],
  mutations: [['mutations', node, [npm, 'run', 'test:mutation', '--', '--force']]],
  dependencies: [['npm-audit-backend', node, [npm, 'audit', '--audit-level=moderate']],
    ['npm-audit-frontend', node, [npm, '--prefix', 'frontend', 'audit', '--audit-level=moderate']],
    ['sbom', ...npmTask('quality:sbom')]],
};
const selected = process.argv[2];
if (!Object.hasOwn(jobs, selected)) throw new Error('Select an explicit known verification group.');
if (selected === 'browser') env.CI = 'true';
const attempt = process.argv[3] ?? '';
if (attempt && !/^[a-z0-9-]+$/.test(attempt)) throw new Error('Invalid attempt label.');
const suffix = attempt ? `-${attempt}` : '';
const reportPath = path.join(out, `verification-${selected}${suffix}.json`);
if (existsSync(reportPath)) throw new Error('Refusing to overwrite existing execution evidence. Archive the old attempt explicitly first.');
const before = collectBuildInputs(root);
const report = { kind: 'observed-final-offline-verification', schemaVersion: 1, group: selected,
  startedAt: stamp(), attempt, revision: observe('git', ['rev-parse', 'HEAD']),
  runtime: { node: process.version, python: observe(python, ['--version']),
    ccxt: observe(python, ['-c', 'import ccxt; print(ccxt.__version__)']) },
  explicitTestPython: python, inputsBefore: before, commands: [], providerAcceptanceVerified: false,
  monitoringExecution: selected === 'foundation' ? {
    mode: env.PROMTOOL_PATH && env.AMTOOL_PATH ? 'native-configuration-only' : 'docker-images',
    tools: ['PROMTOOL_PATH', 'AMTOOL_PATH'].filter(key => env[key]).map(key => ({
      key, executable: env[key], sha256: sha(readFileSync(env[key])), version: observe(env[key], ['--version']),
    })),
    containerAcceptanceVerified: false,
  } : null };
writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n');
for (const [name, command, args] of jobs[selected]) {
  const logPath = path.join(out, `verification-${name}${suffix}.log`);
  if (existsSync(logPath)) throw new Error(`Refusing to overwrite log: ${name}`);
  const startedAt = stamp();
  const output = createWriteStream(logPath, { flags: 'wx' });
  const child = spawn(command, args, { cwd: root, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.pipe(output, { end: false });
  child.stderr.pipe(output, { end: false });
  const outcome = await new Promise(resolve => {
    child.on('error', error => resolve({ exitCode: null, error: error.message }));
    child.on('close', (exitCode, signal) => resolve({ exitCode, signal }));
  });
  await new Promise(resolve => output.end(resolve));
  const result = { name, command, args, startedAt, completedAt: stamp(), ...outcome,
    log: path.relative(root, logPath).replaceAll('\\', '/'), logSha256: sha(readFileSync(logPath)) };
  report.commands.push(result);
  writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(result));
}
report.completedAt = stamp();
report.inputsAfter = collectBuildInputs(root);
report.observedInputsUnchanged = JSON.stringify(before) === JSON.stringify(report.inputsAfter);
report.revisionAfter = observe('git', ['rev-parse', 'HEAD']);
report.allCommandsPassed = report.commands.every(item => item.exitCode === 0);
writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ report: path.relative(root, reportPath), allCommandsPassed: report.allCommandsPassed,
  observedInputsUnchanged: report.observedInputsUnchanged, sourceTreeHash: before.sourceTreeHash, reportSha256: sha(readFileSync(reportPath)) }));
if (!report.allCommandsPassed || !report.observedInputsUnchanged) process.exitCode = 1;
