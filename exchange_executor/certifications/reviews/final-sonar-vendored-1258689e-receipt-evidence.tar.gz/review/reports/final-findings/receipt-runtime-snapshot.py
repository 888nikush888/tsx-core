"""Read runtime commitments only; never alter an operative receipt or pin."""
import importlib.metadata
import json
from pathlib import Path
import sqlite3
import sys

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / 'exchange_executor'))
import ccxt
from ccxt_certification_evidence import expected_profile_hash, python_tree_hash
from ccxt_profiles import PROFILES

if sys.version_info[:2] != (3, 12) or ccxt.__version__ != '4.5.75':
    raise ValueError('Runtime does not match the pinned Python/CCXT contract')
sdk = Path(ccxt.__file__).resolve().parent
print(json.dumps({
    'python': sys.version,
    'pythonExecutable': str(Path(sys.executable).resolve()),
    'ccxt': ccxt.__version__,
    'sdkRoot': str(sdk),
    'executorTreeHash': python_tree_hash(root / 'exchange_executor'),
    'sdkTreeHash': python_tree_hash(sdk, sdk=True),
    'profileHash': expected_profile_hash(PROFILES['hyperliquid']),
    'pythonSqliteVersion': sqlite3.sqlite_version,
    'coverageVersion': importlib.metadata.version('coverage'),
}))
