"""Unadopted receipt-helper safety candidate. No receipt or authority writes."""
import os
from pathlib import Path
import stat

GROUPS = ('foundation', 'backend', 'python', 'frontend', 'build', 'browser', 'mutations', 'dependencies')

def require(condition, message):
    if not condition:
        raise ValueError(message)

def plain_local(root, value):
    root = Path(root)
    original = Path(value)
    require('..' not in original.parts, 'Parent traversal in evidence path')
    candidate = original if original.is_absolute() else root / original
    candidate = Path(os.path.abspath(candidate))
    require(candidate.is_relative_to(root), 'Evidence path leaves repository')
    # lstat every lexical component before resolve: includes Windows junctions.
    current = Path(candidate.anchor)
    parts = candidate.parts[1:]
    for index, part in enumerate(parts):
        current /= part
        meta = current.lstat()
        require(not stat.S_ISLNK(meta.st_mode) and not getattr(meta, 'st_file_attributes', 0) & 0x400,
                'Symlink/reparse component in evidence path')
        if index < len(parts) - 1:
            require(stat.S_ISDIR(meta.st_mode), 'Non-directory evidence ancestor')
        else:
            require(stat.S_ISREG(meta.st_mode) and meta.st_nlink == 1, 'Non-ordinary evidence file')
    require(candidate.resolve(strict=True) == candidate, 'Non-canonical evidence path')
    return candidate

def executable(value):
    return os.path.normcase(os.path.abspath(value))

def expected_commands(root, node):
    root = Path(root)
    npm = str(Path(node).parent / 'node_modules/npm/bin/npm-cli.js')
    python = str(root.parent / 'tsx-security-python-env/Scripts/python.exe')
    def task(name, script):
        return (name, node, [npm, 'run', script])
    foundation = ['lint', 'lint:frontend', 'lint:python', 'typecheck', 'quality:architecture',
                  'quality:complexity', 'quality:frontend', 'quality:release', 'quality:risk-acceptances',
                  'quality:monitoring', 'quality:build-context', 'quality:licenses', 'quality:dependencies',
                  'quality:duplicates']
    return {
        'foundation': [task(s.replace(':', '-'), s) for s in foundation],
        'backend': [task('backend-coverage', 'test:coverage'), task('backend-module-coverage', 'test:coverage:modules')],
        'python': [('python-coverage', python, ['-B', '-m', 'coverage', 'run', '--branch', '--source=exchange_executor', '-m', 'unittest', 'discover', '-s', 'exchange_executor/tests', '-v']),
                   ('python-coverage-report', python, ['-m', 'coverage', 'report', '--fail-under=60']),
                   ('python-coverage-xml', python, ['-m', 'coverage', 'xml', '-o', 'exchange_executor/coverage.xml'])],
        'frontend': [('frontend-coverage', node, [npm, '--prefix', 'frontend', 'run', 'test:coverage'])],
        'build': [task('build', 'build')],
        'browser': [('browser', node, [npm, '--prefix', 'frontend', 'run', 'test:e2e', '--', '--workers=2'])],
        'mutations': [('mutations', node, [npm, 'run', 'test:mutation', '--', '--force'])],
        'dependencies': [('npm-audit-backend', node, [npm, 'audit', '--audit-level=moderate']),
                         ('npm-audit-frontend', node, [npm, '--prefix', 'frontend', 'audit', '--audit-level=moderate']),
                         task('sbom', 'quality:sbom')],
        # Exact previously supported bounded native replacement; never an extra required group.
        'monitoring-native': [('promtool-version', 'C:/Users/nikla/AppData/Local/tsx-core-dev-runtime/quality-tools/prometheus-3.13.2/promtool.exe', ['--version']),
                              ('amtool-version', 'C:/Users/nikla/AppData/Local/tsx-core-dev-runtime/quality-tools/alertmanager-0.33.1/amtool.exe', ['--version']),
                              ('configuration-and-rules', node, ['scripts/check_monitoring.js'])],
    }

def check_command_inventory(execution, root, node, allow_native=False):
    group = execution.get('group')
    require(group in GROUPS or allow_native and group == 'monitoring-native', 'Unexpected verification group')
    expected = expected_commands(root, node)[group]
    commands = execution.get('commands', [])
    require(len(commands) == len(expected), 'Missing/extra verification commands')
    npm = str(Path(node).parent / 'node_modules/npm/bin/npm-cli.js')
    def args_normalized(values):
        values = list(values)
        if values and executable(values[0]) == executable(npm):
            values[0] = executable(values[0])
        return values
    for actual, (name, command, args) in zip(commands, expected):
        require(actual['name'] == name and executable(actual['command']) == executable(command)
                and args_normalized(actual['args']) == args_normalized(args), 'Verification command identity/arguments differ')

def check_group_inventory(executions):
    require([e['group'] for e in executions] == list(GROUPS), 'Exactly eight ordered verification groups required')

def historical_archive_for_queue(root, out, binding):
    # Include opaque nested archive bytes; never reinterpret historical source bindings.
    archive = plain_local(root, binding['archive']['path'])
    return archive if archive.is_relative_to(out) else None
