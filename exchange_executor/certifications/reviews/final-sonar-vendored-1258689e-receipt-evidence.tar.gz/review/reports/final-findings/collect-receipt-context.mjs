import fs from 'node:fs';
import cp from 'node:child_process';
import crypto from 'node:crypto';
import path from 'node:path';
import { createRequire } from 'node:module';
import { collectBuildInputs } from '../../scripts/verify_exchange_implementation.js';

const [tag, expectedRevision, pythonArgument] = process.argv.slice(2);
if (!/^[a-zA-Z0-9_-]+$/.test(tag ?? '') || !/^[a-f0-9]{40}$/.test(expectedRevision ?? '')) {
  throw Error('Usage: node collect-receipt-context.mjs <unique-tag> <frozen-sha> [absolute-python]');
}
const root = process.cwd();
const python = pythonArgument ?? path.resolve(root, '../tsx-security-python-env/Scripts/python.exe');
if (!path.isAbsolute(python)) throw Error('Python must be absolute');
const output = `reports/final-findings/receipt-context-${tag}.json`;
if (fs.existsSync(output)) throw Error('Refusing to overwrite a prior context observation');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const run = (exe, args, options = {}) => cp.execFileSync(exe, args, { cwd: root, windowsHide: true, ...options });
const revision = () => run('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
const startedAt = new Date().toISOString();
if (revision() !== expectedRevision) throw Error('Unexpected frozen revision');
const inputs = collectBuildInputs(root);
const batch = run('git', ['cat-file', '--batch'], { input: inputs.files.map(row => `${expectedRevision}:${row.path}\n`).join(''), maxBuffer: 128 * 1024 * 1024 });
let position = 0;
for (const row of inputs.files) {
  const end = batch.indexOf(10, position);
  const header = batch.subarray(position, end).toString('utf8').split(' ');
  const size = Number(header[2]);
  if (header[1] !== 'blob' || !Number.isSafeInteger(size) || size < 0) throw Error(`Missing frozen Git input: ${row.path}`);
  const bytes = batch.subarray(end + 1, end + 1 + size);
  position = end + 2 + size;
  if (sha(bytes) !== row.sha256 || sha(fs.readFileSync(row.path)) !== row.sha256 || fs.statSync(row.path).nlink !== 1) throw Error(`Input mismatch: ${row.path}`);
}
const runtime = JSON.parse(run(python, ['-I', '-B', 'reports/final-findings/receipt-runtime-snapshot.py', root], { encoding: 'utf8', maxBuffer: 4 * 1024 * 1024 }));
const require = createRequire(path.join(root, 'package.json'));
const sqlite = require('sqlite3');
const nativeModules = Object.keys(require.cache).filter(p => p.endsWith('.node')).map(p => ({ path: p, sha256: sha(fs.readFileSync(p)), singleLink: fs.statSync(p).nlink === 1 }));
const sqliteVersion = await new Promise((resolve, reject) => {
  const db = new sqlite.Database(':memory:', error => {
    if (error) return reject(error);
    db.get('SELECT sqlite_version() AS version', (failure, row) => db.close(closeError => failure || closeError ? reject(failure ?? closeError) : resolve(row.version)));
  });
});
runtime.node = process.version;
runtime.nodeExecutable = process.execPath;
runtime.npm = run(process.execPath, [path.join(path.dirname(process.execPath), 'node_modules/npm/bin/npm-cli.js'), '--version'], { encoding: 'utf8' }).trim();
runtime.nodeSqlite = { packageVersion: require('sqlite3/package.json').version, wrapperVersion: JSON.parse(fs.readFileSync(path.join(root, 'node_modules/sqlite/package.json'), 'utf8')).version, runtimeVersion: sqliteVersion, nativeModules };
const after = collectBuildInputs(root);
if (JSON.stringify(after) !== JSON.stringify(inputs) || revision() !== expectedRevision) throw Error('Context changed during capture');
const report = { schemaVersion: 1, kind: 'actual-receipt-context-observation', startedAt, observedAt: new Date().toISOString(), revision: expectedRevision,
  inputs, runtime, rawEqualsGit: true, allInputsSingleLink: true, sourceStableDuringCapture: true,
  providerAcceptanceVerified: false, performedGateExecution: false,
  collector: { path: 'reports/final-findings/collect-receipt-context.mjs', sha256: sha(fs.readFileSync('reports/final-findings/collect-receipt-context.mjs')) },
  runtimeCollector: { path: 'reports/final-findings/receipt-runtime-snapshot.py', sha256: sha(fs.readFileSync('reports/final-findings/receipt-runtime-snapshot.py')) } };
fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ path: output, sha256: sha(fs.readFileSync(output)), revision: expectedRevision, inputCount: inputs.files.length, sourceTreeHash: inputs.sourceTreeHash,
  executorTreeHash: runtime.executorTreeHash, sdkTreeHash: runtime.sdkTreeHash, rawEqualsGit: true }));
