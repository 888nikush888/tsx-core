"""Seal new review evidence deterministically; never change receipt or authority."""
import argparse
import importlib.util
import subprocess
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

from receipt_renewal_safety_candidate import plain_local, historical_archive_for_queue

ROOT = Path.cwd().resolve()
REVISION='d74f2ae68722a1a86f71af6c1a872dd4cfbf3f0d'
TAG='final-snyk-deps-d74f2ae6'
OUT = ROOT / 'reports/final-findings'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def local(relative):
    return plain_local(ROOT, relative)

def historical(binding):
    a = local(binding['archive']['path'])
    require(sha(a.read_bytes()) == binding['archive']['sha256'], 'Historical archive changed')
    with tarfile.open(a) as archive:
        members=archive.getmembers()
        require(len(members)<=20000 and len({m.name for m in members})==len(members),'Ambiguous historical archive inventory')
        require(not binding['member'].startswith('/') and '..' not in Path(binding['member']).parts and '\\' not in binding['member'],'Invalid historical member path')
        item = archive.getmember(binding['member'])
        require(item.isfile() and not item.issym() and not item.islnk(), 'Historical reference is not an ordinary member')
        raw = archive.extractfile(item).read()
    require(sha(raw) == binding['sha256'], 'Historical member changed')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--revision', required=True)
    parser.add_argument('--source-review-sha256', required=True)
    parser.add_argument('--validator-sha256', required=True)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    require(args.revision==REVISION, 'Only exact frozen d74f2ae6 archive allowed')
    require(re.fullmatch('[a-f0-9]{64}',args.source_review_sha256), 'Reviewed source hash required')
    require(re.fullmatch('[a-f0-9]{64}',args.validator_sha256), 'Independent validator hash required')
    require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==REVISION, 'Frozen revision changed')
    validator_path=local(OUT/'validate-independent-receipt-snyk-d74f2ae6.py')
    require(sha(validator_path.read_bytes())==args.validator_sha256,'Independent validator changed')
    spec=importlib.util.spec_from_file_location('independent312c',validator_path)
    validator=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    validator.configure(args.revision,args.source_review_sha256)
    validator.check_operative_unchanged()
    state_path = OUT / f'{TAG}-receipt-candidate-state.json'
    review_path = OUT / f'{TAG}-independent-receipt-review.json'
    approval_path = OUT / f'{TAG}-receipt-adoption-approval.json'
    state, review, approval = [json.loads(local(p).read_bytes()) for p in (state_path, review_path, approval_path)]
    require(state['revision']==REVISION and state['completeSourceReview']['sha256']==args.source_review_sha256,'Wrong frozen review/source')
    require(review['reviewValidator']==validator.ref(validator_path),'Independent review used a different validator')
    closure=validator.reference_closure(state_path)
    require(closure==review['referenceClosure'],'Reference graph differs from independent review')
    execution=validator.read(validator.bound(state['execution']))
    inputs=validator.check_execution_groups(execution)
    validator.check_exact_source_and_rows(validator.read(validator.bound(state['completeSourceReview'])),inputs,validator.read(validator.bound(state['parity'])),state)
    require(review['candidate'] == approval['candidate'] == state['candidate'], 'Review and approval do not bind this candidate')
    require(review['revision'] == approval['revision'] == state['revision'], 'Review revision mismatch')
    require(review['referenceClosure']['unresolvedReferences'] == 0 and review['checks']['productionPythonValidation'] == 'PASS', 'Independent runtime/reference review missing')
    comparison = review['checks']['productionNodeComparison']
    require(comparison['buildInputsMatch'] is True and comparison['implementationVerified'] is False, 'Production comparison missing or authority overstated')
    require(approval['approved'] is True, 'Explicit bounded root adoption approval missing')
    require(state['operativeReceiptApproved'] is False and state['operativeReceiptOrPinsChanged'] is False, 'Candidate authority status invalid')
    queue = [state_path, review_path, approval_path, Path(__file__).absolute(), Path(__file__).with_name("receipt_renewal_safety_candidate.py").absolute()]
    included, inherited, references = {}, {}, {}

    def walk(value):
        if isinstance(value, list):
            for child in value:
                walk(child)
        elif isinstance(value, dict):
            if isinstance(value.get('path'),str) and value['path'].startswith('review/') and isinstance(value.get('sha256'),str):
                explicit=validator.sealed_bare_member(value)
                walk(explicit)
                return
            if isinstance(value.get('archive'), dict) and isinstance(value.get('member'), str) and isinstance(value.get('sha256'), str):
                historical(value)
                opaque = historical_archive_for_queue(ROOT, OUT, value)
                if opaque is not None:
                    queue.append(opaque)
                key = value['archive']['path'] + ':' + value['member']
                inherited[key] = value
                return  # Preserve sealed historical context; never rebind old source to current files.
            if isinstance(value.get('path'), str) and re.fullmatch('[a-f0-9]{64}', str(value.get('sha256', ''))):
                p = local(value['path'])
                require(sha(p.read_bytes()) == value['sha256'], 'Current reference changed: ' + value['path'])
                references[value['path']] = {'path': value['path'], 'sha256': value['sha256']}
                if p.is_relative_to(OUT):
                    queue.append(p)
            if isinstance(value.get('log'), str) and isinstance(value.get('logSha256'), str):
                walk({'path': value['log'], 'sha256': value['logSha256']})
            for child in value.values():
                walk(child)

    while queue:
        p = local(queue.pop())
        require(p.is_relative_to(OUT), 'Only new ignored report evidence may be included')
        relative = p.relative_to(ROOT).as_posix()
        if relative in included:
            continue
        require(len(included)<20000 and p.stat().st_size<=256*1024*1024,'Evidence inventory budget exceeded')
        raw = p.read_bytes()
        included[relative] = raw
        if p.suffix == '.json':
            walk(json.loads(raw))

    manifest = {'schemaVersion': 1, 'sourceRevision': state['revision'],
        'scope': 'New offline execution/review evidence; tracked source remains bound to the frozen Git revision. Prior archive members keep their historical context.',
        'files': [{'path': p, 'member': 'review/' + p, 'sha256': sha(raw), 'bytes': len(raw)} for p, raw in sorted(included.items())],
        'verifiedCurrentReferences': [references[k] for k in sorted(references)], 'inheritedExactReferences': [inherited[k] for k in sorted(inherited)],
        'unresolvedReferences': [], 'providerAcceptanceVerified': False, 'operativeReceiptOrPinsChanged': False}
    manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
    payload = {'manifest.json': manifest_raw, **{'review/' + p: b for p, b in sorted(included.items())}}

    def pack():
        plain = io.BytesIO()
        with tarfile.open(fileobj=plain, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name, raw in payload.items():
                item = tarfile.TarInfo(name)
                item.size, item.mode = len(raw), 0o444
                item.uid = item.gid = item.mtime = 0
                item.uname = item.gname = ''
                archive.addfile(item, io.BytesIO(raw))
        compressed = io.BytesIO()
        with gzip.GzipFile(filename='', fileobj=compressed, mode='wb', mtime=0, compresslevel=9) as handle:
            handle.write(plain.getvalue())
        return compressed.getvalue()

    raw = pack()
    require(raw == pack(), 'Archive is not reproducible byte-for-byte')
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        require(len(archive.getmembers()) == len(payload), 'Archive member inventory mismatch')
        for member in archive.getmembers():
            require(member.isfile() and member.mtime == 0 and archive.extractfile(member).read() == payload[member.name], 'Archive read-back mismatch')
    for p, content in included.items():
        require(local(p).read_bytes() == content, 'Evidence changed during archive creation')
    for binding in references.values():
        require(sha(local(binding['path']).read_bytes()) == binding['sha256'], 'Current reference changed during archive creation')
    for binding in inherited.values():
        historical(binding)
    validator.check_operative_unchanged()
    require(validator.head()==REVISION and validator.reference_closure(state_path)==closure,'Final revision/reference drift')
    require(validator.check_execution_groups(execution)==inputs,'Final execution source drift')
    if args.dry_run:
        print(json.dumps({'dryRun':True,'wouldArchiveSha256':sha(raw),'files':len(included),'everyMemberReadBack':True,'doubleBuildByteIdentical':True,'archiveCreated':False}))
        return
    output = OUT / f'{TAG}-receipt-evidence.tar.gz'
    manifest_path = OUT / f'{TAG}-receipt-evidence-manifest.json'
    require(not output.exists() and not manifest_path.exists(), 'Refusing to overwrite an evidence archive')
    with output.open('xb') as handle:
        handle.write(raw)
    with manifest_path.open('xb') as handle:
        handle.write(manifest_raw)
    print(json.dumps({'archive': output.relative_to(ROOT).as_posix(), 'sha256': sha(raw), 'manifest': manifest_path.relative_to(ROOT).as_posix(),
        'manifestSha256': sha(manifest_raw), 'files': len(included), 'doubleBuildByteIdentical': True, 'everyMemberReadBack': True, 'unresolvedReferences': 0,
        'operativeReceiptOrPinsChanged': False}))

if __name__ == '__main__':
    main()
