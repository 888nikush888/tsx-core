"""Future independent receipt review only. Never installs a receipt or changes pins.
Next target remains unbound until exact final revision and root source-review hash are pinned; then refuses before all eight complete passing groups and candidate.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
from receipt_renewal_safety_candidate import plain_local, check_command_inventory, check_group_inventory

ROOT=Path.cwd().resolve();OUT=ROOT/'reports/final-findings'
TAG='final-snyk-deps-d74f2ae6'
REVISION='d74f2ae68722a1a86f71af6c1a872dd4cfbf3f0d'
FROZEN_TREE='ba9cf9697874d2e8f5bf32645bdd5360ac2f43eccab8399cfaed2b0383effbf6'
SOURCE_REVIEW_HASH=None
ORIGINAL_RECEIPT_HASH='90dd3f4ec6ad9774c11f8d47631a5d4cb07ef9ce7729555daf1cec8793be4ae9'
ORIGINAL_AUTHORITY_HASH='51c9a02327de70ced52802fb290ecf47a6a2030ae8db422626344e985939d563'
NODE='C:/Users/nikla/AppData/Local/Programs/node22/node-v22.23.2-win-x64/node.exe'
PYTHON=str(ROOT.parent/'tsx-security-python-env/Scripts/python.exe')
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def configure(revision, source_review_hash):
 global SOURCE_REVIEW_HASH
 require(revision==REVISION,'Exact frozen d74f2ae6 revision required')
 require(isinstance(source_review_hash,str) and len(source_review_hash)==64
         and all(c in '0123456789abcdef' for c in source_review_hash),
         'Exact reviewed source hash required')
 SOURCE_REVIEW_HASH=source_review_hash

def require(ok,reason):
 if not ok:raise ValueError(reason)
def unique(pairs):
 result={}
 for key,value in pairs:
  require(key not in result,'Duplicate JSON key');result[key]=value
 return result
def parse(raw):
 def bad(value):raise ValueError('Nonfinite JSON value: '+value)
 return json.loads(raw.decode('utf-8-sig'),object_pairs_hook=unique,parse_constant=bad)
def file_bytes(path):
 p=plain_local(ROOT,path);require(p.stat().st_size<=256*1024*1024,'Evidence file budget exceeded');return p.read_bytes()
def read(path):return parse(file_bytes(path))
def ref(path):
 p=plain_local(ROOT,path);return {'path':p.relative_to(ROOT).as_posix(),'sha256':sha(file_bytes(p))}
def bound(binding):
 require(set(binding)=={'path','sha256'},'Reference schema differs')
 canonical=plain_local(ROOT,binding['path'])
 require(ref(canonical)['sha256']==binding['sha256'],'Current reference bytes differ')
 return canonical
def time(value):return datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
def head():return subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def check_operative_unchanged():
 require(sha(file_bytes(ROOT/'exchange_executor/certifications/hyperliquid.json'))==ORIGINAL_RECEIPT_HASH,'Operative receipt changed before review')
 require(sha(file_bytes(ROOT/'exchange_executor/ccxt_implementation_reviews.py'))==ORIGINAL_AUTHORITY_HASH,'Operative approval pins changed before review')

def sealed_bare_member(binding):
 require(set(binding)=={'path','sha256'},'Unexpected bare historical reference fields')
 boundaries={
  **{'review/reports/final-findings/'+name:(ROOT/'exchange_executor/certifications/reviews/final-28cfa93-receipt-evidence.tar.gz','5d317742422c39866f22623fc114c30a16921c16a7cefb61f21f7c9dca116bc4') for name in ('final-28cfa93-receipt-source-review-root.json','receipt-context-final-28cfa93-after.json','final-28cfa93-receipt-parity-supplement.json')},
  **{'review/reports/final-findings/'+name:(ROOT/'exchange_executor/certifications/reviews/final-312c5a36-receipt-evidence.tar.gz','27d8b1672721cfe9fab7bd8038bdd4f478f9acf198ea31d22163cd400c4d1975') for name in ('final-312c5a36-receipt-source-review-root.json','receipt-context-final-312c5a36-after.json','final-312c5a36-receipt-parity-supplement.json')},
  **{'review/reports/final-findings/'+name:(PRIOR_ARCHIVE,PRIOR_ARCHIVE_HASH) for name in ('final-dd747eba-receipt-source-review-root.json','receipt-context-final-dd747eba-after.json','final-dd747eba-receipt-parity-supplement.json')},
 }
 require(binding['path'] in boundaries,'Unrecognized bare historical provenance member')
 archive_path,archive_hash=boundaries[binding['path']]
 require(sha(file_bytes(archive_path))==archive_hash,'Bare member archive changed')
 with tarfile.open(archive_path) as archive:
  members=archive.getmembers()
  require(len(members)<=20000 and len({m.name for m in members})==len(members),'Ambiguous sealed archive')
  item=archive.getmember(binding['path'])
  require(item.isfile() and not item.issym() and not item.islnk() and item.size<=64*1024*1024,'Nonordinary bare historical member')
  require(sha(archive.extractfile(item).read())==binding['sha256'],'Bare historical member hash differs')
 return {'archive':{'path':archive_path.relative_to(ROOT).as_posix(),'sha256':archive_hash},'member':binding['path'],'sha256':binding['sha256']}

def reference_closure(state_path):
 queue=[plain_local(ROOT,state_path)];visited={};current={};historical={};opaque={}
 def walk(value):
  if isinstance(value,list):
   for child in value:walk(child)
  elif isinstance(value,dict):
   if isinstance(value.get('path'),str) and value['path'].startswith('review/') and isinstance(value.get('sha256'),str):
    explicit=sealed_bare_member(value)
    historical[explicit['archive']['path']+':'+explicit['member']]=explicit
    return
   if isinstance(value.get('archive'),dict) and isinstance(value.get('member'),str) and isinstance(value.get('sha256'),str):
    archive=bound(value['archive']);member=value['member'];member_path=PurePosixPath(member)
    require(not member_path.is_absolute() and '..' not in member_path.parts and '\\' not in member,'Invalid historical member path')
    with tarfile.open(archive,'r:*') as handle:
     members=handle.getmembers();require(len(members)<=20000 and len({m.name for m in members})==len(members),'Historical archive ambiguous or over budget')
     item=handle.getmember(member);require(item.isfile() and not item.issym() and not item.islnk() and item.size<=64*1024*1024,'Invalid historical member')
     raw=handle.extractfile(item).read();require(sha(raw)==value['sha256'],'Historical member hash differs')
    historical[value['archive']['path']+':'+member]=value
    if archive.is_relative_to(OUT):opaque[value['archive']['path']]=value['archive']
    return # Old embedded source paths stay in their sealed historical context.
   if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
    require(len(value['sha256'])==64 and all(c in '0123456789abcdef' for c in value['sha256']),'Invalid SHA reference')
    binding={'path':value['path'],'sha256':value['sha256']};p=bound(binding);current[binding['path']]=binding
    if p.is_relative_to(OUT):queue.append(p)
   if isinstance(value.get('log'),str) and isinstance(value.get('logSha256'),str):walk({'path':value['log'],'sha256':value['logSha256']})
   for child in value.values():walk(child)
 while queue:
  p=queue.pop();relative=p.relative_to(ROOT).as_posix()
  if relative in visited:continue
  require(len(visited)<20000,'Current reference graph exceeds budget');raw=file_bytes(p);visited[relative]=sha(raw)
  if p.suffix=='.json':walk(parse(raw))
 for relative,digest in visited.items():require(sha(file_bytes(ROOT/relative))==digest,'Evidence changed during reference walk')
 for binding in current.values():bound(binding)
 for binding in opaque.values():bound(binding)
 return {'unresolvedReferences':0,'currentReports':len(visited),'currentReferences':len(current),'historicalMembers':len(historical),'verifiedCurrentReferences':list(current.values()),'inheritedExactReferences':list(historical.values()),'opaqueIgnoredArchivesToInclude':list(opaque.values()),'historicalContextRebound':False}

def check_execution_groups(execution):
 require(execution['revision']==REVISION and execution['providerAcceptanceVerified'] is False and execution['pythonExecutionInheritance'] is False,'Execution scope differs')
 groups=execution['groups'];check_group_inventory(groups)
 before=read(bound(execution['beforeContext']));after=read(bound(execution['afterContext']))
 require(before['revision']==after['revision']==REVISION and before['inputs']==after['inputs'],'Final contexts differ')
 require(before['runtime']==after['runtime']==execution['runtime'],'Runtime context differs')
 require(all(c['rawEqualsGit'] and c['allInputsSingleLink'] and c['sourceStableDuringCapture'] for c in [before,after]),'Incomplete source proof')
 for group in groups:
  actual=read(bound(group['report']));check_command_inventory(actual,ROOT,NODE)
  require(group['report']['path']==f"reports/final-findings/verification-{group['group']}-d74f2ae6.json",
          'Only d74f2ae6 verification reports may be selected')
  require(actual['group']==group['group'] and actual.get('completedAt') and actual['observedInputsUnchanged'] is True,'Group missing completion/source stability')
  require(actual['allCommandsPassed'] is True and all(type(c['exitCode']) is int and c['exitCode']==0 and c.get('signal') is None and not c.get('error') for c in actual['commands']),'All eight selected groups must be terminal green')
  require(actual['revision']==actual['revisionAfter']==REVISION and actual['inputsBefore']==actual['inputsAfter']==before['inputs'],'Group source differs')
  require(actual['runtime']['node']==before['runtime']['node'] and actual['runtime']['ccxt']==before['runtime']['ccxt'] and actual['runtime']['python']=='Python '+before['runtime']['python'].split()[0],'Group runtime differs')
  require(time(before['observedAt'])<=time(actual['startedAt'])<=time(actual['completedAt'])<=time(after['startedAt']),'Group outside frozen window')
  require(not group['reviewedReplacements'],'This final review requires eight directly passing selected groups; replacement needs separate explicit review')
  require(not group.get('preservedEarlierAttempts') and group.get('attemptSelection') is None,
          'Historical 11107ca5 attempts must not be rebound as d74f2ae6 evidence')
  for c in actual['commands']:
   require(c['log']==f"reports/final-findings/verification-{c['name']}-d74f2ae6.log",
           'Historical verification log cannot be rebound as d74f2ae6 evidence')
   bound({'path':c['log'],'sha256':c['logSha256']});require(time(actual['startedAt'])<=time(c['startedAt'])<=time(c['completedAt'])<=time(actual['completedAt']),'Command time outside group')
  if group['group']=='foundation':
   monitoring=actual['monitoringExecution'];tools=monitoring['tools']
   require(monitoring['mode']=='native-configuration-only'
           and monitoring['containerAcceptanceVerified'] is False
           and [tool['key'] for tool in tools]==['PROMTOOL_PATH','AMTOOL_PATH'],
           'Foundation report lacks two exact native monitoring tools')
   for tool in tools:
    executable=Path(tool['executable'])
    require(executable.is_absolute() and executable.is_file() and not executable.is_symlink()
            and executable.stat().st_nlink==1 and executable.stat().st_size<=128*1024*1024
            and sha(executable.read_bytes())==tool['sha256'] and tool['version'].strip(),
            'Native monitoring tool bytes or version differ')
 return before['inputs']

PYTHON_CODE=r'''
import json,sys
from pathlib import Path
root=Path(sys.argv[1]);candidate=Path(sys.argv[2]);pin=sys.argv[3]
sys.path.insert(0,str(root/'exchange_executor'))
import ccxt
from ccxt_certification_evidence import read_receipt,validate_receipt
from ccxt_profiles import PROFILES
value=read_receipt(candidate,(pin,)) # Ephemeral review-only comparison pin, never approval-root installation.
validate_receipt(value,'hyperliquid',ccxt.__version__,PROFILES['hyperliquid'],root/'exchange_executor',Path(ccxt.__file__).parent)
print(json.dumps({'validation':'PASS','implementationVerified':False,'providerAcceptanceVerified':False,'operativeReceiptOrPinsChanged':False}))
'''


PRIOR_ARCHIVE=ROOT/'exchange_executor/certifications/reviews/final-dd747eba-receipt-evidence.tar.gz'
PRIOR_ARCHIVE_HASH='14c56bc99618b7129fe3ca0f755871d92c68bfe3072f072b6af83f8ebda34849'
def sealed(name):
 require(sha(file_bytes(PRIOR_ARCHIVE))==PRIOR_ARCHIVE_HASH,'Sealed predecessor archive changed')
 with tarfile.open(PRIOR_ARCHIVE) as archive:
  item=archive.getmember('review/reports/final-findings/'+name)
  require(item.isfile() and not item.issym() and not item.islnk(),'Invalid sealed member')
  return parse(archive.extractfile(item).read())

def check_exact_source_and_rows(approval,inputs,parity,state):
 # Independent recomputation, not trust in the preparing helper's counts.
 prior=sealed('receipt-context-final-dd747eba-after.json')
 old={r['path']:r['sha256'] for r in prior['inputs']['files']}
 current={r['path']:r['sha256'] for r in inputs['files']}
 require(len(current)==len(inputs['files'])==1002 and inputs['sourceTreeHash']==FROZEN_TREE,
         'Frozen d74f2ae6 source inventory differs')
 actual=json.loads(subprocess.check_output([NODE,'--input-type=module','-e',"import {collectBuildInputs} from './scripts/verify_exchange_implementation.js';console.log(JSON.stringify(collectBuildInputs(process.cwd())));"],text=True))
 require(actual==inputs,'Actual current collector differs from execution contexts')
 delta=[{'path':p,'beforeSha256':old.get(p),'currentSha256':current.get(p),'status':'modified' if p in old and p in current else 'added' if p in current else 'removed'} for p in sorted(set(old)|set(current)) if old.get(p)!=current.get(p)]
 require({row['path'] for row in delta}=={
  'docs/testing/final-findings-followup-2026-09-20.md',
  'frontend/package-lock.json','frontend/package.json','frontend/public/licenses/shadcn-MIT.txt',
  'frontend/src/index.css','frontend/src/styles/shadcn-tailwind.css','package-lock.json','package.json'
 },'Exact eight d74f2ae6 source deltas differ')
 delta_doc=read(bound(approval['deltas']))
 require(delta_doc['revision']==REVISION and delta_doc['deltas']==delta and len(delta)>0,'Exact predecessor-to-current delta differs')
 review={r['path']:r for r in approval['reviews']}
 require(approval['revision']==REVISION and approval['providerAcceptanceVerified'] is False,'Root source review scope differs')
 require(len(review)==len(approval['reviews'])==len(delta) and set(review)=={r['path'] for r in delta},'Root review does not cover exact eight deltas')
 for row in delta:
  checked=review[row['path']]
  require(all(checked[k]==v for k,v in row.items()) and checked['reviewed'] is True and checked['rationale'].strip() and checked['evidence'],'Invalid individual source assessment')
 previous=sealed('final-dd747eba-receipt-parity-supplement.json')
 require(parity['priorParity']=={'archive':{'path':PRIOR_ARCHIVE.relative_to(ROOT).as_posix(),'sha256':PRIOR_ARCHIVE_HASH},'member':'review/reports/final-findings/final-dd747eba-receipt-parity-supplement.json','sha256':'80190e30f42261a99cf437c63323fbd187f30f52a39b772c0ba4380aa0a20a95'},'Wrong sealed prior parity boundary')
 oldrows={(r['category'],r['check']):r for r in previous['rows']}
 newrows={(r['category'],r['check']):r for r in parity['rows']}
 require(set(oldrows)==set(newrows),'Requirement identities changed')
 for key,row in newrows.items():
  require(all(set(w)=={'path','sha256'} for w in row['witnessBindings']),'Current witness contains unexpected fields')
  original_pairs=[{'path':w['path'],'sha256':w['sha256']} for w in oldrows[key]['witnessBindings']]
  require(row['witnessBindings']==original_pairs,'Original witness path/hash/order changed')
  require(row['sealedPriorRow']['evidence']==parity['priorParity'],'Historical witness metadata boundary differs')
  for w in row['witnessBindings']:require(current[w['path']]==w['sha256'],'Witness differs from current inputs')
  require(row['sealedPriorRow']['lookup']=={'category':key[0],'check':key[1]},'Historical row lookup differs')
 require(parity['operativeReceiptApproved'] is False,'Parity overclaims approval')
 for group in read(bound(state['execution']))['groups']:
  require(group['report']['path']==f"reports/final-findings/verification-{group['group']}-d74f2ae6.json",'Noncurrent execution report selected')
  require(not group.get('preservedEarlierAttempts') and group.get('attemptSelection') is None,'Attempt replacement not authorized for this renewal')
 return {'actualInputs':len(current),'independentlyRecomputedDeltas':len(delta),'sealedExactRequirementIdentities':62,'sealedExactWitnessReferences':97}

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--revision',required=True)
 parser.add_argument('--source-review-sha256',required=True)
 args=parser.parse_args()
 configure(args.revision,args.source_review_sha256)
 require(head()==REVISION,'Wrong frozen HEAD');check_operative_unchanged()
 state_path=OUT/f'{TAG}-receipt-candidate-state.json'
 require(state_path.exists(),'No candidate exists; no review or authority output created')
 state=read(state_path);require(state['revision']==REVISION and state['operativeReceiptApproved'] is False and state['operativeReceiptOrPinsChanged'] is False,'Candidate already claims authority')
 review_path=bound(state['completeSourceReview']);require(state['completeSourceReview']['sha256']==SOURCE_REVIEW_HASH,'Wrong root source approval')
 approval=read(review_path)
 require(approval['reviewed'] is True and approval['providerAcceptanceVerified'] is False
         and len(approval['reviews'])==8 and all(row['reviewed'] is True and row['rationale'].strip() and row['evidence'] for row in approval['reviews']),
         'Complete explicit source semantics approval missing')
 execution=read(bound(state['execution']));inputs=check_execution_groups(execution)
 parity=read(bound(state['parity']));require(parity['revision']==REVISION and parity['providerAcceptanceVerified'] is False,'Parity scope differs')
 rows=parity['rows'];require(len(rows)==62 and len({(r['category'],r['check']) for r in rows})==62 and sum(len(r['witnessBindings']) for r in rows)==97 and len({w['path'] for r in rows for w in r['witnessBindings']})==30,'Requirement/witness inventory differs')
 require(parity['counts']['changedWitnessReferences']==0 and parity['counts']['unchangedWitnessReferences']==97,'Original witnesses must remain unchanged')
 for row in rows:require(row['completeSourceReview']==state['completeSourceReview'] and row['currentExecution']==state['execution'],'Requirement review/execution binding differs')
 exact_review=check_exact_source_and_rows(approval,inputs,parity,state)
 candidate_path=bound(state['candidate']);candidate=read(candidate_path);prior=read(ROOT/'exchange_executor/certifications/hyperliquid.json')
 require(candidate['sourceRevision']==REVISION and candidate['parityEvidenceHash']==state['parity']['sha256'] and candidate['executionReportHash']==state['execution']['sha256'],'Candidate evidence commitments differ')
 for key in ['schemaVersion','kind','exchange','ccxtVersion','profileVersion','profileHash','scope','providerAcceptanceVerified']:require(candidate[key]==prior[key],'Receipt scope/identity expanded')
 closure=reference_closure(state_path)
 py=subprocess.run([PYTHON,'-I','-B','-c',PYTHON_CODE,str(ROOT),str(candidate_path),state['candidate']['sha256']],capture_output=True,text=True,check=True)
 py_result=parse(py.stdout.encode());require(py_result['validation']=='PASS' and py_result['implementationVerified'] is False,'Unexpected Python result')
 js="import fs from 'node:fs';import {compareBuildReceipt} from './scripts/verify_exchange_implementation.js';const r=compareBuildReceipt(fs.readFileSync("+json.dumps(str(candidate_path))+"),{root:process.cwd(),exchange:'hyperliquid',profileVersion:"+str(prior['profileVersion'])+",approvedReceiptHashes:["+json.dumps(state['candidate']['sha256'])+"]});console.log(JSON.stringify(r));"
 node=subprocess.run([NODE,'--input-type=module','-e',js],cwd=ROOT,capture_output=True,text=True,check=True);comparison=parse(node.stdout.encode())
 require(comparison['buildInputsMatch'] is True and comparison['sourceTreeHash']==inputs['sourceTreeHash'] and all(comparison[k] is False for k in ['implementationVerified','providerAcceptanceVerified','runtimeReceiptVerified','performedGateExecution']),'Build comparison overclaims verification')
 check_operative_unchanged();require(head()==REVISION,'HEAD changed during review');closure_after=reference_closure(state_path);require(closure==closure_after,'Reference graph changed during validation')
 result={'revision':REVISION,'candidate':state['candidate'],'completeSourceReview':state['completeSourceReview'],'reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exactSourceAndWitnessReview':exact_review,'checks':{'productionPythonValidation':'PASS','productionNodeComparison':comparison,'eightTerminalGreenGroups':True,'scopeUnchanged':True},'referenceClosure':closure,'reviewValidator':ref(Path(__file__).absolute()),'priorValidator':ref(OUT/'validate-independent-receipt-dd747eba.py'),'comparisonOnlyPin':{'candidateHash':state['candidate']['sha256'],'scope':'Explicit trusted-call test comparison only; not installed in operative approval root.'},'implementationVerified':False,'providerAcceptanceVerified':False,'operativeReceiptOrPinsChanged':False,'operativeReceiptApproved':False,'remaining':['Explicit bounded root adoption approval','Reviewed deterministic archive','Actual post-adoption production implementation gate and bridge regressions']}
 out=OUT/f'{TAG}-independent-receipt-review.json';require(not out.exists(),'Review evidence already exists')
 with out.open('x',encoding='utf-8',newline='\n') as handle:json.dump(result,handle,ensure_ascii=False,indent=2);handle.write('\n')
 print(json.dumps({'review':ref(out),'operativeReceiptOrPinsChanged':False,'implementationVerified':False,'providerAcceptanceVerified':False}))
if __name__=='__main__':main()
