"""Archive exact reviewed evidence under reports; never adopt receipt or pin."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT = Path.cwd().resolve()
OUT = ROOT / 'reports/findings-review'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tag', required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[a-zA-Z0-9_-]+', args.tag)
    included, inherited, references, seen = {}, {}, [], set()
    # Prior reports retain their sealed historical context. Never reinterpret
    # their source commitments as observations of the new test revision.
    prior_path = ROOT / 'exchange_executor/certifications/reviews/findings-1363d84-evidence.tar.gz'
    prior_hash = '9efd9edae65d5bb466cfcc1536b150148df778bf22b8626f323f59f93d69d853'
    assert sha(prior_path.read_bytes()) == prior_hash
    with tarfile.open(prior_path, 'r:gz') as prior_archive:
        prior_reports = {m.name.removeprefix('review/'): (m.name, prior_archive.extractfile(m).read())
                         for m in prior_archive.getmembers()
                         if m.isfile() and m.name.startswith('review/reports/findings-review/')}

    queue = [OUT / f'{args.tag}-receipt-candidate-state.json',
             OUT / f'{args.tag}-independent-receipt-review.json',
             OUT / f'{args.tag}-receipt-adoption-approval.json', Path(__file__).resolve(),
             OUT / 'audit-receipt-reference-closure.py', OUT / 'prepare-root-source-review.mjs',
             OUT / 'assemble-source-review.mjs']
    for p in queue:
        assert p.is_file(), p

    def local(relative):
        p = (ROOT / relative).resolve()
        assert p.is_relative_to(ROOT) and p.is_file(), relative
        return p

    def walk(value):
        if isinstance(value, list):
            for v in value:
                walk(v)
        elif isinstance(value, dict):
            # Archived JSON is evidence at its historical revision, not a set of
            # instructions to compare historical source hashes to current files.
            if isinstance(value.get('archive'), dict) and 'member' in value and 'sha256' in value:
                a = value['archive']
                p = local(a['path'])
                assert sha(p.read_bytes()) == a['sha256']
                with tarfile.open(p, 'r:gz') as archive:
                    member = archive.getmember(value['member'])
                    assert member.isfile()
                    raw = archive.extractfile(member).read()
                assert sha(raw) == value['sha256']
                inherited[(a['path'], value['member'])] = value
                references.append({'kind': 'historical-member', **value})
                return
            if isinstance(value.get('path'), str) and re.fullmatch(r'[a-f0-9]{64}', str(value.get('sha256', ''))):
                p = local(value['path'])
                assert sha(p.read_bytes()) == value['sha256'], value['path']
                references.append({'kind': 'current-file', 'path': value['path'], 'sha256': value['sha256']})
                if p.is_relative_to(OUT):
                    queue.append(p)
                elif p.suffixes[-2:] == ['.tar', '.gz']:
                    inherited[(value['path'], '')] = value
            for v in value.values():
                walk(v)
        elif isinstance(value, str):
            # Preserve raw logs/helpers explicitly named by reports even when
            # the containing report binds them using a differently named field.
            if value.startswith('reports/findings-review/') and '\n' not in value:
                p = ROOT / value
                if p.suffix in ('.json', '.log', '.mjs', '.py', '.diff', '.md', '.txt'):
                    queue.append(local(value))
            elif re.fullmatch(r'[A-Za-z0-9_.-]+\.(?:json|log|mjs|py|diff|md|txt)', value):
                p = OUT / value
                if p.is_file():
                    queue.append(p)

    while queue:
        p = queue.pop().resolve()
        assert p.is_relative_to(OUT), p
        relative = p.relative_to(ROOT).as_posix()
        if relative in seen:
            continue
        seen.add(relative)
        raw = p.read_bytes()
        included[relative] = raw
        if relative in prior_reports and prior_reports[relative][1] == raw:
            member, _ = prior_reports[relative]
            binding = {'archive': {'path': prior_path.relative_to(ROOT).as_posix(), 'sha256': prior_hash},
                       'member': member, 'sha256': sha(raw)}
            inherited[(binding['archive']['path'], member)] = binding
            references.append({'kind': 'historical-member', **binding})
            continue
        if p.suffix == '.json':
            try:
                walk(json.loads(raw))
            except AssertionError as error:
                raise AssertionError(f'{relative}: {error}') from error

    state = json.loads(included[f'reports/findings-review/{args.tag}-receipt-candidate-state.json'])
    approval = json.loads(included[f'reports/findings-review/{args.tag}-receipt-adoption-approval.json'])
    assert approval['candidate'] == state['candidate'] and approval['approved'] is True
    independent = json.loads(included[f'reports/findings-review/{args.tag}-independent-receipt-review.json'])
    assert independent['candidate'] == state['candidate'] and independent['revision'] == state['revision']
    assert independent['referenceClosure']['unresolvedReferences'] == 0
    assert independent['checks']['productionPythonValidation'] == 'PASS'
    assert independent['checks']['productionNodeComparison']['buildInputsMatch'] is True
    assert independent['checks']['productionNodeComparison']['implementationVerified'] is False
    manifest = {'schemaVersion': 1, 'sourceRevision': state['revision'],
        'scope': 'Exact new offline evidence; source files remain bound to the reviewed Git revision. Historical members retain their own context.',
        'files': [{'path': p, 'member': 'review/' + p, 'sha256': sha(raw), 'bytes': len(raw)} for p, raw in sorted(included.items())],
        'inheritedExactReferences': list(inherited.values()), 'verifiedReferences': references,
        'unresolvedReferences': [], 'providerAcceptanceVerified': False, 'operativeReceiptOrPinsChanged': False}
    manifest_raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    payload = {'manifest.json': manifest_raw, **{'review/' + p: raw for p, raw in sorted(included.items())}}

    def pack():
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name, raw in payload.items():
                item = tarfile.TarInfo(name)
                item.size = len(raw)
                item.mode = 0o444
                item.uid = item.gid = item.mtime = 0
                item.uname = item.gname = ''
                archive.addfile(item, io.BytesIO(raw))
        result = io.BytesIO()
        with gzip.GzipFile(filename='', fileobj=result, mode='wb', mtime=0, compresslevel=9) as compressed:
            compressed.write(buf.getvalue())
        return result.getvalue()

    raw = pack()
    assert raw == pack(), 'Nondeterministic archive'
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        assert len(archive.getmembers()) == len(payload)
        for member in archive.getmembers():
            assert member.isfile() and member.mtime == 0
            assert archive.extractfile(member).read() == payload[member.name]
    assert all((ROOT / p).read_bytes() == b for p, b in included.items())
    for binding in references:
        if binding['kind'] == 'current-file':
            assert sha(local(binding['path']).read_bytes()) == binding['sha256']
        else:
            a = binding['archive']
            assert sha(local(a['path']).read_bytes()) == a['sha256']
            with tarfile.open(local(a['path']), 'r:gz') as archive:
                assert sha(archive.extractfile(binding['member']).read()) == binding['sha256']
    archive_path = OUT / f'{args.tag}-receipt-evidence.tar.gz'
    with archive_path.open('xb') as handle:
        handle.write(raw)
    manifest_path = OUT / f'{args.tag}-receipt-evidence-manifest.json'
    with manifest_path.open('xb') as handle:
        handle.write(manifest_raw)
    print(json.dumps({'archive': archive_path.relative_to(ROOT).as_posix(), 'sha256': sha(raw),
        'manifest': manifest_path.relative_to(ROOT).as_posix(), 'manifestSha256': sha(manifest_raw),
        'files': len(included), 'bytes': len(raw), 'doubleBuildByteIdentical': True,
        'everyMemberReadBack': True, 'unresolvedReferences': [], 'operativeReceiptOrPinsChanged': False}))

if __name__ == '__main__':
    main()
