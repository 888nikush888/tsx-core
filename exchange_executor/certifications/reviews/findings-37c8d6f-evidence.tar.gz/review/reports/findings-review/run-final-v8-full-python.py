import pathlib,sys,subprocess,json,hashlib,datetime
root=pathlib.Path.cwd();out=root/'reports/findings-review';sha=lambda b:hashlib.sha256(b).hexdigest();stamp=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def inputs():
 paths=[p for p in (root/'exchange_executor').rglob('*.py') if '__pycache__' not in p.parts]
 paths += [root/'docs/testing/ccxt-expansion-matrix.json',root/'exchange_executor/requirements.txt']
 return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in sorted(paths) if p.exists()}
sys.path.insert(0,str(root/'exchange_executor'));import ccxt
from ccxt_certification_evidence import python_tree_hash
before=inputs();start=stamp();log=out/'final-v8-python-full-unittest.log';cmd=[sys.executable,'-B','-m','unittest','discover','-s','exchange_executor/tests','-v']
with log.open('xb') as handle:run=subprocess.run(cmd,cwd=root,stdout=handle,stderr=subprocess.STDOUT)
after=inputs();report={'kind':'observed-full-offline-python-execution','startedAt':start,'completedAt':stamp(),'command':cmd,'cwd':str(root),'python':sys.version,'ccxt':ccxt.__version__,'exitCode':run.returncode,'log':str(log.relative_to(root)).replace('\\','/'),'logSha256':sha(log.read_bytes()),'inputsBefore':before,'inputsAfter':after,'relevantObservedInputsUnchanged':before==after,'executorTreeHash':python_tree_hash(root/'exchange_executor'),'sdkTreeHash':python_tree_hash(pathlib.Path(ccxt.__file__).parent,sdk=True),'providerAcceptanceVerified':False,'finalSourceClaim':False,'note':'Run during source review; final receipt must independently match complete final relevant inputs/runtime and witness semantics. No final receipt created.'}
p=out/'final-v8-python-full-unittest-execution.json';p.open('x',encoding='utf8').write(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['inputsBefore','inputsAfter']},indent=2));print('executionSha256',sha(p.read_bytes()))
