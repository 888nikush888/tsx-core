"""Bind 315 unchanged sealed reviews and one independently reviewed selector delta."""
from pathlib import Path
import json, hashlib, subprocess, tarfile, copy

R = Path('reports/findings-review')
sha = lambda b: hashlib.sha256(b).hexdigest()
ref = lambda p: {'path': p.as_posix(), 'sha256': sha(p.read_bytes())}
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision == '37c8d6ffa9d03611627c2ebd61b1dd3aa59c0b2d'
archive = Path('exchange_executor/certifications/reviews/findings-1363d84-evidence.tar.gz')
assert sha(archive.read_bytes()) == '9efd9edae65d5bb466cfcc1536b150148df778bf22b8626f323f59f93d69d853'
member = 'review/reports/findings-review/final-v7-receipt-source-review.json'
with tarfile.open(archive) as handle:
    members = {entry.name: handle.extractfile(entry).read() for entry in handle.getmembers() if entry.isfile()}
raw = members[member]
assert sha(raw) == '0f06c56b2547f165870c3415423559af2b4c01ffd30492b7eef942b725f1597d'
base = json.loads(raw)
old = {row['path']: row for row in base['reviews']}
assert len(old) == len(base['reviews']) == 316
delta_path = R / 'final-v8-receipt-source-deltas.json'
deltas = json.loads(delta_path.read_bytes())
assert deltas['revision'] == revision and deltas['counts'] == {'inputs': 974, 'changedOrAddedOrRemoved': 316}
review_path = R / 'final-v8-selector-independent-review.json'
review = json.loads(review_path.read_bytes())
assert review['revision'] == revision and review['independent'] is True and review['status'] == 'pass' and not review['findings']
assert review['path'] == 'frontend/tests/telegram-settings-coverage.test.tsx'
assert review['beforeSha256'] == old[review['path']]['currentSha256']
assert review['sha256'] == sha(Path(review['path']).read_bytes())
for binding in review['evidence']:
    assert ref(Path(binding['path'])) == binding
assert set(old) == {row['path'] for row in deltas['deltas']}

def sealed(binding):
    """Keep the original evidence bytes and review context in the immutable archive."""
    assert set(binding) == {'path', 'sha256'}
    evidence_member = 'review/' + binding['path']
    assert sha(members[evidence_member]) == binding['sha256']
    return {'archive': ref(archive), 'member': evidence_member, 'sha256': binding['sha256']}

rows = []
unchanged = 0
for delta in deltas['deltas']:
    path = delta['path']
    prior = old[path]
    assert prior['reviewed'] is True and sha(Path(path).read_bytes()) == delta['currentSha256']
    row = copy.deepcopy(prior)
    row['evidence'] = [sealed(binding) for binding in prior['evidence']]
    if path == review['path']:
        assert prior['currentSha256'] == review['beforeSha256'] and delta['currentSha256'] == review['sha256']
        row['currentSha256'] = review['sha256']
        row['rationale'] = prior['rationale'] + ' Subsequent independent selector review: ' + ' '.join(review['review'])
        row['evidence'].append({'archive': ref(archive), 'member': member, 'sha256': sha(raw)})
        row['evidence'].append(ref(review_path))
    else:
        assert prior['currentSha256'] == delta['currentSha256']
        unchanged += 1
    rows.append(row)
assert len(rows) == 316 and unchanged == 315
result = {'revision': revision, 'deltas': ref(delta_path),
    'method': 'Preserve the exact source hashes, rationales and reviewed flags of 315 rows; preserve their ordered evidence bytes through exact sealed v7 archive members. Re-review only the Telegram selector delta using the independent root record. Historical evidence is not reinterpreted as current source. No operative adoption.',
    'priorSealedReview': {'archive': ref(archive), 'member': member, 'sha256': sha(raw)},
    'supplements': [ref(review_path)], 'frontendLintLog': ref(R / 'final-v8-frontend-lint.log'), 'reviews': rows}
destination = R / 'final-v8-receipt-source-review.json'
destination.open('x', encoding='utf-8', newline='\n').write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'manifest': ref(destination), 'reviewRows': len(rows), 'unchangedRows': unchanged}))
