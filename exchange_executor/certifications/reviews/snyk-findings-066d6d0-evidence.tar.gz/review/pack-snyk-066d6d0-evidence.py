"""Pack reviewed Snyk evidence and exact scanned Git source bindings deterministically."""
import gzip,hashlib,io,json,pathlib,subprocess,tarfile
ROOT=pathlib.Path.cwd();R=ROOT/'reports/findings-review';REV='066d6d0393282da3863317106a0e2ec7453bb699'
def require(ok,msg):
    if not ok: raise ValueError(msg)
def sha(data):return hashlib.sha256(data).hexdigest()
def readjson(name):return json.loads((R/name).read_bytes())
side=readjson('snyk-066d6d0-candidate.json.evidence.json');candidate=readjson('snyk-066d6d0-candidate.json');authority=readjson('snyk-066d6d0-authority-review.json')
require(candidate['reviewedRevision']==side['sourceRevision']==REV,'revision differs')
require(sha((R/'snyk-066d6d0-candidate.json').read_bytes())=='75ed625275fc943b8f997eeaa805214a1c5a6debf70e800edc9b6833ae0340ed','candidate differs')
files=set(['snyk-066d6d0-candidate.json','snyk-066d6d0-candidate.json.evidence.json','snyk-066d6d0-evaluator.json','snyk-066d6d0-actions-artifacts.json','snyk-066d6d0-actions-run.json','prepare-snyk-066d6d0-candidate.mjs','pack-snyk-066d6d0-evidence.py','snyk-historical-95d6666c.sarif.json','snyk-prior-operative-95d6666c.json','snyk-fbc3517-flow-comparison.json','compare-snyk-flow.mjs','independent144-test-ast.json','restored-direct-rejects159.json','wrapper-api-ast-proofs.json','restored-indirect-async-fixtures10.json','direct-rejects159-execution.json','direct-rejects159.log','indirect-async10-execution.json','indirect-async10.log','test-restoration-eslint.log','review144.mjs','restore-direct-rejects159.mjs','verify-direct-rejects159.mjs','verify-indirect-async10.mjs','snyk-independent-production.diff','snyk-independent-tests.diff'])
references=[]
for ref in [side['sarif'],side['status'],*side['reviews'],*authority['evidence']]:
    p=ROOT/ref['path'];require(p.is_file() and sha(p.read_bytes())==ref['sha256'],'reference changed: '+ref['path']);files.add(p.relative_to(R).as_posix());references.append(ref)
files.add('snyk-fbc3517-ci/snyk-code-234ffdddcfac211e4f3f588de0191df622b7c311/code.sarif.json')
files.add('snyk-fbc3517-ci/snyk-code-234ffdddcfac211e4f3f588de0191df622b7c311/code.status.json')
for row in readjson('adopted-v6-verification.json')['rows']:
    p=ROOT/row['log'];require(sha(p.read_bytes())==row['logSha256'],'verification log drift');files.add(p.relative_to(R).as_posix());references.append({'path':row['log'],'sha256':row['logSha256']})
# Scope-preserving receipt archive already stores the full transitive receipt/test closure.
archive_path='exchange_executor/certifications/reviews/findings-0f428ab-evidence.tar.gz';archive_bytes=subprocess.check_output(['git','show',REV+':'+archive_path]);require(sha(archive_bytes)==readjson('final-v6-archive-check.json')['archive']['sha256'],'receipt archive differs')
payload={};manifest_files=[]
for name in sorted(files):
    p=R/name;data=p.read_bytes();member='review/'+name;payload[member]=data;manifest_files.append({'member':member,'path':'reports/findings-review/'+name,'sha256':sha(data),'bytes':len(data)})
bindings={}
for entry in candidate['entries']:
    for binding in [{'path':entry['path'],'sha256':entry['reviewedSourceSha256']},*entry['contextPaths']]:
        p,h=binding['path'],binding['sha256'];require(p not in bindings or bindings[p]==h,'conflicting source binding');bindings[p]=h
for p in ['scripts/check_snyk_code_review.js','scripts/check_risk_acceptances.js','docs/risk-acceptances/RA-2026-09-08-internal-http.md','exchange_executor/certifications/hyperliquid.json','exchange_executor/certifications/reviews/findings-1bda99a-archive-verifier.py']:
    bindings.setdefault(p,sha(subprocess.check_output(['git','show',REV+':'+p])))
source_refs=[]
for p,h in sorted(bindings.items()):
    data=subprocess.check_output(['git','show',REV+':'+p]);require(sha(data)==h,'source binding drift: '+p);member='source/'+p;payload[member]=data;source_refs.append({'path':p,'revision':REV,'member':member,'sha256':h,'bytes':len(data)})
payload['archive/findings-0f428ab-evidence.tar.gz']=archive_bytes
artifacts=readjson('snyk-066d6d0-actions-artifacts.json')['artifacts'];artifact=next(x for x in artifacts if x['id']==10485132270)
require(artifact['name']=='snyk-code-fe2fbcdf237af210f1c63743010e04cdaf47ff5d' and not artifact['expired'],'wrong Actions artifact')
run=readjson('snyk-066d6d0-actions-run.json');require(run['id']==35194113467 and run['head_sha']==REV and run['status']=='completed','wrong Actions run')
manifest={'schemaVersion':1,'kind':'snyk-bounded-delta-evidence-archive','reviewedRevision':REV,'scannedRevision':side['scannedRevision'],'candidateSha256':sha((R/'snyk-066d6d0-candidate.json').read_bytes()),'actionsRun':run,'artifact':artifact,'files':manifest_files,'sourceBindings':source_refs,'declaredReferences':references,'receiptEvidenceArchive':{'path':archive_path,'member':'archive/findings-0f428ab-evidence.tar.gz','sha256':sha(archive_bytes)},'classification':{'reviewedFalsePositives':81,'acceptedOpenRisks':4,'remaining':0,'acceptanceExpires':'2026-10-08'},'scope':'Exact 066d6d0 scan and reviewed bindings, not a relabelled later revision. Only subsequent evidence adoption is outside source bindings; final Actions scan must reject any new finding. Embedded receipt archive carries upstream receipt/test reference closure; legacy review narratives remain historical evidence, not renewed authority.','unresolvedDeclaredReferences':[]}
manifest_bytes=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();payload['manifest.json']=manifest_bytes
# Pure builder called twice; all ordering and tar/gzip metadata fixed.
def build():
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w',format=tarfile.PAX_FORMAT) as tar:
        for name,data in sorted(payload.items()):
            member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o444;member.uid=member.gid=member.mtime=0;member.uname=member.gname='';tar.addfile(member,io.BytesIO(data))
    target=io.BytesIO()
    with gzip.GzipFile(filename='',fileobj=target,mode='wb',mtime=0,compresslevel=9) as stream:stream.write(buffer.getvalue())
    return target.getvalue()
first,second=build(),build();require(first==second,'independent builds differ')
with tarfile.open(fileobj=io.BytesIO(first),mode='r:gz') as tar:
    members=tar.getmembers();require(len(members)==len(payload) and len({m.name for m in members})==len(payload),'duplicate or missing archive member')
    for member in members:
        require(member.isfile() and member.mode==0o444 and member.uid==member.gid==member.mtime==0 and not member.uname and not member.gname,'unsafe archive metadata')
        require(tar.extractfile(member).read()==payload[member.name],'member readback differs')
(R/'snyk-066d6d0-evidence.tar.gz').write_bytes(first);(R/'snyk-066d6d0-evidence-manifest.json').write_bytes(manifest_bytes)
report={'reviewedRevision':REV,'archiveSha256':sha(first),'archiveBytes':len(first),'members':len(payload),'sourceBindings':len(source_refs),'reportFiles':len(manifest_files),'doubleBuildByteIdentical':True,'everyMemberReadBack':True,'allDeclaredReferenceHashesVerified':True,'operativeChanged':False}
(R/'snyk-066d6d0-evidence-check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps(report,indent=2))
