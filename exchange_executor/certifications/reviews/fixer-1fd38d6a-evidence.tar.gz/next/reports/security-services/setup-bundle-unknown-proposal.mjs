import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';
const file=path.resolve('src/setup_bundle.ts');
const original=fs.readFileSync(file,'utf8');
let candidate=original.replace('const copy = structuredClone(bundle) as any;', "const copy: Omit<PortableSetupBundle, 'checksum'> & { checksum?: string } = structuredClone(bundle);")
.replaceAll('Record<string, any>', 'Record<string, unknown>')
.replace('new Set<WorkflowResourceKind>([','new Set<unknown>([')
.replace('Map<string, WorkflowResourceKind>', 'Map<unknown, unknown>')
.replaceAll('nodeKinds: Map<string, WorkflowResourceKind>', 'nodeKinds: Map<unknown, unknown>')
.replace('new Map<string, WorkflowResourceKind>', 'new Map<unknown, unknown>')
.replace('(node: any)', '(node: { id: unknown; kind: unknown })')
.replace('[1, 2, 3].includes(graph.schemaVersion)', '([1, 2, 3] as readonly unknown[]).includes(graph.schemaVersion)')
.replace('[1, 2, SETUP_BUNDLE_VERSION].includes(candidate.schemaVersion)', '([1, 2, SETUP_BUNDLE_VERSION] as readonly unknown[]).includes(candidate.schemaVersion)')
.replace("['3.1.0', '3.2.0', '3.3.0'].includes(candidate.applicationVersion)", "(['3.1.0', '3.2.0', '3.3.0'] as readonly unknown[]).includes(candidate.applicationVersion)")
.replace('graph.schemaVersion);', 'graph.schemaVersion as number);')
.replace('candidate.exportedAt < 0', '(candidate.exportedAt as number) < 0')
.replace('candidate.schemaVersion);', 'candidate.schemaVersion as number);')
.replace('const models = object(value, \'Setup bundle models\');', "const models = object(value, 'Setup bundle models');")
.replace('(schema: any)', '(schema: { sourceContractVersionId?: string })')
.replace('(strategy: any)', '(strategy: { configuration: Pick<StrategyConfiguration, \'allowedSignalSchemas\'> })');
candidate=candidate
.replace("function checksumPayload(bundle: Omit<PortableSetupBundle, 'checksum'> | PortableSetupBundle): Omit<PortableSetupBundle, 'checksum'> {", "function checksumPayload<T extends object>(bundle: T): Omit<T, 'checksum'> {")
.replace("const copy: Omit<PortableSetupBundle, 'checksum'> & { checksum?: string } = structuredClone(bundle);", "const copy: T & { checksum?: unknown } = structuredClone(bundle);")
.replace('checksumPayload(candidate as PortableSetupBundle)', 'checksumPayload(candidate)')
.replace('return graph as WorkflowGraph;', 'return graph as unknown as WorkflowGraph;')
.replace('return structuredClone(candidate) as PortableSetupBundle;', 'return structuredClone(candidate) as unknown as PortableSetupBundle;')
.replace('models[key].length', '(models[key] as unknown[]).length');
for (const key of ['contracts','schemas','strategies','channelRiskPolicies']) {
 candidate=candidate.replaceAll('models.'+key+'.forEach', '(models.'+key+' as unknown[]).forEach');
}
for (const key of ['contracts','schemas','strategies']) {
 candidate=candidate.replaceAll('uniqueModelIdentifiers(models.'+key+',', 'uniqueModelIdentifiers(models.'+key+' as Array<Record<string, unknown>>,');
}
candidate=candidate
.replace('models.schemas.some((schema: { sourceContractVersionId?: string })', '(models.schemas as Array<{ sourceContractVersionId?: string }>).some((schema)')
.replace("models.strategies.some((strategy: { configuration: Pick<StrategyConfiguration, 'allowedSignalSchemas'> })", "(models.strategies as Array<{ configuration: { allowedSignalSchemas: string[] } }>).some((strategy)");
fs.writeFileSync('reports/security-services/setup-bundle-unknown-candidate.ts',candidate);
const config=ts.readConfigFile('tsconfig.json', ts.sys.readFile);
const parsed=ts.parseJsonConfigFileContent(config.config, ts.sys, process.cwd());
const host=ts.createCompilerHost({...parsed.options,noEmit:true});
const read=host.readFile.bind(host); host.readFile=p=>path.resolve(p)===file?candidate:read(p);
const program=ts.createProgram(parsed.fileNames,{...parsed.options,noEmit:true},host);
const diagnostics=ts.getPreEmitDiagnostics(program);
console.log(ts.formatDiagnosticsWithColorAndContext(diagnostics,{getCurrentDirectory:()=>process.cwd(),getCanonicalFileName:f=>f,getNewLine:()=> '\n'}));
console.log('Diagnostics',diagnostics.length);

const emitted=source=>ts.transpileModule(source,{compilerOptions:{...parsed.options,sourceMap:false,declaration:false}}).outputText;
const before=emitted(original),after=emitted(candidate);
console.log('Configured JavaScript equal:',before===after);
fs.writeFileSync('reports/security-services/setup-bundle-unknown-virtual-result.json', JSON.stringify({diagnostics:diagnostics.length,javascriptEqual:before===after,sourceUnmodified:fs.readFileSync(file,'utf8')===original,candidateAny: (candidate.match(/\bany\b/g)||[]).length},null,2)+'\n');

