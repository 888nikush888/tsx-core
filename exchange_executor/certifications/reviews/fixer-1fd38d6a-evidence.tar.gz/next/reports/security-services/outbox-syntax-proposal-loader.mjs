import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import ts from 'typescript';
const db = path.resolve('src/db.ts');
const test = path.resolve('tests/test_outbox.js');
registerHooks({ load(url, context, next) {
  if (url.startsWith('file:')) {
    const p = fileURLToPath(url);
    if (p === test) return { format: 'module', source: readFileSync('reports/security-services/outbox-syntax-test-proposed.js', 'utf8'), shortCircuit: true };
    if (p === db && process.env.OUTBOX_SYNTAX_BASELINE !== '1') return { format: 'module', source: ts.transpileModule(readFileSync('reports/security-services/outbox-syntax-db-proposed.ts', 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText, shortCircuit: true };
  }
  return next(url, context);
} });
