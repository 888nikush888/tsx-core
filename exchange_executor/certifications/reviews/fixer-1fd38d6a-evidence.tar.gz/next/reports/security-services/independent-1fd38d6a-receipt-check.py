import json,hashlib,pathlib,subprocess,tarfile,sys,re
ROOT=pathlib.Path(__file__).resolve().parents[2];R=ROOT/'reports/security-services';PROOF=ROOT.parent/'tsx-core-candidate-proof-20260915'
REV='1fd38d6af1bd51ac8b8f232d7142a90419123ef9'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_bytes())
graph=[];seen=set();archives={}
def binding(b):
 if 'archive' in b:
  a=b['archive'];p=ROOT/a['path']
  if a['path'] not in archives:
   assert sha(p.read_bytes())==a['sha256'];archives[a['path']]=tarfile.open(p,'r:gz')
  raw=archives[a['path']].extractfile(b['member']).read();label=a['path']+'::'+b['member']
 else:raw=(ROOT/b['path']).read_bytes();label=b['path']
 assert sha(raw)==b['sha256'],label
 graph.append({'reference':label,'sha256':b['sha256'],'verified':True});return raw
def walk(d):
 if isinstance(d,list):
  for x in d:walk(x)
 elif isinstance(d,dict):
  if 'sha256' in d and ('archive' in d and 'member' in d or 'path' in d):
   key=json.dumps({k:d[k] for k in ('archive','member','path','sha256') if k in d},sort_keys=True)
   if key not in seen:
    seen.add(key);raw=binding(d)
    if 'archive' not in d and d.get('path','').startswith('reports/') and d['path'].endswith('.json') and '1fd38d6a' in d['path']:walk(json.loads(raw))
  for k,v in d.items():
   if k!='archive':walk(v)
prep=read(R/'fixer-1fd38d6a-candidate-preparation-state.json')
for k in ['candidate','parity','execution','completeSource']:binding(prep[k]);walk(read(ROOT/prep[k]['path']))
c,p,e,s=[read(ROOT/prep[k]['path']) for k in ['candidate','parity','execution','completeSource']]
assert prep['candidate']['sha256']=='9d56f6946102b339acce02ac2ccc5c0388b44402f60a5de1cd461309626d4c8b'
assert c['parityEvidenceHash']==prep['parity']['sha256'] and c['executionReportHash']==prep['execution']['sha256']
before=read(ROOT/e['sourceContinuity']['duringVerification']['path']);after=read(ROOT/e['sourceContinuity']['afterCompletedVerification']['path'])
assert before['inputs']==after['inputs'] and before['runtime']==after['runtime']
items=after['inputs']['files'];inputs={x['path']:x['sha256'] for x in items}
stream=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,input=''.join(REV+':'+x['path']+'\n' for x in items).encode());pos=0
for x in items:
 end=stream.index(b'\n',pos);size=int(stream[pos:end].split()[2]);blob=stream[end+1:end+1+size];pos=end+size+2
 assert sha(blob)==x['sha256']==sha((PROOF/x['path']).read_bytes())==sha((ROOT/x['path']).read_bytes()),x['path']
 assert (PROOF/x['path']).stat().st_nlink==1 and (ROOT/x['path']).stat().st_nlink==1
base=json.loads(binding(s['baselineContext']));old={x['path']:x['sha256'] for x in base['inputs']['files']}
deltas={k for k,v in inputs.items() if old.get(k)!=v};assert deltas=={x['path'] for x in s['deltas']} and len(deltas)==10 and not(set(old)-set(inputs))
for k in ('sourceTreeHash','nodeSourcesHash','testSourcesHash','fixturesHash'):assert c[k]==after['inputs'][k]
for k in ('executorTreeHash','sdkTreeHash','profileHash'):assert c[k]==after['runtime'][k]
part=e['python'];logs=[binding(b) for b in part['evidence']]
assert b'Ran 548 tests' in logs[1] and re.search(rb'^OK\s*$',logs[1],re.M) and json.loads(logs[0])['exitCode']==0 and not part['freshCurrentRunClaimed']
fa=part['evidence'][0]['archive'];ft=archives[fa['path']]
fctx=json.loads(ft.extractfile('next/reports/security-services/fixer-final-f1b7-context-after.json').read())
fi={x['path']:x['sha256'] for x in fctx['inputs']['files']}
py={k:v for k,v in inputs.items() if k.startswith('exchange_executor/') and k.endswith('.py')}
assert len(py)==118 and all(fi[k]==v for k,v in py.items()) and fctx['runtime']==after['runtime']
log=binding(e['node']['evidence'][1]);assert b'ALL 226 TEST FILES PASSED' in log and b'Module coverage ratchet passed.' in log
assert re.search(rb'All files\s*\|\s*96\.58\s*\|\s*86\.68\s*\|\s*99\.24\s*\|\s*96\.58',log)
completion=json.loads(binding(e['node']['evidence'][2]));assert completion['failure'] is None and all(x['exitCode']==0 for x in completion['rows'])
for b in e['node']['evidence']:assert binding(b)==(PROOF/b['path']).read_bytes()
flog=binding(e['frontend']['evidence'][0]);assert b'328 passed' in flog and b'40 passed' in flog and e['frontend']['freshCurrentRunClaimed']
plan=read(R/'fixer-1fd38d6a-62-requirement-continuity-plan.json');bp=json.loads(binding(plan['baselineParity']))
rowkeys=lambda rows:{(x['category'],x['check']) for x in rows}
assert rowkeys(p['rows'])==rowkeys(bp['rows']) and len(p['rows'])==len(rowkeys(p['rows']))==62
w=[w for row in p['rows'] for w in row['witnessBindings']];assert len(w)==97
assert all(inputs[x['path']]==old[x['path']]==x['sha256'] and x['unchangedSince5a532f'] for x in w)
for row in p['rows']:
 prior=next(x for x in bp['rows'] if (x['category'],x['check'])==(row['category'],row['check']))
 assert [(x['path'],x['sha256']) for x in row['witnessBindings']]==[(x['path'],x['sha256']) for x in prior['witnessBindings']]
 assert {x['path'] for x in row['currentDeltaDependencies']}==deltas
 for d in row['currentDeltaDependencies']:assert d['sha256']==inputs[d['path']] and d['evidence']
sys.path.insert(0,str(PROOF/'exchange_executor'))
from ccxt_certification_evidence import python_tree_hash
import ccxt
assert python_tree_hash(PROOF/'exchange_executor')==c['executorTreeHash'] and python_tree_hash(pathlib.Path(ccxt.__file__).parent,sdk=True)==c['sdkTreeHash'] and ccxt.__version__==c['ccxtVersion']
assert all(x['providerAcceptanceVerified'] is False for x in [c,p,e,s])
baseline_candidate=json.loads(archives[s['baselineContext']['archive']['path']].extractfile('next/reports/security-services/hyperliquid-5a532f-receipt-candidate-lf.json').read())
assert c['scope']==baseline_candidate['scope'] and c['exchange']==baseline_candidate['exchange'] and c['profileVersion']==baseline_candidate['profileVersion']
out={'kind':'independent-current-byte-reference-graph','revision':REV,'candidateSha256':prep['candidate']['sha256'],'references':graph,'counts':{'uniqueReferenceBindings':len({(x['reference'],x['sha256']) for x in graph}),'inputsRawNextAndProofEqualGitSingleLink':len(items),'delta':len(deltas),'unchanged':len(inputs)-len(deltas),'requirements':62,'witnessReferences':97,'changedWitnessReferences':0,'pythonExactInheritedInputs':len(py)},'runtimeActualSdkAndExecutorHashesVerified':True,'currentNode226AndFrontend328LogsVerified':True,'python548HistoricalOnly':True,'sourceDeltas':sorted(deltas),'scopeUnchanged':True,'providerAcceptanceVerified':False,'status':'passed'}
dest=R/'fixer-1fd38d6a-independent-receipt-reference-graph.json';dest.write_bytes((json.dumps(out,indent=2)+'\n').encode('utf-8'));print(json.dumps({'report':str(dest),'sha256':sha(dest.read_bytes()),'counts':out['counts']}))
