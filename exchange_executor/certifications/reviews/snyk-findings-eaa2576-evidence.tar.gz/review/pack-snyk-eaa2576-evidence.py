"""Pack reviewed Snyk evidence and exact scanned Git source bindings deterministically."""
import gzip,hashlib,io,json,pathlib,subprocess,tarfile
ROOT=pathlib.Path.cwd();R=ROOT/'reports/findings-review';REV='eaa2576c51d1bddb7bac52687bb470992c81b2d6'
def require(ok,msg):
    if not ok: raise ValueError(msg)
def sha(data):return hashlib.sha256(data).hexdigest()
def readjson(name):return json.loads((R/name).read_bytes())
side=readjson('snyk-eaa2576-candidate.json.evidence.json');candidate=readjson('snyk-eaa2576-candidate.json');authority=readjson('snyk-eaa2576-authority-review.json')
require(candidate['reviewedRevision']==side['sourceRevision']==REV,'revision differs')
require(sha((R/'snyk-eaa2576-candidate.json').read_bytes())=='9e0794413fe1e3ca2afb842388877723e1064e18332853619cf74825dae77176','candidate differs')
files=set(['snyk-eaa2576-candidate.json','snyk-eaa2576-candidate.json.evidence.json','snyk-eaa2576-evaluator.json','snyk-eaa2576-actions-artifacts.json','snyk-eaa2576-actions-run.json','prepare-snyk-reviewed-candidate.mjs','pack-snyk-eaa2576-evidence.py','snyk-historical-95d6666c.sarif.json','snyk-prior-operative-95d6666c.json','snyk-fbc3517-flow-comparison.json','compare-snyk-flow.mjs','independent144-test-ast.json','restored-direct-rejects159.json','wrapper-api-ast-proofs.json','restored-indirect-async-fixtures10.json','direct-rejects159-execution.json','direct-rejects159.log','indirect-async10-execution.json','indirect-async10.log','test-restoration-eslint.log','review144.mjs','restore-direct-rejects159.mjs','verify-direct-rejects159.mjs','verify-indirect-async10.mjs','snyk-independent-production.diff','snyk-independent-tests.diff'])
references=[]
for ref in [side['sarif'],side['status'],*side['reviews'],*authority['evidence']]:
    p=ROOT/ref['path'];require(p.is_file() and sha(p.read_bytes())==ref['sha256'],'reference changed: '+ref['path']);files.add(p.relative_to(R).as_posix());references.append(ref)
files.add('snyk-fbc3517-ci/snyk-code-234ffdddcfac211e4f3f588de0191df622b7c311/code.sarif.json')
files.add('snyk-fbc3517-ci/snyk-code-234ffdddcfac211e4f3f588de0191df622b7c311/code.status.json')
for row in readjson('adopted-v5-verification.json')['rows']:
    p=ROOT/row['log'];require(sha(p.read_bytes())==row['logSha256'],'verification log drift');files.add(p.relative_to(R).as_posix());references.append({'path':row['log'],'sha256':row['logSha256']})
# Scope-preserving receipt archive already stores the full transitive receipt/test closure.
archive_path='exchange_executor/certifications/reviews/findings-1bda99a-evidence.tar.gz';archive_bytes=subprocess.check_output(['git','show',REV+':'+archive_path]);require(sha(archive_bytes)==readjson('final-v5-independent-archive-check.json')['archive']['sha256'],'receipt archive differs')
payload={};manifest_files=[]
for name in sorted(files):
    p=R/name;data=p.read_bytes();member='review/'+name;payload[member]=data;manifest_files.append({'member':member,'path':'reports/findings-review/'+name,'sha256':sha(data),'bytes':len(data)})
bindings={}
for entry in candidate['entries']:
    for binding in [{'path':entry['path'],'sha256':entry['reviewedSourceSha256']},*entry['contextPaths']]:
        p,h=binding['path'],binding['sha256'];require(p not in bindings or bindings[p]==h,'conflicting source binding');bindings[p]=h
for p in ['scripts/check_snyk_code_review.js','scripts/check_risk_acceptances.js','docs/risk-acceptances/RA-2026-09-08-internal-http.md','exchange_executor/certifications/hyperliquid.json','exchange_executor/certifications/reviews/findings-1bda99a-archive-verifier.py']:
    bindings.setdefault(p,sha(subprocess.check_output(['git','show',REV+':'+p])))
source_refs=[]
for p,h in sorted(bindings.items()):
    data=subprocess.check_output(['git','show',REV+':'+p]);require(sha(data)==h,'source binding drift: '+p);member='source/'+p;payload[member]=data;source_refs.append({'path':p,'revision':REV,'member':member,'sha256':h,'bytes':len(data)})
payload['archive/findings-1bda99a-evidence.tar.gz']=archive_bytes
artifacts=readjson('snyk-eaa2576-actions-artifacts.json')['artifacts'];artifact=next(x for x in artifacts if x['id']==10465630014)
require(artifact['name']=='snyk-code-dd9806865b1b683b777a84dba78c32b1bf1c9c5f' and not artifact['expired'],'wrong Actions artifact')
run=readjson('snyk-eaa2576-actions-run.json');require(run['id']==35140605388 and run['head_sha']==REV and run['status']=='completed','wrong Actions run')
manifest={'schemaVersion':1,'kind':'independent-snyk-evidence-archive','reviewedRevision':REV,'scannedRevision':side['scannedRevision'],'candidateSha256':sha((R/'snyk-eaa2576-candidate.json').read_bytes()),'actionsRun':run,'artifact':artifact,'files':manifest_files,'sourceBindings':source_refs,'declaredReferences':references,'receiptEvidenceArchive':{'path':archive_path,'member':'archive/findings-1bda99a-evidence.tar.gz','sha256':sha(archive_bytes)},'classification':{'reviewedFalsePositives':81,'acceptedOpenRisks':4,'remaining':0,'acceptanceExpires':'2026-10-08'},'scope':'Exact eaa2576 scan and reviewed bindings, not a relabelled later revision. Subsequent evidence-helper hardening is outside these85bindings and requires final Actions scan to reject any new finding. Embedded receipt archive carries upstream receipt/test reference closure; legacy review narratives remain historical evidence, not renewed authority.','unresolvedDeclaredReferences':[]}
manifest_bytes=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();payload['manifest.json']=manifest_bytes
# Pure builder called twice; all ordering and tar/gzip metadata fixed.
def build():
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w',format=tarfile.PAX_FORMAT) as tar:
        for name,data in sorted(payload.items()):
            member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o444;member.uid=member.gid=member.mtime=0;member.uname=member.gname='';tar.addfile(member,io.BytesIO(data))
    target=io.BytesIO()
    with gzip.GzipFile(filename='',fileobj=target,mode='wb',mtime=0,compresslevel=9) as stream:stream.write(buffer.getvalue())
    return target.getvalue()
first,second=build(),build();require(first==second,'independent builds differ')
with tarfile.open(fileobj=io.BytesIO(first),mode='r:gz') as tar:
    members=tar.getmembers();require(len(members)==len(payload) and len({m.name for m in members})==len(payload),'duplicate or missing archive member')
    for member in members:
        require(member.isfile() and member.mode==0o444 and member.uid==member.gid==member.mtime==0 and not member.uname and not member.gname,'unsafe archive metadata')
        require(tar.extractfile(member).read()==payload[member.name],'member readback differs')
(R/'snyk-eaa2576-evidence.tar.gz').write_bytes(first);(R/'snyk-eaa2576-evidence-manifest.json').write_bytes(manifest_bytes)
report={'reviewedRevision':REV,'archiveSha256':sha(first),'archiveBytes':len(first),'members':len(payload),'sourceBindings':len(source_refs),'reportFiles':len(manifest_files),'doubleBuildByteIdentical':True,'everyMemberReadBack':True,'allDeclaredReferenceHashesVerified':True,'operativeChanged':False}
(R/'snyk-eaa2576-evidence-check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps(report,indent=2))
