from pathlib import Path
import json,hashlib,subprocess,tarfile,copy
R=Path('reports/findings-review');sha=lambda b:hashlib.sha256(b).hexdigest()
ref=lambda p:{'path':p.as_posix(),'sha256':sha(p.read_bytes())}
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
archive=Path('exchange_executor/certifications/reviews/findings-1bda99a-evidence.tar.gz')
assert sha(archive.read_bytes())=='f81e6a20ba29554557c8a8be2e3bdabbcefc8006968a6a0e5df22a3dd3b75fc2'
member='review/reports/findings-review/current-receipt-source-review.json'
with tarfile.open(archive) as t:raw=t.extractfile(member).read()
assert sha(raw)=='009e16410b0348120eea48533f9ca3071f4af30f10c929df5c78f6241dc1fca4'
base=json.loads(raw); old={r['path']:r for r in base['reviews']}
dp=R/'final-v6-receipt-source-deltas.json';deltas=json.loads(dp.read_bytes());assert deltas['revision']==revision
newpath=R/'final-v6-outbox-independent-review.json';new=json.loads(newpath.read_bytes());assert new['revision']==revision
rows=[]
for d in deltas['deltas']:
 p=d['path'];prior=old[p]
 assert sha(Path(p).read_bytes())==d['currentSha256']
 if p==new['path']:
  assert prior['currentSha256']==new['beforeSha256'] and new['currentSha256']==d['currentSha256']
  row={'path':p,'currentSha256':new['currentSha256'],'reviewed':True,'rationale':prior['rationale']+' Subsequent independent review: '+new['rationale'],'evidence':new['evidence']+[ref(newpath)]}
 else:
  assert prior['reviewed'] is True and prior['currentSha256']==d['currentSha256']
  row=copy.deepcopy(prior)
 for e in row['evidence']:assert ref(Path(e['path']))==e
 rows.append(row)
assert set(old)=={r['path'] for r in rows} and len(rows)==312
result={'revision':revision,'deltas':ref(dp),'method':'Reuse312 individually reviewed baseline deltas only after current exact-byte verification; one outbox row independently reviewed again. Prior approved source review is sealed at its historical archive context. Current source inventory contains969 unchanged files plus the one test-only outbox delta.','priorSealedReview':{'archive':ref(archive),'member':member,'sha256':sha(raw)},'supplement':ref(newpath),'reviews':rows}
out=R/'final-v6-receipt-source-review.json';out.open('x',encoding='utf8',newline='\n').write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'manifest':ref(out),'reviewRows':len(rows)}))
