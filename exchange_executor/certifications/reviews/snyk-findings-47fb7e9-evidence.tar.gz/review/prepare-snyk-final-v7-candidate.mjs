import fs from 'node:fs';
import cp from 'node:child_process';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {evidenceDigest,evaluateSnykCode,loadHttpRiskAcceptance} from '../../scripts/check_snyk_code_review.js';
// Offline candidate builder only. Never writes operative review or changes scanner/acceptance policy.
const [revision,sarifPath,statusPath,authorityPath,newFindingReviewPath,outputPath,...extraArgs]=process.argv.slice(2);
const must=(ok,msg)=>{if(!ok)throw Error(msg)};
must(revision&&sarifPath&&statusPath&&authorityPath&&newFindingReviewPath&&outputPath&&!extraArgs.length,'Usage: node reports/findings-review/prepare-snyk-final-v7-candidate.mjs ADOPTED_REVISION SARIF STATUS AUTHORITY_REVIEW SINGLE_NEW_FINDING_REVIEW ignored-output.json');
must(/^[a-f0-9]{40}$/.test(revision),'Explicit full adopted revision required');
const reportRoot=path.resolve('reports/findings-review');
must(path.resolve(outputPath).startsWith(reportRoot+path.sep),'Candidate output must remain in ignored reports/findings-review');
const sha=b=>createHash('sha256').update(b).digest('hex'),read=p=>fs.readFileSync(p),json=p=>JSON.parse(read(p));
const git=(...args)=>cp.execFileSync('git',args,{encoding:'utf8'}).trim();
const sourceRevision=git('rev-parse','HEAD');must(sourceRevision===revision,'HEAD differs from explicit adopted revision');const status=json(statusPath);const bytes=read(sarifPath),sarif=JSON.parse(bytes);
must(status.scope==='code'&&status.scannerVersion==='1.1307.1'&&[0,1].includes(status.scannerExit),'Invalid Actions scanner completion');
must(/^[a-f0-9]{40}$/.test(status.revision),'Missing scanned revision');
must(git('rev-parse',`${status.revision}^{tree}`)===git('rev-parse','HEAD^{tree}'),'Scanned tree differs from current committed tree; fresh scan required');
must(git('status','--porcelain','--untracked-files=no')==='','Tracked worktree must be frozen');
const operativePath='exchange_executor/certifications/reviews/snyk-code-scalar-contracts-review-2026-09-15.json';
const base=json(operativePath);const independentPath='reports/findings-review/snyk-independent-ec139e7-review.json';const testPath='reports/findings-review/independent144-test-review.json';
const independent=json(independentPath),tests=json(testPath);
const referencePath='reports/findings-review/snyk-fbc3517-ci/snyk-code-234ffdddcfac211e4f3f588de0191df622b7c311/code.sarif.json';
const reference=json(referencePath).runs.flatMap(x=>x.results);const results=sarif.runs.flatMap(x=>x.results);
const id=r=>r.fingerprints?.['snyk/asset/finding/v1'];const refs=new Map(reference.map(r=>[id(r),r]));const priors=new Map(base.entries.map(e=>[e.findingId,e]));
must(results.length===86&&status.resultCount===86&&new Set(results.map(id)).size===86&&refs.size===85&&priors.size===85,'Finding set/count changed; independent manual review required');
function normalized(o){if(Array.isArray(o))return o.map(normalized);if(!o||typeof o!=='object')return o;return Object.fromEntries(Object.keys(o).filter(k=>k!=='region').sort().map(k=>[k,normalized(o[k])]));}
const flow=r=>({locations:r.locations,relatedLocations:r.relatedLocations??[],codeFlows:r.codeFlows??[]});
const locations=r=>[...r.locations,...r.relatedLocations??[],...(r.codeFlows??[]).flatMap(f=>f.threadFlows.flatMap(t=>t.locations.map(s=>s.location)))];
const newFindingId='40aa77d4-0842-4520-885d-a108e083d3a0';
const newFindingReview=json(newFindingReviewPath),newEntry=newFindingReview.entry;
must(newFindingReview.revision===sourceRevision&&newFindingReview.kind==='explicit-single-new-finding-review'&&newFindingReview.reviewer==='root independent of test author','Separate revision-bound root review required for the one new fixture finding');
must(newFindingReview.sarif.sha256===sha(bytes)&&sha(read(newFindingReview.sarif.path))===sha(bytes),'New finding review references a different SARIF');
must(newEntry.findingId===newFindingId&&newEntry.ruleId==='javascript/HardcodedNonCryptoSecret/test'&&newEntry.path==='frontend/tests/telegram-settings-coverage.test.tsx'&&newEntry.disposition==='false-positive','Only the explicitly reviewed fixture finding may be added');
const added=results.filter(r=>!priors.has(id(r)));
must(added.length===1&&id(added[0])===newFindingId&&[...priors.keys()].every(key=>results.some(r=>id(r)===key)),'Unreviewed new or removed finding');
const newResult=added[0];
must(newResult.ruleId===newEntry.ruleId&&newResult.locations[0].physicalLocation.artifactLocation.uri===newEntry.path&&newResult.locations[0].physicalLocation.region.startLine===newEntry.line,'New finding identity/location changed');
must(JSON.stringify(normalized(newResult.fingerprints))===JSON.stringify(normalized(newEntry.fingerprints))&&evidenceDigest(newResult)===newEntry.evidenceSha256,'New finding exact fingerprint/flow changed');
must(JSON.stringify(locations(newResult).map(l=>({path:l.physicalLocation.artifactLocation.uri,line:l.physicalLocation.region?.startLine})))===JSON.stringify(newEntry.codeFlowLocations),'New finding reviewed flow locations differ');
const newBindings=new Map([{path:newEntry.path,sha256:newEntry.reviewedSourceSha256},...newEntry.contextPaths].map(binding=>[binding.path,binding.sha256]));
for(const [file,hash] of newBindings){must(/^[a-f0-9]{64}$/.test(hash)&&sha(read(file))===hash&&sha(cp.execFileSync('git',['show',sourceRevision+':'+file]))===hash,'New finding binding differs from reviewed committed bytes: '+file);}
for(const location of locations(newResult))must(newBindings.has(location.physicalLocation.artifactLocation.uri),'New finding has unreviewed flow context');
const pathReviews=new Map(independent.pathReviews.map(x=>[x.path,x]));const testReviews=new Map(tests.files.map(x=>[x.path,x]));
const rowReviews=new Map(independent.findings.map(x=>[x.findingId,x]));
const supplementPath='reports/findings-review/snyk-1bda99a-supplement.json';
const authority=json(authorityPath);
must(authority.revision===sourceRevision,'Authority review must explicitly bind adopted revision');
must(typeof authority.reviewer==='string'&&authority.reviewer.trim(),'Separate authority reviewer required');
must(Array.isArray(authority.evidence)&&authority.evidence.length>0,'Separate authority evidence required');
for(const ref of [authority.receipt,authority.authority,...authority.evidence]){
 must(ref&&typeof ref.path==='string'&&/^[a-f0-9]{64}$/.test(ref.sha256),'Invalid authority evidence reference');
 must(sha(read(ref.path))===ref.sha256,'Authority evidence changed: '+ref.path);
}
for(const ref of [authority.receipt,authority.authority])must(sha(cp.execFileSync('git',['show',sourceRevision+':'+ref.path]))===ref.sha256,'Authority binding differs from committed source: '+ref.path);
must(Array.isArray(authority.findings)&&authority.findings.length>0&&authority.findings.every(row=>typeof row.rationale==='string'&&row.rationale.trim()),'Explicit authority finding rationales required');
must(new Set(authority.findings.map(row=>row.findingId)).size===authority.findings.length&&authority.findings.every(row=>priors.has(row.findingId)),'Authority finding IDs absent or duplicated');
must(Array.isArray(authority.pathReviews)&&authority.pathReviews.some(row=>row.path===authority.authority.path&&row.sha256===authority.authority.sha256),'Reviewed authority path binding missing');

const supplements=new Map([...json(supplementPath).pathReviews,...authority.pathReviews].map(x=>[x.path,x]));
function approvedBinding(file,priorHash){
 const current=sha(read(file));must(sha(cp.execFileSync('git',['show',`HEAD:${file}`]))===current,`Uncommitted binding ${file}`);
 const tr=testReviews.get(file),pr=pathReviews.get(file),extra=supplements.get(file);
 if(extra&&extra.sha256===current)return{sha256:current,note:extra.note};
 if(tr&&tr.reviewedSha256===current)return{sha256:current,note:tr.rationale};
 if(pr&&pr.sha256===current)return{sha256:current,note:pr.note};
 if(current===priorHash)return{sha256:current,note:'Exact previous reviewed source bytes unchanged.'};
 throw Error(`Unreviewed source/context drift: ${file}. Receipt authority changes require separate independent review; never refresh automatically.`);
}
const securityClaims={
 'frontend/src/lib/api.ts':'TOKEN_KEY is the sessionStorage lookup name, not credential bytes. apiFetch normalizes exactly one Request, checks same origin and absent userinfo before bearer attachment, and fetches that Request with redirect:error.',
 'scripts/verify_exchange_implementation.js':'The path and command sources are local build/operator authority. Canonical directories, ordinary non-symlink/single-link bounded files and pre/open/post identity checks remain enforced. Python execution uses canonical absolute operator-selected executable, fixed bridge arguments, shell:false, timeout and output bounds; receipt content cannot select interpreter arguments.',
 'src/backup_cli.ts':'The restore artifact and destinations are explicitly selected by the local operator CLI. Owner capability, database inactivity and genuine maintenance lease checks remain; no remote request supplies the reported path. This does not claim symlink confinement beyond the existing implementation.',
 'src/signal_parser.ts':'The reported readFile path is populated only from local --file argv within isMain. Exported parser receives message text and cannot choose this CLI pathname.',
 'src/metrics.ts':'The reported metrics response uses JSON.stringify with application/json, no-store and nosniff; it does not render exception text as HTML. This XSS disposition is not a blanket claim that arbitrary exception messages contain no sensitive data.',
 'src/incoming_work_repository.ts':'The filter flow retains pattern validation/cache limits,8000-character text bound and actual safeRegexTest vm.runInContext100ms matching timeout; failures reject the filter. No unbounded matching execution was introduced.',
 'tests/fixtures/backup_generation_crash_child.js':'The parent-owned mkdtemp root is additionally realpath/temp-parent/prefix checked. Fixed lock/config/database members are created under genuine owner capability. The crash fixture accepts no remote pathname.',
 'tests/fixtures/crash_guard_owner_child.js':'The parent selects a temporary directory as a discrete child argv. Fixed lock/crash-counter members and genuine owner capability are used; there is no production request path source.',
 'tests/fixtures/maintenance_participant_child.js':'The parent supplies its private temporary forwarder.db as a discrete child argv. Marker scope and exclusive writes remain; this is a local maintenance/crash fixture.',
 'tests/fixtures/ui_restart_child.js':'The checkpoint and shutdown log have fixed basenames inside the parent-owned temporary directory. Synthetic controls and blocked provider fetch isolate this restart fixture.',
 'tests/test_trading_adaptive_money_migration.js':'Dynamic PRAGMA identifiers are from the literal fixture table list and sqlite_master/index_list of the same private freshly constructed test database, not request input. Bound DB edits add no identifier source.',
};
let exactFlow=0,identicalFingerprints=0;
const entries=results.map(r=>{
 if(id(r)===newFindingId)return newEntry;
 const key=id(r),prior=priors.get(key),ref=refs.get(key),review=rowReviews.get(key);
 must(prior&&ref&&review,`Unreviewed finding ${key}`);must(prior.ruleId===r.ruleId&&prior.path===r.locations[0].physicalLocation.artifactLocation.uri,`Changed finding identity ${key}`);
 must(JSON.stringify(normalized(flow(ref)))===JSON.stringify(normalized(flow(r))),`Structural flow changed for ${key}; manual review required`);
 if(evidenceDigest(ref)===evidenceDigest(r))exactFlow++;
 if(JSON.stringify(normalized(ref.fingerprints))===JSON.stringify(normalized(r.fingerprints)))identicalFingerprints++;
 const bound=[{path:prior.path,sha256:prior.reviewedSourceSha256},...prior.contextPaths];const commitments=new Map(bound.map(b=>[b.path,approvedBinding(b.path,b.sha256)]));
 for(const loc of locations(r))must(commitments.has(loc.physicalLocation.artifactLocation.uri),`New unreviewed flow context ${key}`);
 let claim=securityClaims[prior.path];
 if(prior.disposition==='open')claim='This is an actual internal plaintext HTTP transport risk. Listener/destination, token/authorization and deployment scope remain unchanged in the reviewed delta. It stays OPEN under the exact owner acceptance expiring2026-10-08; no risk closure or extension.';
 else if(!claim&&r.ruleId.includes('/HttpToHttps/test'))claim='The reported HTTP transport belongs to an explicitly loopback/ephemeral-port local integration fixture with synthetic controls and credentials, not a deployed public endpoint.';
 else if(!claim&&(/HardcodedNonCryptoSecret|NoHardcodedPasswords/.test(r.ruleId)))claim='The reported literal is synthetic local test or redaction-sentinel data in the bound fixture, not a deployable provider credential. Its fixture setup, intended consumer and assertions remain isolated under the reviewed changes.';
 else if(!claim)claim=prior.rationale;
 const notes=[...commitments].filter(([,v])=>!v.note.startsWith('Exact previous')).map(([p,v])=>`${p}: ${v.note}`);
 const authorityNote=authority.findings.find(x=>x.findingId===key)?.rationale;
 if(bound.some(binding=>binding.path===authority.authority.path&&binding.sha256!==authority.authority.sha256))must(authorityNote,`Changed authority requires a separate rationale for finding ${key}`);
 const rationale=`Scoped review at ${sourceRevision}. ${authorityNote??claim}${notes.length?' Current binding review: '+notes.join(' '):' All source/context byte commitments are unchanged from the preceding independent review.'}`;
 return{...prior,line:r.locations[0].physicalLocation.region.startLine,reviewedSourceSha256:commitments.get(prior.path).sha256,rationale,contextPaths:prior.contextPaths.map(c=>({path:c.path,sha256:commitments.get(c.path).sha256})),codeFlowLocations:locations(r).map(l=>({path:l.physicalLocation.artifactLocation.uri,line:l.physicalLocation.region?.startLine})),fingerprints:r.fingerprints,evidenceSha256:evidenceDigest(r)};
});
const candidate={...base,reviewedRevision:sourceRevision,sarifSha256:sha(bytes),reviewedCount:86,counts:{'false-positive':82,open:4},reviewKind:'root-bounded-authority-delta-and-single-explicit-fixture-review',priorReviewRevision:base.reviewedRevision,scopeNote:`Fresh Actions scan of ${status.revision}, identical Git tree to ${sourceRevision};85 existing identities,${exactFlow} exact flows and${85-exactFlow} coordinate-only flow changes relative to fbc3517;${identicalFingerprints} exact fingerprint maps. One additional synthetic fixture finding ${newFindingId} has exact revision/SARIF/source/context/flow commitments in separate root review ${newFindingReviewPath}.82 scoped false positives and4OPEN accepted HTTP risks. Adopted receipt ${authority.receipt.sha256} and authority ${authority.authority.sha256} bound by separately supplied review ${authorityPath}; no provider acceptance or transport-risk closure claimed.`,entries};
const evaluation=await evaluateSnykCode({sarif,scannerExit:status.scannerExit,review:candidate,readSource:async file=>read(file),acceptance:await loadHttpRiskAcceptance(process.cwd())});
must(evaluation.resultCount===86&&evaluation.reviewedFalsePositives===82&&evaluation.acceptedRisks===4&&evaluation.remaining===0,'Production evaluator rejects candidate');
const evidence={sourceRevision,scannedRevision:status.revision,sarif:{path:sarifPath,sha256:sha(bytes)},status:{path:statusPath,sha256:sha(read(statusPath))},reviews:[operativePath,referencePath,independentPath,testPath,supplementPath,authorityPath,newFindingReviewPath].map(p=>({path:p,sha256:sha(read(p))})),evaluation,authorityReviewPath:authorityPath,newFindingReviewPath,reviewedAuthority:authority.authority,candidateOnly:true};
must(!fs.existsSync(outputPath)&&!fs.existsSync(`${outputPath}.evidence.json`),'Refusing to overwrite candidate or evidence');
fs.writeFileSync(outputPath,JSON.stringify(candidate,null,2)+'\n',{flag:'wx'});fs.writeFileSync(`${outputPath}.evidence.json`,JSON.stringify(evidence,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({outputPath,evaluation,exactFlow,identicalFingerprints},null,2));
