"""Offline deterministic evidence packer; all adopted identities are explicit CLI inputs."""
import argparse
import gzip
import hashlib
import io
import json
import pathlib
import re
import subprocess
import tarfile

ROOT = pathlib.Path.cwd().resolve()
REPORTS = ROOT / 'reports/findings-review'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args])

def local(value):
    p = (ROOT / value).resolve()
    require(p.is_relative_to(ROOT), 'Path outside repository: ' + str(value))
    return p

def readjson(value):
    return json.loads(local(value).read_bytes())

parser = argparse.ArgumentParser(description=__doc__)
for name in ['revision', 'candidate', 'candidate-sha256', 'authority', 'new-finding-review', 'verification',
             'archive-check', 'receipt-archive', 'actions-run', 'actions-artifacts',
             'evaluator', 'output-prefix']:
    parser.add_argument('--' + name, required=True)
parser.add_argument('--run-id', type=int, required=True)
parser.add_argument('--artifact-id', type=int, required=True)
parser.add_argument('--node', default='node', help='Node 22 executable used to rerun the production evaluator')
args = parser.parse_args()
REV = args.revision
require(re.fullmatch('[a-f0-9]{40}', REV), 'Full adopted revision required')
require(re.fullmatch('[a-f0-9]{64}', args.candidate_sha256), 'Explicit reviewed candidate digest required')
require(git('rev-parse', 'HEAD').decode().strip() == REV, 'HEAD differs from adopted revision')
require(not git('status', '--porcelain', '--untracked-files=no').strip(), 'Tracked worktree must be frozen')
prefix = local(args.output_prefix)
require(prefix.is_relative_to(REPORTS) and prefix != REPORTS, 'Output must remain under ignored reports')
outputs = [pathlib.Path(str(prefix) + suffix) for suffix in ['.tar.gz', '-manifest.json', '-check.json']]
require(all(not p.exists() for p in outputs), 'Refusing to overwrite an existing output')

candidate_bytes = local(args.candidate).read_bytes()
require(sha(candidate_bytes) == args.candidate_sha256, 'Candidate differs from explicitly reviewed digest')
candidate = json.loads(candidate_bytes)
side_path = args.candidate + '.evidence.json'
side = readjson(side_path)
authority = readjson(args.authority)
new_finding_review = readjson(args.new_finding_review)
verification = readjson(args.verification)
archive_check = readjson(args.archive_check)
evaluation = readjson(args.evaluator)
require(candidate['reviewedRevision'] == side['sourceRevision'] == authority['revision'] == verification['revision'] == REV, 'Revision binding differs')
require(side['candidateOnly'] is True, 'Not a candidate evidence sidecar')
require(local(side['authorityReviewPath']) == local(args.authority), 'Wrong separately reviewed authority')
require(local(side['newFindingReviewPath']) == local(args.new_finding_review), 'Wrong explicit new-finding review')
for review_path in [args.authority, args.new_finding_review]:
    bound_reviews = [ref for ref in side['reviews'] if local(ref['path']) == local(review_path)]
    require(len(bound_reviews) == 1 and bound_reviews[0]['sha256'] == sha(local(review_path).read_bytes()), 'Separate review absent or changed in candidate sidecar')
require(evaluation == side['evaluation'], 'Evaluator output differs from candidate evaluation')
require((evaluation['resultCount'], evaluation['reviewedFalsePositives'], evaluation['acceptedRisks'], evaluation['remaining']) == (86, 82, 4, 0), 'Classification changed; manual review required')
require(len(candidate['entries']) == len({e['findingId'] for e in candidate['entries']}) == 86, 'Finding identities changed')
require(candidate['reviewedCount'] == 86 and candidate['counts'] == {'false-positive': 82, 'open': 4}, 'Candidate count contract differs')
require(sum(e['disposition'] == 'false-positive' for e in candidate['entries']) == 82 and sum(e['disposition'] == 'open' for e in candidate['entries']) == 4, 'Disposition policy changed')
require(git('rev-parse', REV + '^{tree}') == git('rev-parse', side['scannedRevision'] + '^{tree}'), 'Scanned tree differs; fresh scan required')
status = readjson(side['status']['path'])
require(status['revision'] == side['scannedRevision'] and status['scope'] == 'code' and status['scannerVersion'] == '1.1307.1' and status['scannerExit'] in [0, 1] and status['resultCount'] == 86, 'Invalid scanner completion')
require(sha(local(side['sarif']['path']).read_bytes()) == candidate['sarifSha256'], 'Candidate SARIF digest differs')
# The only permitted addition is the individually reviewed synthetic fixture finding.
new_id = '40aa77d4-0842-4520-885d-a108e083d3a0'
require(new_finding_review['revision'] == REV and new_finding_review['kind'] == 'explicit-single-new-finding-review'
        and new_finding_review['reviewer'] == 'root independent of test author', 'Independent revision-bound fixture review required')
require(new_finding_review['sarif']['sha256'] == candidate['sarifSha256']
        and sha(local(new_finding_review['sarif']['path']).read_bytes()) == candidate['sarifSha256'], 'Fixture review SARIF binding differs')
new_entry = new_finding_review['entry']
require(new_entry['findingId'] == new_id and new_entry['ruleId'] == 'javascript/HardcodedNonCryptoSecret/test'
        and new_entry['path'] == 'frontend/tests/telegram-settings-coverage.test.tsx'
        and new_entry['disposition'] == 'false-positive', 'Unapproved new finding')
entries = {entry['findingId']: entry for entry in candidate['entries']}
require(entries.get(new_id) == new_entry, 'Candidate differs from independently reviewed exact new entry')
reference_path = 'reports/findings-review/snyk-fbc3517-ci/snyk-code-234ffdddcfac211e4f3f588de0191df622b7c311/code.sarif.json'
reference = [result for run_item in readjson(reference_path)['runs'] for result in run_item['results']]
results = [result for run_item in readjson(side['sarif']['path'])['runs'] for result in run_item['results']]
finding_id = lambda result: result['fingerprints']['snyk/asset/finding/v1']
refs = {finding_id(result): result for result in reference}
scanned = {finding_id(result): result for result in results}
require(len(reference) == len(refs) == 85 and len(results) == len(scanned) == 86, 'Duplicate or unexpected finding set')
require(set(scanned) == set(entries) == set(refs) | {new_id} and new_id not in refs, 'Historical finding removed or another finding added')

def normalized(value):
    if isinstance(value, list):
        return [normalized(item) for item in value]
    if isinstance(value, dict):
        return {key: normalized(item) for key, item in value.items() if key != 'region'}
    return value

def flow(result):
    return {'locations': result['locations'], 'relatedLocations': result.get('relatedLocations', []), 'codeFlows': result.get('codeFlows', [])}

for key, prior in refs.items():
    current = scanned[key]
    require(current['ruleId'] == prior['ruleId'] and normalized(flow(current)) == normalized(flow(prior)), 'Historical structural flow changed: ' + key)
require(scanned[new_id]['fingerprints'] == new_entry['fingerprints'], 'New finding fingerprint map differs')
new_location = scanned[new_id]['locations'][0]['physicalLocation']
require(new_location['artifactLocation']['uri'] == new_entry['path'] and new_location['region']['startLine'] == new_entry['line'], 'New finding location differs')
flow_locations = [*scanned[new_id]['locations'], *scanned[new_id].get('relatedLocations', [])]
for code_flow in scanned[new_id].get('codeFlows', []):
    for thread_flow in code_flow['threadFlows']:
        flow_locations.extend(step['location'] for step in thread_flow['locations'])
require([{'path': loc['physicalLocation']['artifactLocation']['uri'], 'line': loc['physicalLocation'].get('region', {}).get('startLine')}
         for loc in flow_locations] == new_entry['codeFlowLocations'], 'New finding reviewed flow locations differ')
# The production evaluator below validates exact evidenceDigest, source/context bytes and acceptance.
# Recheck live expiration and actual evaluator contracts, not just saved result counts.
evaluate_js = """
import fs from 'node:fs';
import {evaluateSnykCode,loadHttpRiskAcceptance} from './scripts/check_snyk_code_review.js';
const [candidatePath,sarifPath,scannerExit]=process.argv.slice(1);
const result=await evaluateSnykCode({review:JSON.parse(fs.readFileSync(candidatePath)),
 sarif:JSON.parse(fs.readFileSync(sarifPath)),scannerExit:Number(scannerExit),
 readSource:async p=>fs.readFileSync(p),acceptance:await loadHttpRiskAcceptance(process.cwd())});
console.log(JSON.stringify(result));
"""
fresh_evaluation = json.loads(subprocess.check_output([args.node, '--input-type=module', '-e', evaluate_js,
    str(local(args.candidate)), str(local(side['sarif']['path'])), str(status['scannerExit'])]))
require(fresh_evaluation == evaluation, 'Fresh production evaluator no longer matches reviewed evidence')

run = readjson(args.actions_run)
artifacts = readjson(args.actions_artifacts)['artifacts']
matches = [a for a in artifacts if a['id'] == args.artifact_id]
require(len(matches) == 1, 'Artifact ID absent or ambiguous')
artifact = matches[0]
require(run['id'] == args.run_id and run['head_sha'] == REV and run['status'] == 'completed', 'Wrong or incomplete Actions run')
require(artifact['name'] == 'snyk-code-' + side['scannedRevision'] and not artifact['expired'], 'Wrong or expired Code artifact')
require(artifact['workflow_run']['id'] == args.run_id and artifact['workflow_run']['head_sha'] == REV, 'Artifact belongs to another run')

payload = {}
manifest_files = []
references = []
recorded = set()

def include(value, expected=None):
    p = local(value)
    data = p.read_bytes()
    if expected is not None:
        require(re.fullmatch('[a-f0-9]{64}', expected) and sha(data) == expected, 'Reference changed: ' + str(value))
    relative = p.relative_to(ROOT).as_posix()
    if relative not in recorded:
        member = 'review/' + p.relative_to(REPORTS).as_posix() if p.is_relative_to(REPORTS) else 'review/repository/' + relative
        require(member not in payload, 'Archive member collision')
        payload[member] = data
        manifest_files.append({'member': member, 'path': relative, 'sha256': sha(data), 'bytes': len(data)})
        recorded.add(relative)
    if expected is not None:
        references.append({'path': relative, 'sha256': expected})

for value in [args.candidate, side_path, args.authority, args.new_finding_review, args.verification, args.archive_check,
              args.evaluator, args.actions_run, args.actions_artifacts,
              'reports/findings-review/prepare-snyk-final-v7-candidate.mjs',
              'reports/findings-review/pack-snyk-final-v7-evidence.py']:
    include(value)
for ref in [side['sarif'], side['status'], *side['reviews'], *authority['evidence']]:
    include(ref['path'], ref['sha256'])

# Preserve the historical review/test closure; it is evidence, never renewed authority.
historical = ['snyk-historical-95d6666c.sarif.json', 'snyk-prior-operative-95d6666c.json',
    'snyk-fbc3517-flow-comparison.json', 'compare-snyk-flow.mjs', 'independent144-test-ast.json',
    'restored-direct-rejects159.json', 'wrapper-api-ast-proofs.json', 'restored-indirect-async-fixtures10.json',
    'direct-rejects159-execution.json', 'direct-rejects159.log', 'indirect-async10-execution.json',
    'indirect-async10.log', 'test-restoration-eslint.log', 'review144.mjs', 'restore-direct-rejects159.mjs',
    'verify-direct-rejects159.mjs', 'verify-indirect-async10.mjs', 'snyk-independent-production.diff',
    'snyk-independent-tests.diff',
    'snyk-fbc3517-ci/snyk-code-234ffdddcfac211e4f3f588de0191df622b7c311/code.sarif.json',
    'snyk-fbc3517-ci/snyk-code-234ffdddcfac211e4f3f588de0191df622b7c311/code.status.json']
for name in historical:
    include('reports/findings-review/' + name)
require(verification['rows'] and all(row['exitCode'] == 0 for row in verification['rows']), 'Adoption verification failed')
for row in verification['rows']:
    include(row['log'], row['logSha256'])
require(verification['receiptSha256'] == authority['receipt']['sha256'] and verification['authoritySha256'] == authority['authority']['sha256'], 'Verification used different receipt or authority')
require(archive_check['everyMemberReadBack'] is True and archive_check['independentRebuildByteIdentical'] is True and archive_check['unresolvedReferences'] == 0, 'Incomplete independent receipt archive verification')
archive_path = local(args.receipt_archive).relative_to(ROOT).as_posix()
archive_bytes = git('show', REV + ':' + archive_path)
require(sha(archive_bytes) == archive_check['archive']['sha256'], 'Committed receipt archive differs from independently verified archive')
payload['archive/receipt-evidence.tar.gz'] = archive_bytes

bindings = {}
def bind(p, h):
    require(p not in bindings or bindings[p] == h, 'Conflicting source binding: ' + p)
    bindings[p] = h

for entry in candidate['entries']:
    for binding in [{'path': entry['path'], 'sha256': entry['reviewedSourceSha256']}, *entry['contextPaths']]:
        bind(binding['path'], binding['sha256'])
for binding in [authority['receipt'], authority['authority']]:
    bind(binding['path'], binding['sha256'])
for p in ['scripts/check_snyk_code_review.js', 'scripts/check_risk_acceptances.js',
          'docs/risk-acceptances/RA-2026-09-08-internal-http.md',
          'exchange_executor/certifications/reviews/findings-1bda99a-archive-verifier.py']:
    bind(p, sha(git('show', REV + ':' + p)))
require(bindings['docs/risk-acceptances/RA-2026-09-08-internal-http.md'] == '7b5076bdd1d9e4dd40ddf44d5096310f0fd0ccb6466c32a602a48d68b76634ff', 'Owner acceptance changed; never extend or renew automatically')
source_refs = []
for p, h in sorted(bindings.items()):
    require(not pathlib.PurePosixPath(p).is_absolute() and all(part not in ['', '.', '..'] for part in p.split('/')) and '\\' not in p, 'Unsafe source member')
    data = git('show', REV + ':' + p)
    require(sha(data) == h, 'Source binding differs: ' + p)
    member = 'source/' + p
    payload[member] = data
    source_refs.append({'path': p, 'revision': REV, 'member': member, 'sha256': h, 'bytes': len(data)})

manifest = {'schemaVersion': 1, 'kind': 'snyk-bounded-delta-evidence-archive',
    'reviewedRevision': REV, 'scannedRevision': side['scannedRevision'], 'candidateSha256': sha(candidate_bytes),
    'actionsRun': run, 'artifact': artifact, 'files': sorted(manifest_files, key=lambda f: f['member']),
    'sourceBindings': source_refs, 'declaredReferences': references,
    'receiptEvidenceArchive': {'path': archive_path, 'member': 'archive/receipt-evidence.tar.gz', 'sha256': sha(archive_bytes)},
    'explicitNewFindingReview': {'path': local(args.new_finding_review).relative_to(ROOT).as_posix(), 'sha256': sha(local(args.new_finding_review).read_bytes()), 'findingId': new_id},
    'adoptedReceipt': authority['receipt'], 'reviewedAuthority': authority['authority'],
    'classification': {'reviewedFalsePositives': 82, 'acceptedOpenRisks': 4, 'remaining': 0, 'acceptanceExpires': '2026-10-08'},
    'scope': 'Exact explicitly adopted revision and same-tree fresh Actions scan: 85 historical structural flows plus one exact independently reviewed synthetic fixture finding. Subsequent evidence adoption is outside source bindings; final Actions scan must reject any other new finding. Embedded receipt archive carries upstream receipt/test closure. Historical narratives are evidence, not renewed authority.',
    'unresolvedDeclaredReferences': []}
manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
payload['manifest.json'] = manifest_bytes

def build():
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for name, data in sorted(payload.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o444
            member.uid = member.gid = member.mtime = 0
            member.uname = member.gname = ''
            tar.addfile(member, io.BytesIO(data))
    target = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0, compresslevel=9) as stream:
        stream.write(buffer.getvalue())
    return target.getvalue()

first = build()
require(first == build(), 'Independent deterministic builds differ')
with tarfile.open(fileobj=io.BytesIO(first), mode='r:gz') as tar:
    members = tar.getmembers()
    require(len(members) == len(payload) == len({m.name for m in members}), 'Duplicate or missing archive member')
    for member in members:
        require(member.isfile() and member.mode == 0o444 and member.uid == member.gid == member.mtime == 0 and not member.uname and not member.gname, 'Unsafe archive metadata')
        require(tar.extractfile(member).read() == payload[member.name], 'Member readback differs')
report = {'reviewedRevision': REV, 'archiveSha256': sha(first), 'archiveBytes': len(first), 'members': len(payload),
    'sourceBindings': len(source_refs), 'reportFiles': len(manifest_files), 'doubleBuildByteIdentical': True,
    'everyMemberReadBack': True, 'allDeclaredReferenceHashesVerified': True, 'operativeChanged': False}
for destination, data in zip(outputs, [first, manifest_bytes, (json.dumps(report, indent=2) + '\n').encode()]):
    with destination.open('xb') as stream:
        stream.write(data)
print(json.dumps(report, indent=2))
