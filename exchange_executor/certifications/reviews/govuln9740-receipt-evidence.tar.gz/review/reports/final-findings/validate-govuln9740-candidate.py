"""Independent read-only review of the unadopted govuln9740 receipt candidate."""
import argparse
import datetime
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

from receipt_renewal_safety_candidate import plain_local, check_command_inventory, check_group_inventory

ROOT = Path.cwd().resolve()
OUT = ROOT / 'reports/final-findings'
HEAD = '9740c2973e1cd71e16bbf597cc22a88a12860118'
PREV = '1258689ef1ed92dcbc9a5a2f0a79dcf6a46af18a'
CURRENT_TREE = '9f2c35de40444d51a00d6dfbb9d1581f3ca0152e18af09ec4e63d8dadcd14b76'
ARCHIVE = ROOT / 'exchange_executor/certifications/reviews/final-sonar-vendored-1258689e-receipt-evidence.tar.gz'
ARCHIVE_SHA = '1d446d22c7b7bb13327fc705cd83d5d1d0f6c0e8036c17ac62b00ee0a46b6913'
RECEIPT_SHA = 'e80181c487e9e48d0dd26092558735c60d2c914125c0d85cb7e7aaa0a9519c91'
PINS_SHA = 'a82912c2049d0594cd9f3d2cf98256b5a82ab2dea98538215f3e146f08da31da'
NODE = 'C:/Users/nikla/AppData/Local/Programs/node22/node-v22.23.2-win-x64/node.exe'
PYTHON = str(ROOT.parent / 'tsx-security-python-env/Scripts/python.exe')
GROUPS = ['foundation', 'backend', 'python', 'frontend', 'build', 'browser', 'mutations', 'dependencies']
DELTAS = {'monitoring/govulncheck/go.mod', 'monitoring/govulncheck/go.sum',
          'monitoring/vex/README.md', 'tests/test_monitoring_artifacts.js',
          'tests/test_supply_chain.js'}
MUTATION_SOURCES = {
    'queue': ('src/queue.ts', 'node --import tsx tests/test_queue.js'),
    'retry': ('src/tdlib_retry.ts', 'node --import tsx tests/test_tdlib_retry.js'),
    'schema': ('src/signal_schema.ts', 'node --import tsx tests/test_signal_parser.js && node --import tsx tests/test_signal_contract_validation.js'),
    'trading-risk': ('src/trading_risk.ts', 'node --import tsx tests/test_trading_core.js && node --import tsx tests/test_trading_leverage_tiers.js'),
}
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key')
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))


def bytes_at(path):
    p = plain_local(ROOT, path)
    require(p.stat().st_size <= 256 * 1024 * 1024, 'Evidence file too large')
    return p.read_bytes()


def read(path):
    return parse(bytes_at(path))


def binding(path):
    p = plain_local(ROOT, path)
    return {'path': p.relative_to(ROOT).as_posix(), 'sha256': sha(bytes_at(p))}


def bound(value):
    require(set(value) == {'path', 'sha256'}, 'Reference schema differs')
    p = plain_local(ROOT, value['path'])
    require(binding(p) == value, 'Reference bytes differ: ' + value['path'])
    return p


def ts(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))


def sealed(archive, name):
    require(sha(bytes_at(archive)) == ARCHIVE_SHA, 'Sealed predecessor archive changed')
    with tarfile.open(archive, 'r:gz') as handle:
        members = handle.getmembers()
        require(len(members) <= 20000 and len({m.name for m in members}) == len(members),
                'Ambiguous sealed archive')
        member_name = 'review/reports/final-findings/' + name
        member = handle.getmember(member_name)
        require(member.isfile() and not member.issym() and not member.islnk(), 'Invalid historical member')
        raw = handle.extractfile(member).read()
    return parse(raw), {'archive': binding(archive), 'member': member_name, 'sha256': sha(raw)}


def check_source(state, candidate, parity, execution):
    require(state['revision'] == HEAD and state['operativeReceiptApproved'] is False
            and state['operativeReceiptOrPinsChanged'] is False,
            'Candidate state claims operative authority')
    require(sha(bytes_at(ROOT/'exchange_executor/certifications/hyperliquid.json')) == RECEIPT_SHA
            and sha(bytes_at(ROOT/'exchange_executor/ccxt_implementation_reviews.py')) == PINS_SHA,
            'Operative receipt or approval pins changed')
    require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == HEAD,
            'Wrong frozen source revision')
    require(not subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).strip(),
            'Tracked working tree changed')
    prior = read(ROOT/'exchange_executor/certifications/hyperliquid.json')
    old_context, context_ref = sealed(ARCHIVE, 'receipt-context-sonar125-after.json')
    old_parity, parity_ref = sealed(ARCHIVE, 'final-sonar-vendored-1258689e-receipt-parity-supplement.json')
    old_candidate, old_candidate_ref = sealed(ARCHIVE, 'final-sonar-vendored-1258689e-hyperliquid-receipt-candidate.json')
    require(old_candidate == prior and old_candidate_ref['sha256'] == RECEIPT_SHA
            and prior['parityEvidenceHash'] == parity_ref['sha256']
            and old_context['revision'] == old_parity['revision'] == prior['sourceRevision'] == PREV,
            'Sealed predecessor differs from operative receipt')
    script = "import {collectBuildInputs} from './scripts/verify_exchange_implementation.js';console.log(JSON.stringify(collectBuildInputs(process.cwd())));"
    inputs = parse(subprocess.check_output([NODE,'--input-type=module','-e',script]))
    require(inputs['sourceTreeHash'] == CURRENT_TREE and len(inputs['files']) == 1002,
            'Current exact source tree differs')
    old = {r['path']:r['sha256'] for r in old_context['inputs']['files']}
    now = {r['path']:r['sha256'] for r in inputs['files']}
    changes = [{'path':p,'beforeSha256':old.get(p),'currentSha256':now.get(p),
                'status':'modified' if p in old and p in now else 'added' if p in now else 'removed'}
               for p in sorted(set(old)|set(now)) if old.get(p)!=now.get(p)]
    require(len(changes) == 5 and {r['path'] for r in changes} == DELTAS
            and set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines()) == DELTAS,
            'Independent five-file source delta differs')
    review = read(bound(state['completeSourceReview']))
    delta = read(bound(review['deltas']))
    require(delta['revision'] == review['revision'] == HEAD
            and delta['predecessorContext'] == context_ref and delta['deltas'] == changes
            and review['reviewed'] is True and review['providerAcceptanceVerified'] is False,
            'Source-review bindings differ')
    rows = {r['path']:r for r in review['reviews']}
    require(len(rows) == len(review['reviews']) == 5 and set(rows) == DELTAS,
            'Incomplete five-file source review')
    for change in changes:
        row = rows[change['path']]
        require(all(row[key] == change[key] for key in ('beforeSha256','currentSha256','status'))
                and row['reviewed'] is True and row['rationale'].strip() and row['evidence'],
                'Unreviewed individual source change')
        for evidence in row['evidence']:
            bound(evidence)
    prev = {(r['category'],r['check']):r for r in old_parity['rows']}
    current = {(r['category'],r['check']):r for r in parity['rows']}
    require(len(prev) == len(current) == 62 and set(prev) == set(current)
            and parity['priorParity'] == parity_ref
            and parity['counts'] == {'requirements':62,'witnessReferences':97,
                                     'changedWitnessReferences':0,'unchangedWitnessReferences':97},
            'Exact requirement identity inventory changed')
    count = 0
    for key, row in current.items():
        prior_w = prev[key]['witnessBindings']
        require(row['witnessBindings'] == prior_w and row['completeSourceReview'] == state['completeSourceReview']
                and row['currentExecution'] == state['execution']
                and row['sealedPriorRow'] == {'evidence':parity_ref,'lookup':{'category':key[0],'check':key[1]}},
                'Witness path/hash or row provenance changed')
        for witness in prior_w:
            require(old[witness['path']] == now[witness['path']] == witness['sha256'],
                    'Changed historical witness')
            count += 1
    require(count == 97, 'Historical witness count differs')
    require(candidate['sourceRevision'] == HEAD and candidate['sourceTreeHash'] == CURRENT_TREE
            and candidate['parityEvidenceHash'] == state['parity']['sha256']
            and candidate['executionReportHash'] == state['execution']['sha256'],
            'Candidate source or evidence commitment differs')
    for key in ('schemaVersion','kind','exchange','ccxtVersion','profileVersion','profileHash','scope','providerAcceptanceVerified'):
        require(candidate[key] == prior[key], 'Receipt scope/identity changed: ' + key)
    for key in ('nodeSourcesHash','testSourcesHash','fixturesHash'):
        require(candidate[key] == inputs[key], 'Candidate input commitment differs: ' + key)
    return inputs, 97


def check_execution(execution, inputs):
    require(execution['revision'] == HEAD and execution['providerAcceptanceVerified'] is False
            and execution['operativeReceiptApproved'] is False
            and execution['pythonExecutionInheritance'] is False
            and execution['beforeContextPresent'] is False,
            'Execution claims unsupported authority or before context')
    progress = read(bound(execution['progressContext']))
    after = read(bound(execution['afterContext']))
    require(all(c['revision'] == HEAD and c['inputs'] == inputs and c['rawEqualsGit']
                and c['allInputsSingleLink'] and c['sourceStableDuringCapture'] for c in (progress,after))
            and progress['runtime'] == after['runtime'] == execution['runtime']
            and ts(progress['observedAt']) <= ts(after['startedAt']),
            'Intermediate/final Git context differs')
    groups = execution['groups']
    check_group_inventory(groups)
    actual = {}
    for entry in groups:
        group = entry['group']
        require(entry['report']['path'] == f'reports/final-findings/verification-{group}-govuln9740.json'
                and entry['originalAllCommandsPassed'] is True and not entry['reviewedReplacements']
                and not entry['preservedEarlierAttempts'] and entry['attemptSelection'] is None,
                'Unreviewed selected verification attempt')
        report = read(bound(entry['report']))
        check_command_inventory(report,ROOT,NODE)
        require(report['group'] == group and report.get('completedAt')
                and report['allCommandsPassed'] is True and report['observedInputsUnchanged'] is True
                and report['revision'] == report['revisionAfter'] == HEAD
                and report['inputsBefore'] == report['inputsAfter'] == inputs
                and report['runtime']['node'] == after['runtime']['node']
                and report['runtime']['ccxt'] == after['runtime']['ccxt']
                and report['runtime']['python'] == 'Python '+after['runtime']['python'].split()[0]
                and ts(report['completedAt']) <= ts(after['startedAt']),
                'Verification report not terminal, passing, current and pre-final: ' + group)
        require(len(entry['logs']) == len(report['commands'])
                and all(type(c['exitCode']) is int and c['exitCode'] == 0
                        and c.get('signal') is None and not c.get('error') for c in report['commands']),
                'Group contains failed or omitted command: ' + group)
        for item, log in zip(report['commands'], entry['logs']):
            require(item['log'] == f"reports/final-findings/verification-{item['name']}-govuln9740.log"
                    and log == {'path':item['log'],'sha256':item['logSha256']}
                    and bound(log)
                    and ts(report['startedAt']) <= ts(item['startedAt'])
                    <= ts(item['completedAt']) <= ts(report['completedAt']),
                    'Verification log identity/time/hash differs')
        if group == 'foundation':
            mon = report['monitoringExecution']
            require(mon['mode'] == 'native-configuration-only'
                    and mon['containerAcceptanceVerified'] is False
                    and [t['key'] for t in mon['tools']] == ['PROMTOOL_PATH','AMTOOL_PATH'],
                    'Foundation native monitoring context differs')
            for tool in mon['tools']:
                require(sha(Path(tool['executable']).read_bytes()) == tool['sha256']
                        and tool['version'].strip(), 'Native monitoring executable changed')
        actual[group] = report
    mutation = actual['mutations']
    require(ts(mutation['startedAt']) <= ts(progress['startedAt'])
            <= ts(progress['observedAt']) <= ts(mutation['completedAt']),
            'Progress context was not an intermediate mutation observation')
    return len(groups), len(actual['foundation']['commands'])


def check_mutation_artifacts(state, inputs):
    artifacts = state['mutationArtifacts']
    expected = ['queue','retry','schema','trading-risk']
    require([row['shard'] for row in artifacts] == expected,
            'Mutation shard artifact inventory differs')
    report = read(OUT/'verification-mutations-govuln9740.json')
    require(len(report['commands']) == 1 and report['commands'][0]['name'] == 'mutations',
            'Mutation command identity differs')
    command = report['commands'][0]
    log = (OUT/'verification-mutations-govuln9740.log').read_text(encoding='utf-8-sig')
    source_hashes = {r['path']:r['sha256'] for r in inputs['files']}
    last_mtime = None
    for row in artifacts:
        shard = row['shard']
        mutate_path, expected_command = MUTATION_SOURCES[shard]
        require(row['selectedCurrentRun']['path'] ==
                f"reports/final-findings/mutation-artifacts-govuln9740/{shard}.json"
                and row['selectedCurrentRun']['sha256'] == row['sourceSha256AtCapture'],
                'Mutation artifact source/hash binding differs')
        artifact = read(bound(row['selectedCurrentRun']))
        config = artifact['config']
        require(artifact['schemaVersion'] == '1.0'
                and artifact['projectRoot'] == str(ROOT)
                and list(artifact['files']) == [mutate_path]
                and config['mutate'] == [mutate_path]
                and config['jsonReporter']['fileName'] == f'reports/mutation/{shard}.json'
                and config['testRunner'] == 'command'
                and config['commandRunner']['command'] == expected_command
                and config['coverageAnalysis'] == 'off'
                and config['incremental'] is False and config['force'] is True
                and artifact['thresholds'] == config['thresholds']
                == {'high':80,'low':70,'break':70},
                'Mutation artifact config does not match exact shard')
        original = artifact['files'][mutate_path]
        require(original['source'].encode('utf-8') == bytes_at(ROOT/mutate_path)
                and sha(original['source'].encode('utf-8')) == source_hashes[mutate_path],
                'Mutation artifact source differs from frozen Git')
        mutants = original['mutants']
        ids = [m['id'] for m in mutants]
        statuses = [m['status'] for m in mutants]
        require(mutants and len(ids) == len(set(ids))
                and set(statuses) <= {'Killed','Timeout','Survived'},
                'Mutation identities/statuses differ')
        counts = {status:statuses.count(status) for status in ('Killed','Timeout','Survived')}
        score = Decimal(100)*Decimal(counts['Killed']+counts['Timeout'])/Decimal(len(mutants))
        score_text = str(score.quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))
        marker = f'=== Mutation shard: {shard} ==='
        require(score >= Decimal(70) and row['mutantCounts'] == counts
                and row['mutationScorePercent'] == score_text and log.count(marker) == 1,
                'Mutation score or log marker differs')
        section = log.split(marker,1)[1].split('=== Mutation shard:',1)[0]
        logged_score = re.findall(r'Final mutation score of ([0-9]+\.[0-9]+) is greater than or equal to break threshold 70',section)
        instrumented = re.findall(r'Instrumented 1 source file\(s\) with (\d+) mutant\(s\)',section)
        require(logged_score == [score_text] and instrumented == [str(len(mutants))],
                'Mutation JSON score/count differs from run log')
        source_path = f'reports/mutation/{shard}.json'
        require(row['sourcePath'] == source_path, 'Mutation source path differs')
        source = plain_local(ROOT,source_path)
        mtime_ns = source.stat().st_mtime_ns
        mtime = datetime.datetime.fromtimestamp(mtime_ns/1_000_000_000,datetime.timezone.utc)
        require(sha(source.read_bytes()) == row['sourceSha256AtCapture']
                and mtime_ns == row['sourceMtimeNs']
                and ts(command['startedAt']) <= mtime <= ts(command['completedAt'])
                and (last_mtime is None or mtime_ns > last_mtime),
                'Mutation JSON was not written in ordered current command window')
        last_mtime = mtime_ns
    return len(artifacts)


def closure(state_path):
    queue = [state_path]
    visited = {}
    current = {}
    historical = {}
    def walk(value):
        if isinstance(value,list):
            for item in value: walk(item)
        elif isinstance(value,dict):
            if isinstance(value.get('archive'),dict) and isinstance(value.get('member'),str):
                archive = bound(value['archive']); member = value['member']
                require(not member.startswith('/') and '..' not in Path(member).parts
                        and '\\' not in member, 'Unsafe historical member')
                with tarfile.open(archive,'r:*') as handle:
                    entries = handle.getmembers()
                    require(len(entries) <= 20000 and len({e.name for e in entries}) == len(entries),
                            'Ambiguous historical archive')
                    item = handle.getmember(member)
                    require(item.isfile() and not item.issym() and not item.islnk()
                            and sha(handle.extractfile(item).read()) == value['sha256'],
                            'Historical member differs')
                historical[value['archive']['path']+':'+member] = value
                return
            if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
                item = {'path':value['path'],'sha256':value['sha256']}
                p = bound(item)
                current[item['path']] = item
                if p.is_relative_to(OUT): queue.append(p)
            if isinstance(value.get('log'),str) and isinstance(value.get('logSha256'),str):
                walk({'path':value['log'],'sha256':value['logSha256']})
            for item in value.values(): walk(item)
    while queue:
        p = plain_local(ROOT,queue.pop())
        relative = p.relative_to(ROOT).as_posix()
        if relative in visited: continue
        require(len(visited) < 20000, 'Current reference graph too large')
        raw = bytes_at(p);visited[relative] = sha(raw)
        if p.suffix == '.json': walk(parse(raw))
    for path,digest in visited.items():
        require(sha(bytes_at(ROOT/path)) == digest, 'Evidence changed during reference walk')
    return {'currentReports':len(visited),'currentReferences':len(current),
            'historicalMembers':len(historical),'unresolvedReferences':0}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--state', default='reports/final-findings/govuln9740-receipt-candidate-state.json')
    args = parser.parse_args()
    state_path = plain_local(ROOT,args.state)
    state = read(state_path)
    candidate_path = bound(state['candidate'])
    candidate = read(candidate_path)
    parity = read(bound(state['parity']))
    execution = read(bound(state['execution']))
    inputs,witnesses = check_source(state,candidate,parity,execution)
    groups,foundation = check_execution(execution,inputs)
    artifacts = check_mutation_artifacts(state,inputs)
    network = closure(state_path)
    py = subprocess.check_output([PYTHON,'-I','-B','-c',
        "import sys,json;from pathlib import Path;r=Path(sys.argv[1]);p=Path(sys.argv[2]);sys.path.insert(0,str(r/'exchange_executor'));import ccxt;from ccxt_certification_evidence import validate_receipt;from ccxt_profiles import PROFILES;validate_receipt(json.loads(p.read_bytes()),'hyperliquid',ccxt.__version__,PROFILES['hyperliquid'],r/'exchange_executor',Path(ccxt.__file__).parent);print('PASS')",
        str(ROOT),str(candidate_path)],text=True).strip()
    require(py == 'PASS', 'Production Python receipt validator did not pass')
    node_script = "import fs from 'node:fs';import {compareBuildReceipt} from './scripts/verify_exchange_implementation.js';const r=compareBuildReceipt(fs.readFileSync("+json.dumps(str(candidate_path))+") ,{root:process.cwd(),exchange:'hyperliquid',profileVersion:1,approvedReceiptHashes:["+json.dumps(state['candidate']['sha256'])+"]});console.log(JSON.stringify(r));"
    comparison = parse(subprocess.check_output([NODE,'--input-type=module','-e',node_script]))
    require(comparison['buildInputsMatch'] is True and comparison['sourceTreeHash'] == inputs['sourceTreeHash']
            and all(comparison[key] is False for key in ('runtimeReceiptVerified','implementationVerified',
                    'providerAcceptanceVerified','performedGateExecution')),
            'Node comparison overclaims approval or differs from frozen inputs')
    require(sha(bytes_at(ROOT/'exchange_executor/certifications/hyperliquid.json')) == RECEIPT_SHA
            and sha(bytes_at(ROOT/'exchange_executor/ccxt_implementation_reviews.py')) == PINS_SHA,
            'Operative authority changed during independent review')
    print(json.dumps({'revision':HEAD,'sourceDeltas':5,'requirements':62,'witnesses':witnesses,
                      'terminalGreenGroups':groups,'foundationCommands':foundation,
                      'mutationArtifacts':artifacts,
                      'referenceClosure':network,'productionPythonValidation':py,
                      'productionNodeBuildInputsMatch':True,
                      'beforeContextPresent':False,'candidateApproved':False,
                      'operativeReceiptOrPinsChanged':False}))


if __name__ == '__main__':
    main()
