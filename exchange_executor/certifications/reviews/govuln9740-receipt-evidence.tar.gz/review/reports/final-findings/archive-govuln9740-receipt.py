"""Deterministically seal a separately approved offline receipt review.

Requires a completed candidate, an independent validator-bound review, and
explicit bounded root approval. Does not install a receipt or approval pin.
"""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile

from receipt_renewal_safety_candidate import plain_local

ROOT = Path.cwd().resolve()
OUT = ROOT / 'reports/final-findings'
REVISION = '9740c2973e1cd71e16bbf597cc22a88a12860118'
SOURCE_REVIEW_HASH = '24dc444297a07483777ef8900de20bfa5a3ca91888c3c67078ff8f24595cbd7b'
PREVIOUS_RECEIPT_HASH = 'e80181c487e9e48d0dd26092558735c60d2c914125c0d85cb7e7aaa0a9519c91'
PREVIOUS_PINS_HASH = 'a82912c2049d0594cd9f3d2cf98256b5a82ab2dea98538215f3e146f08da31da'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def safe(path):
    return plain_local(ROOT, path)


def unique(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, 'Duplicate JSON key')
        value[key] = item
    return value


def parse(raw):
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))


def read(path):
    return parse(safe(path).read_bytes())


def ref(path):
    p = safe(path)
    return {'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p.read_bytes())}


def check_authority():
    require(sha(safe(ROOT/'exchange_executor/certifications/hyperliquid.json').read_bytes()) == PREVIOUS_RECEIPT_HASH,
            'Operative receipt changed')
    require(sha(safe(ROOT/'exchange_executor/ccxt_implementation_reviews.py').read_bytes()) == PREVIOUS_PINS_HASH,
            'Operative approval pins changed')
    require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == REVISION,
            'Frozen source revision changed')
    require(not subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).strip(),
            'Tracked working tree changed')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--review', required=True, type=Path)
    parser.add_argument('--approval', required=True, type=Path)
    parser.add_argument('--validator-sha256', required=True)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    check_authority()
    validator_path = OUT/'validate-govuln9740-candidate-v2.py'
    require(ref(validator_path)['sha256'] == args.validator_sha256,
            'Independent validator hash changed')
    source_path = OUT/'govuln9740-receipt-source-review-root-v2.json'
    require(ref(source_path)['sha256'] == SOURCE_REVIEW_HASH,
            'Complete source review v2 changed')
    state_path = OUT/'govuln9740-receipt-candidate-state.json'
    state = read(state_path)
    require(state['revision'] == REVISION and state['completeSourceReview'] == ref(source_path)
            and state['operativeReceiptApproved'] is False
            and state['operativeReceiptOrPinsChanged'] is False,
            'Candidate state is not the unadopted reviewed revision')
    require(safe(args.review).is_relative_to(OUT) and safe(args.approval).is_relative_to(OUT),
            'Reviews must be ignored local evidence')
    review = read(args.review)
    approval = read(args.approval)
    require(review['revision'] == REVISION and approval['revision'] == REVISION
            and review['candidate'] == approval['candidate'] == state['candidate']
            and review['completeSourceReview'] == approval['completeSourceReview'] == state['completeSourceReview']
            and review['reviewValidator'] == ref(validator_path)
            and review['providerAcceptanceVerified'] is False
            and approval['providerAcceptanceVerified'] is False
            and approval['operativeReceiptOrPinsChanged'] is False,
            'Review or approval does not bind exact unadopted candidate')
    require(approval['independentReview'] == ref(args.review)
            and approval['approved'] is True and approval['reviewer'] == 'root'
            and isinstance(approval['scope'],str) and len(approval['scope'].strip()) >= 80
            and len(approval['rootChecks']) >= 4
            and all(isinstance(value,str) and value.strip() for value in approval['rootChecks']),
            'Explicit bounded root adoption approval missing')
    require(review['checks']['productionPythonValidation'] == 'PASS'
            and review['checks']['productionNodeBuildInputsMatch'] is True
            and review['referenceClosure']['unresolvedReferences'] == 0
            and review['checks']['eightTerminalGreenGroups'] is True
            and review['checks']['sealedWitnessReferences'] == 97
            and review['checks']['mutationArtifacts'] == 4
            and review['checks']['beforeContextPresent'] is False,
            'Independent review lacks exact validation or misstates before context')
    independent = subprocess.check_output([
        str(ROOT.parent/'tsx-security-python-env/Scripts/python.exe'),
        '-E','-s','-B',str(validator_path),'--state',str(state_path)],
        cwd=ROOT,text=True)
    observed = parse(independent.encode())
    require(observed['revision'] == REVISION and observed['sourceDeltas'] == 5
            and observed['requirements'] == 62 and observed['witnesses'] == 97
            and observed['terminalGreenGroups'] == 8
            and observed['mutationArtifacts'] == 4
            and observed['referenceClosure']['unresolvedReferences'] == 0
            and observed['productionPythonValidation'] == 'PASS'
            and observed['productionNodeBuildInputsMatch'] is True
            and observed['beforeContextPresent'] is False
            and observed['candidateApproved'] is False
            and observed['operativeReceiptOrPinsChanged'] is False,
            'Fresh independent validation failed or overclaimed authority')
    spec = importlib.util.spec_from_file_location('govuln9740_validator',validator_path)
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    closure_before = validator.closure(state_path)
    require(closure_before == review['referenceClosure'],
            'Reference graph changed since independent review')
    queue = [state_path, safe(args.review), safe(args.approval),
             Path(__file__).resolve(), validator_path,
             OUT/'receipt_renewal_safety_candidate.py']
    included = {}
    references = {}
    inherited = {}

    def walk(value):
        if isinstance(value,list):
            for child in value: walk(child)
        elif isinstance(value,dict):
            if isinstance(value.get('archive'),dict) and isinstance(value.get('member'),str):
                archive = safe(value['archive']['path'])
                require(ref(archive) == value['archive'], 'Historical archive changed')
                member = value['member']
                require(not member.startswith('/') and '..' not in Path(member).parts
                        and '\\' not in member, 'Unsafe historical member')
                with tarfile.open(archive,'r:*') as handle:
                    items = handle.getmembers()
                    require(len(items) <= 20000 and len({m.name for m in items}) == len(items),
                            'Ambiguous historical archive')
                    item = handle.getmember(member)
                    require(item.isfile() and not item.issym() and not item.islnk()
                            and sha(handle.extractfile(item).read()) == value['sha256'],
                            'Historical archive member changed')
                inherited[value['archive']['path']+':'+member] = value
                if archive.is_relative_to(OUT): queue.append(archive)
                return
            if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
                target = safe(value['path'])
                expected_path = str(target) if Path(value['path']).is_absolute() else target.relative_to(ROOT).as_posix()
                require(value['path'] == expected_path and sha(target.read_bytes()) == value['sha256'],
                        'Current reference changed')
                relative = target.relative_to(ROOT).as_posix()
                normalized = {'path':relative,'sha256':value['sha256']}
                if Path(value['path']).is_absolute():
                    normalized['originalBindingPath'] = value['path']
                references[value['path']] = normalized
                if target.is_relative_to(OUT): queue.append(target)
            if isinstance(value.get('log'),str) and isinstance(value.get('logSha256'),str):
                walk({'path':value['log'],'sha256':value['logSha256']})
            for child in value.values(): walk(child)

    while queue:
        path = safe(queue.pop())
        require(path.is_relative_to(OUT), 'Only ignored review evidence may be archived')
        relative = path.relative_to(ROOT).as_posix()
        if relative in included: continue
        require(len(included) < 20000 and path.stat().st_size <= 256*1024*1024,
                'Evidence archive budget exceeded')
        raw = path.read_bytes()
        included[relative] = raw
        if path.suffix == '.json': walk(parse(raw))

    manifest = {'schemaVersion':1,'sourceRevision':REVISION,
        'scope':'Unadopted offline receipt candidate and exact current execution/source review; sealed 1258689e members keep historical context.',
        'files':[{'path':name,'member':'review/'+name,'sha256':sha(raw),'bytes':len(raw)}
                 for name,raw in sorted(included.items())],
        'verifiedCurrentReferences':[references[name] for name in sorted(references)],
        'inheritedExactReferences':[inherited[name] for name in sorted(inherited)],
        'unresolvedReferences':[],'providerAcceptanceVerified':False,
        'operativeReceiptOrPinsChanged':False}
    manifest_raw = (json.dumps(manifest,indent=2)+'\n').encode()
    payload = {'manifest.json':manifest_raw,
               **{'review/'+name:raw for name,raw in sorted(included.items())}}

    def pack():
        plain = io.BytesIO()
        with tarfile.open(fileobj=plain,mode='w',format=tarfile.PAX_FORMAT) as archive:
            for name,raw in payload.items():
                item = tarfile.TarInfo(name)
                item.size,item.mode = len(raw),0o444
                item.uid = item.gid = item.mtime = 0
                item.uname = item.gname = ''
                archive.addfile(item,io.BytesIO(raw))
        compressed = io.BytesIO()
        with gzip.GzipFile(filename='',fileobj=compressed,mode='wb',mtime=0,compresslevel=9) as stream:
            stream.write(plain.getvalue())
        return compressed.getvalue()

    raw = pack()
    require(raw == pack(), 'Evidence archive not reproducible byte-for-byte')
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
        require(len(archive.getmembers()) == len(payload), 'Archive inventory differs')
        for item in archive.getmembers():
            require(item.isfile() and item.mtime == 0
                    and archive.extractfile(item).read() == payload[item.name],
                    'Archive member read-back differs')
    for name,content in included.items():
        require(safe(name).read_bytes() == content, 'Current evidence changed during archiving')
    for item in references.values():
        target = safe(item['path'])
        original = item.get('originalBindingPath',item['path'])
        expected_path = str(target) if Path(original).is_absolute() else target.relative_to(ROOT).as_posix()
        require(original == expected_path and item['path'] == target.relative_to(ROOT).as_posix()
                and sha(target.read_bytes()) == item['sha256'],
                'Current reference changed during archiving')
    check_authority()
    require(validator.closure(state_path) == closure_before,
            'Reference graph changed during archiving')
    if args.dry_run:
        print(json.dumps({'dryRun':True,'wouldArchiveSha256':sha(raw),'files':len(included),
                          'everyMemberReadBack':True,'doubleBuildByteIdentical':True,
                          'archiveCreated':False,'operativeReceiptOrPinsChanged':False}))
        return
    archive_path = OUT/'govuln9740-receipt-evidence.tar.gz'
    manifest_path = OUT/'govuln9740-receipt-evidence-manifest.json'
    require(not archive_path.exists() and not manifest_path.exists(),
            'Refusing to overwrite an existing receipt archive')
    with archive_path.open('xb') as stream: stream.write(raw)
    with manifest_path.open('xb') as stream: stream.write(manifest_raw)
    print(json.dumps({'archive':archive_path.relative_to(ROOT).as_posix(),
                      'sha256':sha(raw),'manifest':manifest_path.relative_to(ROOT).as_posix(),
                      'manifestSha256':sha(manifest_raw),'files':len(included),
                      'unresolvedReferences':0,'operativeReceiptOrPinsChanged':False}))


if __name__ == '__main__':
    main()
