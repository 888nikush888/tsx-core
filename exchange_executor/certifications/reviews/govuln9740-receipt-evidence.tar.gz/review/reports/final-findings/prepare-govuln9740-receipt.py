"""Prepare an unapproved receipt renewal for the exact govulncheck source delta.

All outputs are ignored review evidence. This helper never edits an operative
receipt, approval pin, tracked source, or a pre-existing evidence file.
"""
import argparse
import copy
import datetime
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

from receipt_renewal_safety_candidate import check_command_inventory, check_group_inventory, plain_local

ROOT = Path.cwd().resolve()
OUT = ROOT / 'reports/final-findings'
REVISION = '9740c2973e1cd71e16bbf597cc22a88a12860118'
PREVIOUS_REVISION = '1258689ef1ed92dcbc9a5a2f0a79dcf6a46af18a'
PREVIOUS_SOURCE_TREE = '5c7d438588394a131d0c4970668cc46b7fd66427fdd04b3b922182fcda3a009f'
CURRENT_SOURCE_TREE = '9f2c35de40444d51a00d6dfbb9d1581f3ca0152e18af09ec4e63d8dadcd14b76'
PREVIOUS_RECEIPT_HASH = 'e80181c487e9e48d0dd26092558735c60d2c914125c0d85cb7e7aaa0a9519c91'
PREVIOUS_AUTHORITY_HASH = 'a82912c2049d0594cd9f3d2cf98256b5a82ab2dea98538215f3e146f08da31da'
ARCHIVE_HASH = '1d446d22c7b7bb13327fc705cd83d5d1d0f6c0e8036c17ac62b00ee0a46b6913'
ARCHIVE = ROOT / 'exchange_executor/certifications/reviews/final-sonar-vendored-1258689e-receipt-evidence.tar.gz'
MANIFEST = ROOT / 'exchange_executor/certifications/reviews/final-sonar-vendored-1258689e-receipt-evidence-manifest.json'
NODE = 'C:/Users/nikla/AppData/Local/Programs/node22/node-v22.23.2-win-x64/node.exe'
TAG = 'govuln9740'
GROUPS = ['foundation', 'backend', 'python', 'frontend', 'build', 'browser', 'mutations', 'dependencies']
MUTATION_SOURCES = {
    'queue': ('src/queue.ts', 'node --import tsx tests/test_queue.js'),
    'retry': ('src/tdlib_retry.ts', 'node --import tsx tests/test_tdlib_retry.js'),
    'schema': ('src/signal_schema.ts', 'node --import tsx tests/test_signal_parser.js && node --import tsx tests/test_signal_contract_validation.js'),
    'trading-risk': ('src/trading_risk.ts', 'node --import tsx tests/test_trading_core.js && node --import tsx tests/test_trading_leverage_tiers.js'),
}
EXPECTED_DELTAS = {
    'monitoring/govulncheck/go.mod', 'monitoring/govulncheck/go.sum',
    'monitoring/vex/README.md', 'tests/test_monitoring_artifacts.js',
    'tests/test_supply_chain.js',
}
MEMBER_ROOT = 'review/reports/final-findings/'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def stamp(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key')
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))


def read(path):
    return parse(plain_local(ROOT, path).read_bytes())


def ref(path):
    p = plain_local(ROOT, path)
    return {'path': p.relative_to(ROOT).as_posix(), 'sha256': sha(p.read_bytes())}


def save(name, value):
    p = OUT / name
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    require(not p.exists() or p.read_bytes() == raw, 'Refusing to overwrite changed evidence: ' + name)
    if not p.exists():
        p.write_bytes(raw)
    return ref(p)


def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()


def current_inputs():
    script = "import {collectBuildInputs} from './scripts/verify_exchange_implementation.js';console.log(JSON.stringify(collectBuildInputs(process.cwd())));"
    return parse(subprocess.check_output([NODE, '--input-type=module', '-e', script]))


def sealed_archive():
    require(ref(ARCHIVE)['sha256'] == ARCHIVE_HASH, 'Predecessor archive hash differs')
    manifest = read(MANIFEST)
    require(manifest['sourceRevision'] == PREVIOUS_REVISION and manifest['unresolvedReferences'] == [],
            'Predecessor manifest source or reference closure differs')
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        members = archive.getmembers()
        require(len(members) <= 20000 and len({m.name for m in members}) == len(members),
                'Ambiguous predecessor archive inventory')
        by_name = {m.name: m for m in members}
        manifest_bytes = archive.extractfile('manifest.json').read()
        require(parse(manifest_bytes) == manifest, 'Tracked predecessor manifest differs from archive manifest')
        require(set(by_name) == {'manifest.json'} | {entry['member'] for entry in manifest['files']},
                'Predecessor archive member inventory differs from manifest')
        for entry in manifest['files']:
            m = by_name[entry['member']]
            require(m.isfile() and not m.issym() and not m.islnk() and m.size == entry['bytes']
                    and sha(archive.extractfile(m).read()) == entry['sha256'],
                    'Predecessor archive member differs: ' + entry['member'])
        def sealed(name):
            member = MEMBER_ROOT + name
            raw = archive.extractfile(member).read()
            return parse(raw), {'archive': ref(ARCHIVE), 'member': member, 'sha256': sha(raw)}
        context, context_ref = sealed('receipt-context-sonar125-after.json')
        parity, parity_ref = sealed('final-sonar-vendored-1258689e-receipt-parity-supplement.json')
        state, state_ref = sealed('final-sonar-vendored-1258689e-receipt-candidate-state.json')
        candidate, candidate_ref = sealed('final-sonar-vendored-1258689e-hyperliquid-receipt-candidate.json')
    receipt = read(ROOT / 'exchange_executor/certifications/hyperliquid.json')
    require(ref(ROOT / 'exchange_executor/certifications/hyperliquid.json')['sha256'] == PREVIOUS_RECEIPT_HASH,
            'Operative receipt changed')
    require(ref(ROOT / 'exchange_executor/ccxt_implementation_reviews.py')['sha256'] == PREVIOUS_AUTHORITY_HASH,
            'Operative approval pins changed')
    require(candidate == receipt and candidate_ref['sha256'] == PREVIOUS_RECEIPT_HASH
            and state['candidate'] == {'path': 'reports/final-findings/final-sonar-vendored-1258689e-hyperliquid-receipt-candidate.json', 'sha256': PREVIOUS_RECEIPT_HASH},
            'Archived candidate and operative receipt do not match')
    require(receipt['parityEvidenceHash'] == parity_ref['sha256']
            and state['parity'] == {'path': 'reports/final-findings/final-sonar-vendored-1258689e-receipt-parity-supplement.json', 'sha256': parity_ref['sha256']},
            'Archived parity and operative receipt commitments differ')
    require(context['revision'] == parity['revision'] == state['revision'] == receipt['sourceRevision'] == PREVIOUS_REVISION
            and context['inputs']['sourceTreeHash'] == receipt['sourceTreeHash'] == PREVIOUS_SOURCE_TREE
            and parity['counts']['requirements'] == 62 and parity['counts']['witnessReferences'] == 97,
            'Predecessor source or parity differs')
    return context, context_ref, parity, parity_ref, state_ref, receipt


def source_delta(context, context_ref, inputs):
    old = {r['path']: r['sha256'] for r in context['inputs']['files']}
    current = {r['path']: r['sha256'] for r in inputs['files']}
    require(len(old) == len(context['inputs']['files']) == len(current) == len(inputs['files']) == 1002,
            'Build input inventory differs')
    require(inputs['sourceTreeHash'] == CURRENT_SOURCE_TREE, 'Frozen current source tree differs')
    changes = [{'path': p, 'beforeSha256': old.get(p), 'currentSha256': current.get(p),
                'status': 'modified' if p in old and p in current else 'added' if p in current else 'removed'}
               for p in sorted(set(old) | set(current)) if old.get(p) != current.get(p)]
    require({r['path'] for r in changes} == EXPECTED_DELTAS and len(changes) == 5
            and all(r['status'] == 'modified' for r in changes), 'Expected exact five-file source delta')
    changed = set(subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', 'HEAD'], text=True).splitlines())
    require(changed == EXPECTED_DELTAS, 'Git commit does not contain exact five-file delta')
    return save('govuln9740-receipt-source-deltas.json', {
        'revision': REVISION, 'predecessorContext': context_ref,
        'counts': {'priorInputs': len(old), 'currentInputs': len(current), 'changedAddedRemoved': len(changes)},
        'deltas': changes, 'reviewed': False, 'operativeReceiptOrPinsChanged': False,
    }), changes, old, current


def check_group_reports(inputs, runtime=None, after=None):
    reports = []
    logs = {}
    for group in GROUPS:
        path = OUT / f'verification-{group}-{TAG}.json'
        report = read(path)
        check_command_inventory(report, ROOT, NODE)
        require(report['group'] == group and report['revision'] == REVISION
                and report['inputsBefore'] == inputs and report['providerAcceptanceVerified'] is False,
                'Group source/identity differs: ' + group)
        require(report.get('completedAt') and report.get('revisionAfter') == REVISION
                and report.get('inputsAfter') == inputs and report.get('observedInputsUnchanged') is True
                and report.get('allCommandsPassed') is True,
                'Group not terminal, stable and passing: ' + group)
        require(report['commands'] and all(type(c['exitCode']) is int and c['exitCode'] == 0
                and c.get('signal') is None and not c.get('error') for c in report['commands']),
                'A command in group failed: ' + group)
        require(stamp(report['startedAt']) <= stamp(report['completedAt']), 'Group timestamp differs')
        if runtime is not None:
            require(report['runtime']['node'] == runtime['node'] and report['runtime']['ccxt'] == runtime['ccxt']
                    and report['runtime']['python'] == 'Python ' + runtime['python'].split()[0],
                    'Group runtime differs: ' + group)
        if after is not None:
            require(stamp(report['completedAt']) <= stamp(after['startedAt']),
                    'Group ended after final context: ' + group)
        bindings = []
        for command in report['commands']:
            require(command['log'] == f"reports/final-findings/verification-{command['name']}-{TAG}.log",
                    'Command log attempt mismatch')
            lp = ROOT / command['log']
            require(ref(lp)['sha256'] == command['logSha256'], 'Command log bytes changed')
            require(stamp(report['startedAt']) <= stamp(command['startedAt']) <= stamp(command['completedAt'])
                    <= stamp(report['completedAt']), 'Command outside group time window')
            logs[command['name']] = lp.read_text(encoding='utf-8-sig')
            bindings.append(ref(lp))
        if group == 'foundation':
            mon = report['monitoringExecution']
            require(mon['mode'] == 'native-configuration-only' and mon['containerAcceptanceVerified'] is False
                    and [t['key'] for t in mon['tools']] == ['PROMTOOL_PATH', 'AMTOOL_PATH'],
                    'Native monitoring execution context differs')
            for tool in mon['tools']:
                require(sha(Path(tool['executable']).read_bytes()) == tool['sha256'] and tool['version'].strip(),
                        'Native monitoring tool bytes differ')
        reports.append({'group': group, 'report': ref(path), 'logs': bindings,
                        'freshAtFrozenRevision': True, 'originalAllCommandsPassed': True,
                        'reviewedReplacements': [], 'preservedEarlierAttempts': [], 'attemptSelection': None})
    check_group_inventory(reports)
    python_count = re.search(r'^Ran (\d+) tests? in ', logs['python-coverage'], re.M)
    frontend_count = re.search(r'Tests\s+(\d+) passed', logs['frontend-coverage'])
    frontend_files = re.search(r'Test Files\s+(\d+) passed', logs['frontend-coverage'])
    backend_files = re.search(r'ALL (\d+) TEST FILES PASSED', logs['backend-module-coverage'])
    require(python_count and re.search(r'^OK\s*$', logs['python-coverage'], re.M)
            and frontend_count and frontend_files and backend_files
            and 'Module coverage ratchet passed.' in logs['backend-module-coverage'],
            'Test suite summaries missing')
    counts = {'pythonTests': int(python_count[1]), 'frontendTests': int(frontend_count[1]),
              'frontendFiles': int(frontend_files[1]), 'backendModuleTestFiles': int(backend_files[1])}
    return reports, counts


def check_review(path, delta_ref, changes):
    require(path is not None, 'Candidate requires independently completed five-file source review')
    value = read(path)
    require(value['revision'] == REVISION and value['deltas'] == delta_ref
            and value['reviewed'] is True and value['providerAcceptanceVerified'] is False,
            'Root source review revision, delta or status differs')
    rows = {r['path']: r for r in value['reviews']}
    require(len(rows) == len(value['reviews']) == len(changes) and set(rows) == EXPECTED_DELTAS,
            'Incomplete source review')
    for change in changes:
        row = rows[change['path']]
        require(all(row[k] == change[k] for k in ('beforeSha256', 'currentSha256', 'status'))
                and row['reviewed'] is True and row['rationale'].strip() and row['evidence'],
                'Unreviewed changed source: ' + change['path'])
        for binding in row['evidence']:
            require(ref(ROOT / binding['path']) == binding, 'Source review evidence differs')
    return ref(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['inventory', 'candidate'], required=True)
    parser.add_argument('--source-review', type=Path)
    args = parser.parse_args()
    require(head() == REVISION, 'Frozen govulncheck HEAD changed')
    require(not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], text=True).strip(),
            'Tracked working tree changed')
    context, context_ref, parity, parity_ref, state_ref, prior = sealed_archive()
    inputs = current_inputs()
    delta_ref, changes, old, current = source_delta(context, context_ref, inputs)
    witness_keys = {(row['category'], row['check']) for row in parity['rows']}
    witness_bindings = [w for row in parity['rows'] for w in row['witnessBindings']]
    require(len(witness_keys) == len(parity['rows']) == 62 and len(witness_bindings) == 97
            and len({w['path'] for w in witness_bindings}) == 30
            and all(old[w['path']] == current[w['path']] == w['sha256'] for w in witness_bindings),
            'One of 97 sealed witness path/hash bindings changed')
    if args.mode == 'inventory':
        draft = {'revision': REVISION, 'deltas': delta_ref, 'reviewed': False,
                 'providerAcceptanceVerified': False,
                 'reviews': [{**c, 'reviewed': False, 'rationale': '', 'evidence': []} for c in changes]}
        draft_ref = save('govuln9740-receipt-source-review-draft.json', draft)
        print(json.dumps({'delta': delta_ref, 'draft': draft_ref, 'changedInputs': len(changes),
                          'sealedWitnessesUnchanged': 97, 'candidateCreated': False}))
        return
    review_ref = check_review(args.source_review, delta_ref, changes)
    progress_path = OUT / 'receipt-context-govuln9740-progress.json'
    after_path = OUT / 'receipt-context-govuln9740-after.json'
    progress = read(progress_path)
    after = read(after_path)
    require(all(c['revision'] == REVISION and c['inputs'] == inputs
                and c['rawEqualsGit'] and c['allInputsSingleLink'] and c['sourceStableDuringCapture']
                for c in (progress, after))
            and progress['runtime'] == after['runtime']
            and stamp(progress['observedAt']) <= stamp(after['startedAt']),
            'Intermediate/final contexts do not prove exact stable Git inputs and runtime')
    groups, suite_counts = check_group_reports(inputs, after['runtime'], after)
    mutation = read(OUT / f'verification-mutations-{TAG}.json')
    require(stamp(mutation['startedAt']) <= stamp(progress['startedAt'])
            <= stamp(progress['observedAt']) <= stamp(mutation['completedAt']),
            'Intermediate context was not captured during the mutation group')
    mutation_artifacts = []
    artifact_dir = OUT / 'mutation-artifacts-govuln9740'
    artifact_dir.mkdir(exist_ok=True)
    require(len(mutation['commands']) == 1 and mutation['commands'][0]['name'] == 'mutations',
            'Exact mutation command missing')
    mutation_command = mutation['commands'][0]
    mutation_log = (OUT / f'verification-mutations-{TAG}.log').read_text(encoding='utf-8-sig')
    source_hashes = {r['path']: r['sha256'] for r in inputs['files']}
    last_mtime = None
    for shard in ('queue', 'retry', 'schema', 'trading-risk'):
        source = ROOT / 'reports/mutation' / f'{shard}.json'
        source = plain_local(ROOT, source)
        original = source.read_bytes()
        data = parse(original)
        mutate_path, expected_command = MUTATION_SOURCES[shard]
        config = data['config']
        require(data['schemaVersion'] == '1.0'
                and data['projectRoot'] == str(ROOT)
                and list(data['files']) == [mutate_path]
                and config['mutate'] == [mutate_path]
                and config['jsonReporter']['fileName'] == f'reports/mutation/{shard}.json'
                and config['testRunner'] == 'command'
                and config['commandRunner']['command'] == expected_command
                and config['coverageAnalysis'] == 'off'
                and config['incremental'] is False
                and config['force'] is True
                and data['thresholds'] == config['thresholds']
                == {'high': 80, 'low': 70, 'break': 70},
                'Mutation configuration differs: ' + shard)
        file_data = data['files'][mutate_path]
        require(file_data['source'].encode('utf-8') == plain_local(ROOT, mutate_path).read_bytes()
                and sha(file_data['source'].encode('utf-8')) == source_hashes[mutate_path],
                'Mutation input source differs from frozen Git: ' + shard)
        mutants = file_data['mutants']
        ids = [m['id'] for m in mutants]
        require(mutants and len(ids) == len(set(ids)), 'Missing or duplicate mutant identities: ' + shard)
        statuses = [m['status'] for m in mutants]
        require(set(statuses) <= {'Killed', 'Timeout', 'Survived'},
                'Unreviewed mutation status affects score: ' + shard)
        mutant_counts = {status: statuses.count(status) for status in ('Killed', 'Timeout', 'Survived')}
        score = Decimal(100) * Decimal(mutant_counts['Killed'] + mutant_counts['Timeout']) / Decimal(len(mutants))
        score_text = str(score.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))
        require(score >= Decimal(70), 'Mutation score below exact break threshold: ' + shard)
        marker = f'=== Mutation shard: {shard} ==='
        require(mutation_log.count(marker) == 1, 'Mutation shard log marker differs: ' + shard)
        section = mutation_log.split(marker, 1)[1].split('=== Mutation shard:', 1)[0]
        logged_score = re.findall(r'Final mutation score of ([0-9]+\.[0-9]+) is greater than or equal to break threshold 70', section)
        instrumented = re.findall(r'Instrumented 1 source file\(s\) with (\d+) mutant\(s\)', section)
        require(logged_score == [score_text] and instrumented == [str(len(mutants))],
                'Mutation JSON score/count differs from current run log: ' + shard)
        mtime_ns = source.stat().st_mtime_ns
        mtime = datetime.datetime.fromtimestamp(mtime_ns / 1_000_000_000, datetime.timezone.utc)
        require(stamp(mutation_command['startedAt']) <= mtime <= stamp(mutation_command['completedAt'])
                and (last_mtime is None or mtime_ns > last_mtime),
                'Mutation JSON not written in ordered current command window: ' + shard)
        last_mtime = mtime_ns
        copy_path = artifact_dir / f'{shard}.json'
        require(not copy_path.exists() or copy_path.read_bytes() == original,
                'Refusing to overwrite changed mutation artifact: ' + shard)
        if not copy_path.exists():
            copy_path.write_bytes(original)
        mutation_artifacts.append({'shard': shard, 'selectedCurrentRun': ref(copy_path),
                                   'sourcePath': source.relative_to(ROOT).as_posix(),
                                   'sourceSha256AtCapture': sha(original),
                                   'sourceMtimeNs': mtime_ns,
                                   'mutantCounts': mutant_counts, 'mutationScorePercent': score_text})
    execution_ref = save('govuln9740-receipt-execution-supplement.json', {
        'revision': REVISION, 'progressContext': ref(progress_path),
        'afterContext': ref(after_path), 'runtime': after['runtime'],
        'groups': groups, 'observedCounts': suite_counts, 'pythonExecutionInheritance': False,
        'beforeContextPresent': False,
        'sourceProof': 'Each of eight complete reports binds identical pre/post inputs to the exact Git revision; independent raw-to-Git contexts were captured during mutation and after all groups. No pre-test context snapshot was captured.',
        'providerAcceptanceVerified': False, 'operativeReceiptApproved': False})
    category_review = ('All 97 original witness path/hash bindings are unchanged from the sealed '
                       '1258689e parity. Five individually reviewed build inputs affect the '
                       'govulncheck build-time scanner, documentation and scanner tests. The '
                       'current eight-group terminal execution is separately bound; no provider '
                       'or live-trading acceptance is claimed.')
    rows = []
    for previous in parity['rows']:
        bindings = [{'path': w['path'], 'sha256': current[w['path']]}
                    for w in previous['witnessBindings']]
        rows.append({'category': previous['category'], 'check': previous['check'],
                     'witnessBindings': bindings,
                     'sealedPriorRow': {'evidence': parity_ref,
                                        'lookup': {'category': previous['category'], 'check': previous['check']}},
                     'completeSourceReview': review_ref, 'currentExecution': execution_ref,
                     'currentDeltaAssessment': category_review,
                     'supplementalCurrentEvidence': [],
                     'scope': 'Offline implementation requirement; no provider execution or scope expansion.'})
    parity_new = save('govuln9740-receipt-parity-supplement.json', {
        'revision': REVISION, 'priorParity': parity_ref,
        'counts': {'requirements': 62, 'witnessReferences': 97,
                   'changedWitnessReferences': 0, 'unchangedWitnessReferences': 97},
        'method': 'Exact original 62 requirement identities and all 97 witness path/hash pairs remain sealed and unchanged; five changed non-witness inputs receive separate source review and fresh eight-group execution.',
        'rows': rows, 'providerAcceptanceVerified': False, 'operativeReceiptApproved': False})
    candidate = copy.deepcopy(prior)
    for key in ('sourceTreeHash', 'nodeSourcesHash', 'testSourcesHash', 'fixturesHash'):
        candidate[key] = inputs[key]
    for key in ('executorTreeHash', 'sdkTreeHash', 'profileHash'):
        candidate[key] = after['runtime'][key]
    candidate.update({'sourceRevision': REVISION, 'parityEvidenceHash': parity_new['sha256'],
                      'executionReportHash': execution_ref['sha256'],
                      'reviewedAt': datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')})
    sys.path.insert(0, str(ROOT / 'exchange_executor'))
    import ccxt
    from ccxt_certification_evidence import validate_receipt
    from ccxt_profiles import PROFILES
    validate_receipt(candidate, 'hyperliquid', ccxt.__version__, PROFILES['hyperliquid'],
                     ROOT / 'exchange_executor', Path(ccxt.__file__).parent)
    require(all(candidate[key] == prior[key] for key in ('schemaVersion', 'kind', 'exchange',
            'ccxtVersion', 'profileVersion', 'profileHash', 'scope', 'providerAcceptanceVerified')),
            'Receipt scope or identity changed')
    candidate_ref = save('govuln9740-hyperliquid-receipt-candidate.json', candidate)
    state_ref = save('govuln9740-receipt-candidate-state.json', {
        'revision': REVISION, 'candidate': candidate_ref, 'execution': execution_ref,
        'parity': parity_new, 'completeSourceReview': review_ref,
        'predecessorReceiptState': state_ref, 'predecessorArchive': ref(ARCHIVE),
        'mutationArtifacts': mutation_artifacts,
        'reproducibilityHelpers': [ref(OUT / p) for p in (
            'prepare-govuln9740-receipt.py', 'collect-receipt-context.mjs',
            'receipt-runtime-snapshot.py', 'run-verification.mjs',
            'receipt_renewal_safety_candidate.py',
            'validate-govuln9740-candidate.py')],
        'operativeReceiptOrPinsChanged': False, 'operativeReceiptApproved': False,
        'remaining': ['Independent source, execution and reference-closure review',
                      'Deterministic evidence archive', 'Explicit bounded root adoption',
                      'Real post-adoption implementation gate and bridge regressions',
                      'Container and remote scanner checks']})
    print(json.dumps({'candidate': candidate_ref, 'state': state_ref,
                      'operativeReceiptOrPinsChanged': False, 'providerAcceptanceVerified': False}))


if __name__ == '__main__':
    main()
