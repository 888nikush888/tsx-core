import json,hashlib,subprocess,copy,tarfile,re,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];R=ROOT/'reports/security-services';PROOF=ROOT.parent/'tsx-core-candidate-proof-20260915';REV='5a532f0230d52e1169cb60311e4f9f726a86d003'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def ref(p):return {'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p.read_bytes())}
def save(n,d):
 p=R/n;p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode());return ref(p)
def archived(binding):
 a=ROOT/binding['archive']['path'];assert sha(a.read_bytes())==binding['archive']['sha256']
 with tarfile.open(a,'r:gz') as t:raw=t.extractfile(binding['member']).read()
 assert sha(raw)==binding['sha256'];return raw
planpath=R/'fixer-5a532f-62-requirement-continuity-plan.json';sourcepath=R/'fixer-5a532f-complete-source-independent-plan.json'
assert sha(planpath.read_bytes())=='a4c2e0a398e23486a32bfd548a244ad6958daace1c294b6b274317a62b3cbe16'
assert sha(sourcepath.read_bytes())=='c0d434c31767c2b65320529c0760ed82508e7b6d08e3d5fe4c53aff1d46580e5'
plan=read(planpath);sourceplan=read(sourcepath);beforepath=R/'fixer-5a532f-final-context-before.json';afterpath=R/'fixer-5a532f-final-context-after.json';before=read(beforepath);after=read(afterpath)
assert sha(afterpath.read_bytes())=='5792dd527e5930c15efc92649476966c1b59ece74b59d218096b42f7749ba873'
assert before['revision']==after['revision']==REV and before['inputs']==after['inputs'] and before['runtime']==after['runtime'] and after['rawEqualsGit'] and after['allInputsSingleLink']
items=after['inputs']['files'];assert len(items)==970;inputs={x['path']:x['sha256'] for x in items}
stream=subprocess.check_output(['git','cat-file','--batch'],input=''.join(REV+':'+x['path']+'\n' for x in items).encode(),cwd=ROOT);pos=0
for x in items:
 end=stream.index(b'\n',pos);header=stream[pos:end].split();assert header[1]==b'blob';size=int(header[2]);blob=stream[end+1:end+1+size];pos=end+size+2;p=PROOF/x['path'];assert sha(blob)==sha(p.read_bytes())==x['sha256'] and p.stat().st_nlink==1
rootreview=read(R/'fixer-5a532f-completed-execution-review.json')
for b in rootreview['evidence']:assert sha((ROOT/b['path']).read_bytes())==b['sha256']
rawlogs=[]
for n in ['verification-completion.json','build.log','module.log']:
 p=R/('fixer-5a532f-final-'+n);assert p.read_bytes()==(PROOF/'reports/security-services'/p.name).read_bytes();rawlogs.append(ref(p))
completion=read(R/'fixer-5a532f-final-verification-completion.json');assert completion['revision']==REV and completion['failure'] is None and {x['name']:x['exitCode'] for x in completion['rows']}=={'build':0,'module-coverage':0}
log=(R/'fixer-5a532f-final-module.log').read_text(encoding='utf-8-sig');assert 'ALL 226 TEST FILES PASSED' in log and 'Module coverage ratchet passed.' in log and re.search(r'All files\s*\|\s*96\.57\s*\|\s*86\.65\s*\|\s*99\.24\s*\|\s*96\.57',log)
baseline=json.loads(archived(sourceplan['baselineContext']));baseinputs={x['path']:x['sha256'] for x in baseline['inputs']['files']};baseparity=json.loads(archived(plan['baselineParity']));baseexecution=json.loads(archived(sourceplan['inheritance']['executionProvenance']))
changed={p for p,h in inputs.items() if baseinputs.get(p)!=h};assert len(changed)==12 and changed=={x['path'] for x in sourceplan['deltas']} and not(set(baseinputs)-set(inputs))
for d in sourceplan['deltas']:
 assert inputs[d['path']]==d['sha256']
 for b in d['evidence']:assert sha((ROOT/b['path']).read_bytes())==b['sha256']
inherit=copy.deepcopy(sourceplan['inheritance'])
for name,count in [('frontend',164),('python',118)]:
 bindings=inherit[name]['unchangedInputs'];assert len(bindings)==count and all(inputs[p]==h for p,h in bindings.items())
assert before['runtime']==baseline['runtime']==sourceplan['currentRuntime']
# Bind original raw Python execution preserved in the f1 archive, not a new run.
pythonbindings=baseexecution['python']['evidence']
pythonraw=archived(pythonbindings[1]);pythoncompletion=json.loads(archived(pythonbindings[0]));assert pythoncompletion['exitCode']==0 and b'Ran 548 tests' in pythonraw and re.search(rb'^OK\s*$',pythonraw,re.M)
frontendcontext=json.loads(archived(inherit['frontend']['originalExecutionContext']));frontendinputs={x['path']:x['sha256'] for x in frontendcontext['inputs']['files']};assert all(frontendinputs[p]==h for p,h in inherit['frontend']['unchangedInputs'].items())
archivebinding=sourceplan['baselineContext']['archive']
def b425member(name):
 a=ROOT/archivebinding['path']
 with tarfile.open(a,'r:gz') as t:raw=t.extractfile('next/reports/security-services/'+name).read()
 return raw,{'archive':archivebinding,'member':'next/reports/security-services/'+name,'sha256':sha(raw)}
frontlog,frontlogref=b425member('fixer-types-142-retry-frontend-tests.log');frontcompletion,frontcompletionref=b425member('fixer-types-142-retry-verification-completion.json');fc=json.loads(frontcompletion)
assert b'328 passed (328)' in frontlog and b'40 passed (40)' in frontlog and fc['revision']==inherit['frontend']['revision'] and next(x['exitCode'] for x in fc['rows'] if x['name']=='frontend-tests')==0
continuity={'before':ref(beforepath),'after':ref(afterpath),'allInputsAndRuntimeEqual':True,'independentRawGitSingleLinkCheck':970}
execution=save('fixer-5a532f-execution-supplement.json',{'kind':'current-final-5a532f-execution-with-explicit-inheritance','revision':REV,'node':{'status':'passed-current-final-source','files':226,'build':'passed','coverage':{'statements':96.57,'branches':86.65,'functions':99.24,'lines':96.57},'ratchet':'passed','runtime':'Node22.23.2','evidence':rawlogs,'rootIndependentCompletionReview':ref(R/'fixer-5a532f-completed-execution-review.json')},'frontend':{**inherit['frontend'],'evidence':[frontcompletionref,frontlogref],'freshCurrentRunClaimed':False},'python':{**inherit['python'],'evidence':pythonbindings,'freshCurrentRunClaimed':False},'runtime':after['runtime'],'sourceContinuity':continuity,'baselineExecution':inherit['executionProvenance'],'scope':'226 Node files actually ran on final 5a532f; frontend328 and Python548 remain exact explicitly inherited prior executions. No b425 full-suite success attributed to 5a532f.','downstreamGates':['Independent candidate review','Evidence archive and root adoption/operative verifier','Applicable external CI/security/container scans; not claimed completed here'],'providerAcceptanceVerified':False,'operativeReceiptApproved':False})
rows=copy.deepcopy(plan['rows']);witnessrefs=0;changedrefs=0
for row in rows:
 for w in row['witnessBindings']:
  assert inputs[w['path']]==w['sha256'];witnessrefs+=1;changedrefs+=not w['unchangedSinceB425']
 for d in row['currentDeltaDependencies']:assert inputs[d['path']]==d['sha256']
 row['currentExecutionClaim']={'node':'226 test files PASS on actual final 5a532f source, including modified emergency test and new two-position allocation regression','frontend':'328 tests at142 inherited with all164 frontend inputs unchanged','python':'548 tests atf1 inherited with all118 Python inputs and runtime unchanged; not newly executed'}
 row['candidateReady']=True;row['currentStatus']='Ready for independent receipt review; exact historical assertions plus reviewed changed emergency witness and current final Node evidence'
assert len(rows)==62 and witnessrefs==97 and changedrefs==3
parity=save('fixer-5a532f-parity-supplement.json',{'kind':'final-offline-parity-successor-supplement','revision':REV,'baselineRevision':sourceplan['baselineRevision'],'counts':{'required':62,'historicallyCoveredOffline':62,'currentFinalEvidenceReady':62,'witnessReferences':97,'changedWitnessReferences':3,'unchangedWitnessReferences':94},'rows':rows,'requirementPlan':ref(planpath),'baselineParity':plan['baselineParity'],'scopeClarifications':plan['scopeClarifications'],'execution':execution,'changedWitnesses':plan['changedWitnesses'],'priorScopeAndBehaviorHistory':plan['baselineParity'],'providerAcceptanceVerified':False,'operativeReceiptApproved':False})
source=save('fixer-5a532f-complete-source-supplement.json',{'kind':'complete-final-source-successor-delta-review','revision':REV,'baselineRevision':sourceplan['baselineRevision'],'baselineContext':sourceplan['baselineContext'],'counts':{'inputs':970,'changedOrAdded':12,'modified':11,'added':1,'unchanged':958,'removed':0},'deltas':sourceplan['deltas'],'reviewPlan':ref(sourcepath),'continuity':continuity,'execution':execution,'currentEvidenceReadyForIndependentReview':True,'supersedesHistoricalPlanPendingFields':'Current final build/module and after-context now verified here; original plan remains unchanged.','providerAcceptanceVerified':False,'operativeReceiptApproved':False})
active=ROOT/'exchange_executor/certifications/hyperliquid.json';assert sha(active.read_bytes())=='e0e8285c975107a2cfb8fad02f4bc608096260c80c9593aa0ce916b90609cac3';candidate=read(active)
candidate.update({'sourceRevision':REV,'reviewedAt':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),'parityEvidenceHash':parity['sha256'],'executionReportHash':execution['sha256']})
for k in ['sourceTreeHash','nodeSourcesHash','testSourcesHash','fixturesHash']:candidate[k]=after['inputs'][k]
for k in ['executorTreeHash','sdkTreeHash','profileHash']:candidate[k]=after['runtime'][k]
assert candidate['providerAcceptanceVerified'] is False
candidateRef=save('hyperliquid-5a532f-receipt-candidate-lf.json',candidate)
summary={'kind':'reviewable-candidate-not-operative-approval','revision':REV,'candidate':candidateRef,'parity':parity,'execution':execution,'completeSource':source,'readyForIndependentReview':True,'missingPreCandidateEvidence':[],'remaining':['Independent review','Archive only after independent review','Root adoption and actual operative verifier','Applicable external gates'],'operativeReceiptOrPinsChanged':False,'providerAcceptanceVerified':False}
save('fixer-5a532f-candidate-preparation-state.json',summary);print(json.dumps(summary,indent=2))
