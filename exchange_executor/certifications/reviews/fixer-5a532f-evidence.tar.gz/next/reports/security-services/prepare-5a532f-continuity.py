import json,hashlib,subprocess,tarfile,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; R=ROOT/'reports/security-services'; PROOF=ROOT.parent/'tsx-core-candidate-proof-20260915'; REV='5a532f0230d52e1169cb60311e4f9f726a86d003'; BASE='b42583fcd9063666da673e1b243f6268cd9c530e'
sha=lambda b:hashlib.sha256(b).hexdigest()
def ref(p):return {'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p.read_bytes())}
def save(n,o):p=R/n;p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8');return ref(p)
def archived(name,digest,member):
 p=ROOT/'exchange_executor/certifications/reviews'/name;assert sha(p.read_bytes())==digest
 with tarfile.open(p) as t:b=t.extractfile(member).read()
 return json.loads(b),{'archive':ref(p),'member':member,'sha256':sha(b)}
A='dbffd63c21754ec9af502689728e05df2621cd82d08b1a18f2b0964af2564a24';F='08959768353cc9f3be169d6ebcdec53a0a443dbb0e2e910ce32090e6be08a636'
old,oldref=archived('fixer-b425-evidence.tar.gz',A,'next/reports/security-services/fixer-b425-final-source-context.json');parity,parityref=archived('fixer-b425-evidence.tar.gz',A,'next/reports/security-services/fixer-b425-parity-supplement.json');execution,exref=archived('fixer-b425-evidence.tar.gz',A,'next/reports/security-services/fixer-b425-execution-supplement.json');mid,midref=archived('fixer-b425-evidence.tar.gz',A,'next/reports/security-services/fixer-types-142-context-after.json');f1,f1ref=archived('fixer-final-f1b7-evidence.tar.gz',F,'next/reports/security-services/fixer-final-f1b7-context-after.json')
contextpath=R/'fixer-5a532f-final-context-before.json';assert sha(contextpath.read_bytes())=='ea2579d9ac3f4fbebd8764b8233f2f9d20d47d46e60541be1a25d41c4195a639';current=json.loads(contextpath.read_bytes());assert current['revision']==REV and current['rawEqualsGit'] and current['allInputsSingleLink']
a={x['path']:x['sha256'] for x in old['inputs']['files']};b={x['path']:x['sha256'] for x in current['inputs']['files']};assert len(a)==969 and len(b)==970
# Independently bind every current collector file to exact Git object bytes and immutable PROOF raw bytes.
paths=sorted(b);payload=''.join(REV+':'+p+'\n' for p in paths).encode();batch=subprocess.run(['git','cat-file','--batch'],input=payload,stdout=subprocess.PIPE,check=True,cwd=ROOT).stdout;offset=0
for p in paths:
 end=batch.index(b'\n',offset);header=batch[offset:end].split();assert header[1]==b'blob';size=int(header[2]);blob=batch[end+1:end+1+size];offset=end+size+2;assert sha(blob)==b[p],p;raw=PROOF/p;assert sha(raw.read_bytes())==b[p] and raw.stat().st_nlink==1,p
assert offset==len(batch)
changed=[p for p in paths if a.get(p)!=b[p]];assert len(changed)==12 and not(set(a)-set(b))
reviews={
'src/viewer_projection.ts':['viewer-projection-s6551-independent-review.json','fixer-viewer82-actual-implementation-review.json'],
'src/telegram_viewer/formatters.ts':['fixer-viewer82-actual-implementation-review.json'],
'src/trading_telemetry.ts':['fixer-telemetry12-implementation-review.json'],
'src/trading_runtime.ts':['fixer-runtime-object-fallback-independent-review.json','fixer-runtime-object-fallback-implementation-review.json'],
'src/exchange_order_identity_contract.ts':['fixer-sonar3-actual-implementation-review.json','sonar3-style-domain-error-proposal-review.json'],
'src/trading_money_reporting.ts':['fixer-sonar3-actual-implementation-review.json','sonar3-style-domain-error-proposal-review.json'],
'src/trading_take_profit.ts':['fixer-sonar3-actual-implementation-review.json','sonar3-style-domain-error-proposal-review.json']}
for p in changed:
 if p.startswith('tests/'):
  reviews[p]=reviews['src/trading_runtime.ts'] if p.endswith('test_trading_control_races.js') else reviews['src/trading_take_profit.ts'] if p.endswith(('test_trading_emergency.js','test_trading_engine_type_guards.js')) else reviews['src/telegram_viewer/formatters.ts']
notes={
'src/viewer_projection.ts':'Only row contracts/comments changed; persisted TEXT and nullable outer-join columns retain original conversions. No runtime validation claim.',
'src/telegram_viewer/formatters.ts':'Intentional display boundary change: 13 selected opaque values use existing scalar guard and ungeklärt fallback; object hooks no longer run here. Valid scalar output retained, not whole-JS equivalence.',
'src/trading_telemetry.ts':'Only three SQL row declarations changed, matching application writer/SQL contracts; independently verified configured emitted JS byte-equal.',
'src/trading_runtime.ts':'Stores original native conversion result and replaces exactly default-object text for selected object message/error. Getter/receiver/native throwing conversions retained; intentional diagnostic change, no general sanitization claim.',
'src/exchange_order_identity_contract.ts':'ASCII [0-9] to JavaScript \\d regex spelling; same 1..256 digit bound, trim check and safe-number branch.',
'src/trading_money_reporting.ts':'First !event short-circuit extracted to early return, remaining account/time/kind comparisons retain order.',
'src/trading_take_profit.ts':'Missing target allocation now throws named Error subclass with same message; not TypeError. Intentional class/name change. Decimal guards and continuation behavior retained.',
 'tests/fixtures/formatter_scalar_cases.js':'New 13-site matrix covers six malformed categories per site (78 cases), verifies hostile coercion hooks are not read, plus defaults/null behavior; optional legacy comparison supports differential proof.',
 'tests/test_telegram_viewer_contracts.js':'Adds fixture invocation/imports; all prior contract assertions retained.',
 'tests/test_trading_control_races.js':'Updates four falsy object expected diagnostics, adds plain/nested object and two literal-tag cases; native error/coercion/getter assertions retained.',
 'tests/test_trading_emergency.js':'Adds allocation-error position-isolation scenario without deleting prior assertions; first position error aggregated while second independent position still reconciles.',
 'tests/test_trading_engine_type_guards.js':'Adds exact named Error subclass/message checks for both missing-array slots; existing valid allocation and invalid decimal/target assertions retained.'}
deltas=[{'path':p,'beforeSha256':a.get(p),'sha256':b[p],'change':'modified' if p in a else 'added','review':notes[p],'evidence':[ref(R/n) for n in reviews[p]]}for p in changed]
# Verify source commitments made by actual implementation records (some records call the key bindings).
for n in ['fixer-viewer82-actual-implementation-review.json','fixer-sonar3-actual-implementation-review.json','fixer-runtime-object-fallback-independent-review.json']:
 o=json.loads((R/n).read_bytes())
 for x in o.get('bindings',o.get('sourceBindings',[])):assert b[x['path']]==x.get('sha256',x.get('lfSha256')),x['path']
tele=json.loads((R/'fixer-telemetry12-implementation-review.json').read_bytes());assert b[tele['source']]==tele['afterRawSha256']
front={p:h for p,h in b.items() if p.startswith('frontend/')};midfront={x['path']:x['sha256'] for x in mid['inputs']['files'] if x['path'].startswith('frontend/')};assert front==midfront and len(front)==164
py={x['path']:x['sha256'] for x in current['inputs']['files'] if x['path'].endswith('.py')};oldpy={x['path']:x['sha256'] for x in f1['inputs']['files'] if x['path'].endswith('.py')};assert py==oldpy and len(py)==118
assert current['runtime']==old['runtime']==f1['runtime']==mid['runtime']
# Non-frontend/Python changes are enumerated; shared package/toolchain/config inputs are byte-identical to b425.
inheritance={'frontend':{'tests':328,'testFiles':40,'status':'inherited-not-fresh','revision':execution['frontend']['revision'],'all164FrontendInputHashesEqual':True,'originalExecutionContext':midref,'unchangedInputs':front},'python':{'tests':548,'status':'inherited-not-fresh','revision':execution['python']['revision'],'all118PythonInputHashesEqual':True,'entireRuntimeObservationEqual':True,'originalExecutionContext':f1ref,'unchangedInputs':py},'executionProvenance':exref,'sharedInputs':'All changed/added collector paths are the enumerated 12 Node source/test files; package locks, configs, frontend files and Python dependencies are unchanged versus b425.'}
source=save('fixer-5a532f-complete-source-independent-plan.json',{'kind':'independent-complete-source-continuity-plan-awaiting-final-execution','revision':REV,'baselineRevision':BASE,'baselineContext':oldref,'currentContext':ref(contextpath),'counts':{'beforeInputs':969,'currentInputs':970,'modified':11,'added':1,'removed':0,'unchanged':958},'all970CurrentGitRawSingleLinkIndependentlyVerified':True,'deltas':deltas,'inheritance':inheritance,'currentRuntime':current['runtime'],'currentNodeExecution':'Pending root full build/226-file completion and after-context; no completed run claimed.','pending':['Final full Node run and after-context equality','Independent candidate review, evidence archive and root adoption','Actual operative verifier plus external scanner/container evidence as required'],'providerAcceptanceVerified':False,'receiptCandidateCreated':False})
rows=[];changedWitnesses=[]
for oldrow in parity['rows']:
 row={'category':oldrow['category'],'check':oldrow['check'],'historicalMapping':{'archiveReference':parityref,'lookup':'rows by category/check','status':'Prior b425 offline evidence and all restrictions retained as historical evidence only.'},'witnessBindings':[]}
 for w in oldrow['witnessBindings']:
  p=w['path'];assert a[p]==w['sha256'];entry={'path':p,'baselineSha256':w['sha256'],'sha256':b[p],'unchangedSinceB425':b[p]==w['sha256']}
  if not entry['unchangedSinceB425']:
   assert p=='tests/test_trading_emergency.js';entry['changedWitnessReview']=notes[p];entry['evidence']=[ref(R/n)for n in reviews[p]];changedWitnesses.append({'category':row['category'],'check':row['check'],'path':p})
  row['witnessBindings'].append(entry)
 row['currentDeltaDependencies']=[{'path':x['path'],'sha256':x['sha256'],'evidence':x['evidence']} for x in deltas]
 row['dependencyScope']='Conservative binding to all twelve reviewed source/test deltas; not an exhaustive import graph.'
 row['supplementalNewEvidence']=[{'path':p,'sha256':b[p],'role':notes[p]} for p in ['tests/test_trading_engine_type_guards.js','tests/fixtures/formatter_scalar_cases.js','tests/test_trading_control_races.js']]
 row['currentExecutionClaim']={'node':'pending root final suite; targeted local results in bound reviews only','frontend':'328 inherited at exact unchanged 142 frontend inputs','python':'548 inherited at exact unchanged f1 Python inputs and runtime'};row['candidateReady']=False;rows.append(row)
assert len(rows)==62 and sum(len(x['witnessBindings'])for x in rows)==97 and len(changedWitnesses)==3
requirements=save('fixer-5a532f-62-requirement-continuity-plan.json',{'kind':'independent-62-requirement-successor-plan-not-receipt-approval','revision':REV,'baselineRevision':BASE,'baselineParity':parityref,'sourceReview':source,'counts':{'requirements':62,'witnessReferences':97,'distinctWitnessFiles':len({w['path']for x in rows for w in x['witnessBindings']}),'changedWitnessReferences':3,'unchangedWitnessReferences':94,'changedWitnessFiles':1},'changedWitnesses':changedWitnesses,'typeGuardClarification':'tests/test_trading_engine_type_guards.js is changed supplemental evidence, not one of the historical 30 witness files. No historical witness reference is invented.','rows':rows,'scopeClarifications':parity['scopeClarifications'],'priorDeliberateSemanticChanges':parity['priorDeliberateSemanticChanges'],'currentExecutionPending':True,'providerAcceptanceVerified':False,'receiptCandidateCreated':False})
print(json.dumps({'source':source,'requirements':requirements,'changedWitnesses':changedWitnesses},indent=2))
