import json, hashlib, pathlib, subprocess, tarfile, sys, re
ROOT=pathlib.Path(__file__).resolve().parents[2]
R=ROOT/'reports/security-services'; PROOF=ROOT.parent/'tsx-core-candidate-proof-20260915'
REV='5a532f0230d52e1169cb60311e4f9f726a86d003'
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_bytes())
graph=[]; seen=set(); archives={}
def binding(b):
    if 'archive' in b:
        a=b['archive']; p=ROOT/a['path']
        if a['path'] not in archives:
            assert sha(p.read_bytes())==a['sha256']; archives[a['path']]=tarfile.open(p,'r:gz')
        raw=archives[a['path']].extractfile(b['member']).read(); label=a['path']+'::'+b['member']
    else:
        p=ROOT/b['path']; raw=p.read_bytes(); label=b['path']
    assert sha(raw)==b['sha256'],label
    graph.append({'reference':label,'sha256':b['sha256'],'verified':True})
    return raw
def walk(d, recurse=True):
    if isinstance(d,list):
        for x in d: walk(x,recurse)
    elif isinstance(d,dict):
        if 'sha256' in d and ('archive' in d and 'member' in d or 'path' in d):
            key=json.dumps({k:d[k] for k in ('archive','member','path','sha256') if k in d},sort_keys=True)
            if key not in seen:
                seen.add(key); raw=binding(d)
                # Archived documents are historical contexts; their source paths are not assertions about today's checkout.
                if recurse and 'archive' not in d and d.get('path','').startswith('reports/') and d['path'].endswith('.json'):
                    doc=json.loads(raw)
                    # Exact current supplements and plan are reference authorities. Other reviews are hash-bound and read separately.
                    if '5a532f' in d['path']: walk(doc,recurse)
        for k,v in d.items():
            if k!='archive': walk(v,recurse)
names={'hyperliquid-5a532f-receipt-candidate-lf.json':'478e4bac1387ce1a1dc775461729607a7c0a0a71ddc68a288e0149f2c7bc8634','fixer-5a532f-parity-supplement.json':'d80644ab8d3a8e907fb9e693faae839786a2da8188f7112b7e26d43ac9d885e5','fixer-5a532f-execution-supplement.json':'e34c5f23053f79b45d1aa5e68682393026e223f54c88e11b1ba2fd47127ba6d8','fixer-5a532f-complete-source-supplement.json':'c59bb24b500e9052a7802df5a40eace1cafb6166dee0a8dbe780954988994807'}
for n,h in names.items(): assert sha((R/n).read_bytes())==h; walk(read(R/n))
c,p,e,s=[read(R/n) for n in names]
after=read(R/'fixer-5a532f-final-context-after.json'); before=read(R/'fixer-5a532f-final-context-before.json')
assert before['inputs']==after['inputs'] and before['runtime']==after['runtime']
items=after['inputs']['files']; inputs={x['path']:x['sha256'] for x in items}
stream=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,input=''.join(REV+':'+x['path']+'\n' for x in items).encode()); pos=0
for x in items:
    end=stream.index(b'\n',pos); size=int(stream[pos:end].split()[2]); blob=stream[end+1:end+1+size]; pos=end+size+2
    assert sha(blob)==x['sha256']==sha((PROOF/x['path']).read_bytes())==sha((ROOT/x['path']).read_bytes()),x['path']
    assert (PROOF/x['path']).stat().st_nlink==1 and (ROOT/x['path']).stat().st_nlink==1
base=json.loads(binding(s['baselineContext'])); old={x['path']:x['sha256'] for x in base['inputs']['files']}
deltas={k for k,v in inputs.items() if old.get(k)!=v}; assert deltas=={x['path'] for x in s['deltas']} and len(deltas)==12 and not(set(old)-set(inputs))
for k in ('sourceTreeHash','nodeSourcesHash','testSourcesHash','fixturesHash'): assert c[k]==after['inputs'][k]
for k in ('executorTreeHash','sdkTreeHash','profileHash'): assert c[k]==after['runtime'][k]
for kind,count in [('frontend',164),('python',118)]:
    part=e[kind]; hist=json.loads(binding(part['originalExecutionContext'])); hi={x['path']:x['sha256'] for x in hist['inputs']['files']}
    assert len(part['unchangedInputs'])==count and all(inputs[k]==v==hi[k] for k,v in part['unchangedInputs'].items())
    if kind=='python': assert hist['runtime']==after['runtime']
    assert not part['freshCurrentRunClaimed']
    logs=[binding(b) for b in part['evidence']]
    if kind=='python': assert b'Ran 548 tests' in logs[1] and re.search(rb'^OK\s*$',logs[1],re.M) and json.loads(logs[0])['exitCode']==0
    else: assert b'328 passed (328)' in logs[1] and b'40 passed (40)' in logs[1]
log=(R/'fixer-5a532f-final-module.log').read_bytes(); assert b'ALL 226 TEST FILES PASSED' in log and b'Module coverage ratchet passed.' in log
completion=read(R/'fixer-5a532f-final-verification-completion.json'); assert completion['failure'] is None and {x['name']:x['exitCode'] for x in completion['rows']}=={'build':0,'module-coverage':0}
for n in ['fixer-5a532f-final-module.log','fixer-5a532f-final-build.log','fixer-5a532f-final-verification-completion.json']: assert (R/n).read_bytes()==(PROOF/'reports/security-services'/n).read_bytes()
w=[w for row in p['rows'] for w in row['witnessBindings']]; assert len(p['rows'])==62 and len(w)==97
assert sum(not x['unchangedSinceB425'] for x in w)==3
assert all(inputs[x['path']]==x['sha256'] and (old[x['path']]==x['sha256'])==x['unchangedSinceB425'] for x in w)
sys.path.insert(0,str(PROOF/'exchange_executor'))
from ccxt_certification_evidence import python_tree_hash
import ccxt
assert python_tree_hash(PROOF/'exchange_executor')==c['executorTreeHash']
assert python_tree_hash(pathlib.Path(ccxt.__file__).parent,sdk=True)==c['sdkTreeHash']
assert ccxt.__version__==c['ccxtVersion']
assert all(x['providerAcceptanceVerified'] is False for x in (c,p,e,s))
out={'kind':'independent-actual-byte-reference-graph','revision':REV,'candidateSha256':names[next(iter(names))],'references':graph,'counts':{'uniqueReferenceBindings':len({(x['reference'],x['sha256']) for x in graph}),'sourceInputsRawNextAndProofEqualGit':len(items),'delta':len(deltas),'unchanged':len(inputs)-len(deltas),'requirements':len(p['rows']),'witnesses':len(w),'changedWitnesses':3},'runtimeActualSdkAndExecutorHashesVerified':True,'sourceDeltas':sorted(deltas),'status':'passed'}
dest=R/'fixer-5a532f-independent-receipt-reference-graph.json'; dest.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({'report':str(dest),'sha256':sha(dest.read_bytes()),'counts':out['counts']}))
