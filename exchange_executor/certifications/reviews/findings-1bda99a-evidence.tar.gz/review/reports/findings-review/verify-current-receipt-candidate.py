"""Separate, read-only candidate verifier; never grants operative authority.

Run only after candidate creation: locked Python -B this.py --tag final-v5.
This script deliberately does not import or run the preparation generator.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path.cwd().resolve()
R = ROOT / 'reports/findings-review'
NODE = 'C:/Users/nikla/AppData/Local/Programs/node22/node-v22.23.2-win-x64/node.exe'
sha = lambda value: hashlib.sha256(value).hexdigest()
read = lambda path: json.loads(path.read_bytes())
stamp = lambda value: datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))

def ref(path):
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(path.read_bytes())}

def bound(value):
    if 'archive' in value:
        archive = ROOT / value['archive']['path']
        assert sha(archive.read_bytes()) == value['archive']['sha256']
        with tarfile.open(archive) as handle:
            raw = handle.extractfile(value['member']).read()
    else:
        raw = (ROOT / value['path']).read_bytes()
    assert sha(raw) == value['sha256']
    return raw

def report(value):
    return json.loads(bound(value))

def log(row):
    raw = (ROOT / row['log']).read_bytes()
    assert row['exitCode'] == 0 and sha(raw) == row['logSha256']
    return raw.decode('utf-8-sig')

parser = argparse.ArgumentParser()
parser.add_argument('--tag', required=True)
args = parser.parse_args()
assert re.fullmatch(r'[a-zA-Z0-9_-]+', args.tag)
state_path = R / f'{args.tag}-receipt-candidate-state.json'
state = read(state_path)
candidate, execution, parity, source_review = [report(state[key]) for key in ('candidate', 'execution', 'parity', 'completeSourceReview')]
revision = state['revision']
assert all(value['revision'] == revision for value in (execution, parity, source_review))
assert candidate['sourceRevision'] == revision
assert candidate['parityEvidenceHash'] == state['parity']['sha256']
assert candidate['executionReportHash'] == state['execution']['sha256']
assert state['operativeReceiptApproved'] is False and state['operativeReceiptOrPinsChanged'] is False
assert candidate['providerAcceptanceVerified'] is False

before, after = [report(execution[key]) for key in ('beforeContext', 'afterContext')]
assert before['revision'] == after['revision'] == revision
assert before['inputs'] == after['inputs'] and before['node'] == after['node']
assert before['rawEqualsGit'] and after['rawEqualsGit'] and before['allInputsSingleLink'] and after['allInputsSingleLink']
actual = json.loads(subprocess.check_output([NODE, '--input-type=module', '-e',
    "import {collectBuildInputs} from './scripts/verify_exchange_implementation.js';console.log(JSON.stringify(collectBuildInputs(process.cwd())));"], text=True))
assert actual == before['inputs']
files = {row['path']: row['sha256'] for row in actual['files']}
assert len(files) == len(actual['files']) == 970
for key in ('sourceTreeHash', 'nodeSourcesHash', 'testSourcesHash', 'fixturesHash'):
    assert candidate[key] == actual[key]
stream = subprocess.check_output(['git', 'cat-file', '--batch'], input=''.join(f'{revision}:{path}\n' for path in files).encode())
position = 0
for path, digest in files.items():
    end = stream.index(b'\n', position)
    size = int(stream[position:end].split()[2])
    assert sha(stream[end + 1:end + 1 + size]) == digest
    position = end + size + 2
    entry = ROOT / path
    assert entry.is_file() and not entry.is_symlink() and entry.stat().st_nlink == 1 and sha(entry.read_bytes()) == digest

node_source = """import fs from 'node:fs';import crypto from 'node:crypto';
import {compareBuildReceipt} from './scripts/verify_exchange_implementation.js';
const bytes=fs.readFileSync(process.argv[1]);
const result=compareBuildReceipt(bytes,{root:process.cwd(),exchange:'hyperliquid',profileVersion:1,
 approvedReceiptHashes:[crypto.createHash('sha256').update(bytes).digest('hex')]});
console.log(JSON.stringify(result));"""
node_comparison = json.loads(subprocess.check_output([NODE, '--input-type=module', '-e', node_source, state['candidate']['path']], text=True))
assert node_comparison['buildInputsMatch'] is True and node_comparison['implementationVerified'] is False
# This explicit caller review context tests production comparison semantics. It
# does not modify the real Python approval registry or assert an operative pin.
sys.path.insert(0, str(ROOT / 'exchange_executor'))
import ccxt
from ccxt_certification_evidence import python_tree_hash, expected_profile_hash, validate_receipt
from ccxt_profiles import PROFILES
assert sys.version_info[:2] == (3, 12) and ccxt.__version__ == '4.5.75'
validate_receipt(candidate, 'hyperliquid', ccxt.__version__, PROFILES['hyperliquid'], ROOT / 'exchange_executor', Path(ccxt.__file__).parent)
runtime = execution['runtime']
assert runtime['python'] == sys.version and runtime['ccxt'] == ccxt.__version__
assert runtime['node'] == subprocess.check_output([NODE, '--version'], text=True).strip() == before['node']
for key, value in {'executorTreeHash': python_tree_hash(ROOT / 'exchange_executor'),
    'sdkTreeHash': python_tree_hash(Path(ccxt.__file__).parent, sdk=True), 'profileHash': expected_profile_hash(PROFILES['hyperliquid'])}.items():
    assert candidate[key] == runtime[key] == value
active_path = ROOT / 'exchange_executor/certifications/hyperliquid.json'
assert sha(active_path.read_bytes()) == '9d56f6946102b339acce02ac2ccc5c0388b44402f60a5de1cd461309626d4c8b'
active = read(active_path)
for key in ('schemaVersion', 'kind', 'exchange', 'ccxtVersion', 'profileVersion', 'profileHash', 'scope', 'providerAcceptanceVerified'):
    assert candidate[key] == active[key]

completion = report(execution['node']['completion'])
assert completion['revision'] == revision and completion['afterContextExit'] == 0 and len(completion['rows']) == 2
assert {r['name'] for r in completion['rows']} == {'build', 'test:coverage:modules'}
for row in completion['rows']:
    text = log(row)
    assert stamp(before['observedAt']) <= stamp(row['startedAt']) <= stamp(row['finishedAt']) <= stamp(after['observedAt'])
    if row['name'] == 'test:coverage:modules':
        assert 'ALL 226 TEST FILES PASSED' in text and 'Module coverage ratchet passed.' in text
continuity = report(execution['inheritedCurrentSessionExecution'])
assert continuity['revision'] == revision and continuity['runtime'] == runtime
python = report(continuity['python']['execution'])
python_log = log(python)
assert 'Ran 548 tests' in python_log and re.search(r'^OK\s*$', python_log, re.M)
assert stamp(python['startedAt']) < stamp(python['completedAt'])
assert python['inputsBefore'] == python['inputsAfter']
observed = {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in (ROOT / 'exchange_executor').rglob('*.py') if '__pycache__' not in p.parts}
for path in ('docs/testing/ccxt-expansion-matrix.json', 'exchange_executor/requirements.txt'):
    if (ROOT / path).exists():
        observed[path] = sha((ROOT / path).read_bytes())
assert observed == python['inputsAfter']
for key in ('python', 'ccxt', 'executorTreeHash', 'sdkTreeHash'):
    assert python[key] == runtime[key]
frontend = report(continuity['frontend']['execution'])
frontend_context = report(continuity['frontend']['context'])
frontend_after = report(continuity['frontend']['afterContext'])
frontend_log = log(frontend)
assert frontend['revision'] == frontend_context['revision'] == revision
assert frontend_context['inputs'] == actual and frontend['sourceTreeHash'] == actual['sourceTreeHash'] and frontend['inputsUnchanged']
assert frontend_after['inputs'] == actual and frontend_after['revision'] == revision
assert '333 passed (333)' in frontend_log and '40 passed (40)' in frontend_log
assert stamp(frontend['startedAt']) < stamp(frontend['finishedAt'])
assert stamp(frontend_context['observedAt']) <= stamp(frontend['startedAt']) <= stamp(frontend_after['observedAt']) <= stamp(frontend['finishedAt'])
assert not continuity['frontend']['sourceChangesSinceRun'] and continuity['frontend']['freshFinalRevisionRunClaimed']

delta = report(source_review['deltas'])
baseline = report(delta['baselineContext'])
old = {row['path']: row['sha256'] for row in baseline['inputs']['files']}
changed_paths = {path for path in set(old) | set(files) if old.get(path) != files.get(path)}
assert len(delta['deltas']) == len(changed_paths) and {row['path'] for row in delta['deltas']} == changed_paths
reviews = {row['path']: row for row in source_review['reviews']}
assert len(reviews) == len(source_review['reviews']) and set(reviews) == changed_paths
for row in delta['deltas']:
    path = row['path']
    assert row['beforeSha256'] == old.get(path) and row['currentSha256'] == files.get(path)
    review = reviews[path]
    assert review['currentSha256'] == files.get(path) and review['reviewed'] is True and review['rationale'].strip() and review['evidence']
    for evidence in review['evidence']:
        bound(evidence)
historic = report(parity['baselineParity'])
prior_rows = {(row['category'], row['check']): row for row in historic['rows']}
current_rows = {(row['category'], row['check']): row for row in parity['rows']}
assert len(prior_rows) == len(current_rows) == len(parity['rows']) == 62 and set(current_rows) == set(prior_rows)
witness_count = changed_count = 0
for key, row in current_rows.items():
    prior = prior_rows[key]
    assert row['sourceReview'] == state['completeSourceReview'] and row['execution'] == state['execution']
    assert [w['path'] for w in row['witnessBindings']] == [w['path'] for w in prior['witnessBindings']]
    for witness, old_witness in zip(row['witnessBindings'], prior['witnessBindings']):
        witness_count += 1
        path = witness['path']
        assert witness['sha256'] == files[path] and witness['previousSha256'] == old_witness['sha256'] == old[path]
        assert witness['unchanged'] == (files[path] == old[path])
        if not witness['unchanged']:
            changed_count += 1
            review = witness['review']
            assert review['lookup'] == path and review['rationale'].strip()
            detail = report(review['evidence'])
            if path.endswith('.js'):
                item = next(item for item in detail if item['path'] == path)
                assert item['currentSha256'] == files[path] and item['previousSha256'] == old[path] and not item['missing']
                assert item['normalization'] == 'Formatting/comments only; async callbacks are not normalized.'
            else:
                item = next(item for item in detail['changes'] if item['path'] == path)
                assert item['currentSha256'] == files[path] and item['beforeSha256'] == old[path]
                assert item['nextExpressionMultisetPreserved'] and all(x['assertionsEquivalentAfterInliningNextLocals'] for x in item['assertionEquivalenceChecks'])
assert witness_count == 97 and parity['counts']['changedWitnessReferences'] == changed_count
graph = json.loads(subprocess.check_output([sys.executable, '-B', str(R / 'audit-receipt-reference-closure.py'), str(state_path)], text=True))
assert graph['unresolvedReferences'] == 0
result = {'kind': 'separate-candidate-verification-not-operative-approval', 'revision': revision,
    'candidate': state['candidate'], 'verifier': ref(Path(__file__).resolve()),
    'checks': {'productionNodeComparison': node_comparison, 'productionPythonValidation': 'PASS',
        'rawGitAndCurrentInputs': len(files), 'sourceDeltasWithExplicitReviewRecords': len(changed_paths),
        'requirements': 62, 'witnessReferences': witness_count, 'changedWitnessReferences': changed_count,
        'nodeTestFiles': 226, 'frontendTests': 333, 'pythonTests': 548},
    'referenceClosure': graph, 'semanticReviewBoundary': 'Verified existence and binding of explicit source review records; their semantic conclusions require the named human/agent reviews, not merely matching hashes.',
    'candidateComparisonUsedExplicitReviewContextOnly': True, 'operativeReceiptApproved': False,
    'providerAcceptanceVerified': False, 'remaining': ['Deterministic archive verification', 'Explicit root adoption', 'Actual operative production gate and bridge test']}
destination = R / f'{args.tag}-independent-receipt-review.json'
with destination.open('xb') as handle:
    handle.write((json.dumps(result, indent=2) + '\n').encode())
print(json.dumps({'report': ref(destination), 'checks': result['checks'], 'operativeReceiptApproved': False}, indent=2))
