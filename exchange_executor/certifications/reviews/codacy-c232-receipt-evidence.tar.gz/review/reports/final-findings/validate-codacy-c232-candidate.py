"""Independent read-only review of the unadopted Codacy c232 receipt candidate."""
import argparse
import copy
import datetime
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

from receipt_renewal_safety_candidate import plain_local, check_command_inventory, check_group_inventory

ROOT = Path.cwd().resolve()
OUT = ROOT / 'reports/final-findings'
HEAD = 'c23272a3228a8e25c3604a556131b978822abe56'
PREV = '9740c2973e1cd71e16bbf597cc22a88a12860118'
CURRENT_TREE = '2e5fc760e96e35a029d632a1c2bf024c8a4448ee79a20196198b0a7b583e1c8c'
ARCHIVE = ROOT / 'exchange_executor/certifications/reviews/govuln9740-receipt-evidence.tar.gz'
MANIFEST = ROOT / 'exchange_executor/certifications/reviews/govuln9740-receipt-evidence-manifest.json'
ARCHIVE_SHA = 'e726e4d83952063ed965fa83a9b946b2a3855eee213b08532d1ee0fb3e65a517'
MANIFEST_SHA = '70bdeedb4d0bc19032404b39cfd9b6a164f456115ba57ef86ecd1fe90506735b'
RECEIPT_SHA = 'eefcdd4d9af1c81482569577508b5e330ade162496073d7adb9ea7bc7e30cfc9'
PINS_SHA = '898d8dde7524cd5231f08b4ab078bbc217b121bda73d71302963b3b45127f468'
NODE = 'C:/Users/nikla/AppData/Local/Programs/node22/node-v22.23.2-win-x64/node.exe'
PYTHON = str(ROOT.parent / 'tsx-security-python-env/Scripts/python.exe')
GROUPS = ['foundation', 'backend', 'python', 'frontend', 'build', 'browser', 'mutations', 'dependencies']
DELTAS = {'docs/testing/final-codacy-2026-09-17.json'}
RENEWED_SOURCES = {'monitoring/govulncheck/go.mod', 'tests/test_monitoring_artifacts.js',
                   'tests/test_supply_chain.js'}
FIRST_BACKEND_SHA = '9351527c03f951e400af1af3914417a9a159b20ba299afcb3e815d05cba6a6b6'
FIRST_BACKEND_LOGS = {'backend-coverage': '950ffeba493c7cf05208d636240eb6398396f278f317c560548f27ee7adc10c1',
                      'backend-module-coverage': '6b67de70ca9548b44668cb354d1a49a56f10db1e29b1b1bb9dd9873f714d0628'}
SECOND_BACKEND_SHA = '22afeac28d44d3140adc504e1103790061247edd166f7a7efe891ea75ffd65d5'
SECOND_BACKEND_LOGS = {'backend-coverage': '50d8fdd9f980c793605849d07e640aba820b1dd65854c66fc7624cb53bbf2ab1',
                       'backend-module-coverage': 'e6e0b8535c4dd5f6eef16487f6edbbc862a4c62e0e8e07c4cd4d2f70368fc985'}
ISOLATED_LOG_SHA = '3ed3a4d00a5e18c9fa5783503f1f8b8aa663affaf4d2d262e9817cf5934ae123'
MUTATION_SOURCES = {
    'queue': ('src/queue.ts', 'node --import tsx tests/test_queue.js'),
    'retry': ('src/tdlib_retry.ts', 'node --import tsx tests/test_tdlib_retry.js'),
    'schema': ('src/signal_schema.ts', 'node --import tsx tests/test_signal_parser.js && node --import tsx tests/test_signal_contract_validation.js'),
    'trading-risk': ('src/trading_risk.ts', 'node --import tsx tests/test_trading_core.js && node --import tsx tests/test_trading_leverage_tiers.js'),
}
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key')
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))


def bytes_at(path):
    p = plain_local(ROOT, path)
    require(p.stat().st_size <= 256 * 1024 * 1024, 'Evidence file too large')
    return p.read_bytes()


def read(path):
    return parse(bytes_at(path))


def binding(path):
    p = plain_local(ROOT, path)
    return {'path': p.relative_to(ROOT).as_posix(), 'sha256': sha(bytes_at(p))}


def bound(value):
    require(set(value) == {'path', 'sha256'}, 'Reference schema differs')
    p = plain_local(ROOT, value['path'])
    expected_path = str(p) if Path(value['path']).is_absolute() else p.relative_to(ROOT).as_posix()
    require(value['path'] == expected_path and sha(bytes_at(p)) == value['sha256'],
            'Reference path or bytes differ: ' + value['path'])
    return p


def ts(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))


def sealed(archive, name):
    require(sha(bytes_at(archive)) == ARCHIVE_SHA, 'Sealed predecessor archive changed')
    require(sha(bytes_at(MANIFEST)) == MANIFEST_SHA, 'Sealed predecessor manifest changed')
    manifest = read(MANIFEST)
    require(manifest['sourceRevision'] == PREV and manifest['unresolvedReferences'] == [],
            'Sealed predecessor manifest source or closure differs')
    with tarfile.open(archive, 'r:gz') as handle:
        members = handle.getmembers()
        require(len(members) <= 20000 and len({m.name for m in members}) == len(members)
                and {m.name for m in members} == {'manifest.json'} | {r['member'] for r in manifest['files']}
                and parse(handle.extractfile('manifest.json').read()) == manifest,
                'Ambiguous or changed sealed archive inventory')
        for row in manifest['files']:
            member = handle.getmember(row['member'])
            require(member.isfile() and not member.issym() and not member.islnk()
                    and member.size == row['bytes'] and sha(handle.extractfile(member).read()) == row['sha256'],
                    'Sealed predecessor archive member differs')
        member_name = 'review/reports/final-findings/' + name
        member = handle.getmember(member_name)
        require(member.isfile() and not member.issym() and not member.islnk(), 'Invalid historical member')
        raw = handle.extractfile(member).read()
    return parse(raw), {'archive': binding(archive), 'member': member_name, 'sha256': sha(raw)}


def check_ledger_change():
    path = 'docs/testing/final-codacy-2026-09-17.json'
    previous = parse(subprocess.check_output(['git', 'show', 'HEAD^:' + path]))
    current = read(ROOT / path)
    require(previous['entries'] == current['entries'] and len(current['entries']) == 439
            and len({e['issueId'] for e in current['entries']}) == 439,
            'Historical Codacy entries or IDs changed')
    old_sources = {r['path']: r for r in previous['finalReview']['sources']}
    new_sources = {r['path']: r for r in current['finalReview']['sources']}
    changed = {p for p in old_sources if old_sources[p] != new_sources[p]}
    unchanged = copy.deepcopy(previous)
    unchanged['finalReview']['sources'] = current['finalReview']['sources']
    require(set(old_sources) == set(new_sources) and changed == RENEWED_SOURCES
            and unchanged == current, 'Codacy ledger contains changes beyond three final source bindings')
    affected = set()
    line_count = 0
    for path in sorted(changed):
        require(old_sources[path]['baselineSha256'] == new_sources[path]['baselineSha256'],
                'Historical Codacy baseline hash changed')
        source = bytes_at(ROOT/path).decode('utf-8').replace('\r\n', '\n')
        lines = source.split('\n')
        require(sha(source.encode('utf-8')) == new_sources[path]['normalizedSha256'],
                'Current Codacy final source binding differs')
        for entry in current['entries']:
            if path not in entry['finalSourcePaths']:
                continue
            affected.add(entry['issueId'])
            for row in entry['finalEvidence']:
                if row['path'] == path:
                    require(0 < row['line'] <= len(lines)
                            and sha(lines[row['line']-1].strip().encode('utf-8')) == row['normalizedLineSha256'],
                            'Historical Codacy line binding differs')
                    line_count += 1
    require(len(affected) == 37 and line_count == 41,
            'Codacy affected issue or final line inventory differs')
    return sha(bytes_at(ROOT/'docs/testing/final-codacy-2026-09-17.json'))


def check_git_inputs(inputs):
    rows = inputs['files']
    require(len(rows) == 1002 and len({r['path'] for r in rows}) == 1002,
            'Current build input path inventory differs')
    tracked = set(subprocess.check_output(['git', 'ls-files', '-z']).decode().strip('\0').split('\0'))
    require(all(r['path'] in tracked and sha(bytes_at(ROOT/r['path'])) == r['sha256']
                for r in rows), 'Current raw input is missing from Git or differs from inventory')
    require(not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], text=True).strip(),
            'Current tracked bytes differ from frozen Git revision')


def check_source(state, candidate, parity, execution):
    require(state['revision'] == HEAD and state['operativeReceiptApproved'] is False
            and state['operativeReceiptOrPinsChanged'] is False,
            'Candidate state claims operative authority')
    require(sha(bytes_at(ROOT/'exchange_executor/certifications/hyperliquid.json')) == RECEIPT_SHA
            and sha(bytes_at(ROOT/'exchange_executor/ccxt_implementation_reviews.py')) == PINS_SHA,
            'Operative receipt or approval pins changed')
    require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == HEAD,
            'Wrong frozen source revision')
    require(not subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).strip(),
            'Tracked working tree changed')
    prior = read(ROOT/'exchange_executor/certifications/hyperliquid.json')
    old_context, context_ref = sealed(ARCHIVE, 'receipt-context-govuln9740-after.json')
    old_parity, parity_ref = sealed(ARCHIVE, 'govuln9740-receipt-parity-supplement.json')
    old_candidate, old_candidate_ref = sealed(ARCHIVE, 'govuln9740-hyperliquid-receipt-candidate.json')
    old_state, old_state_ref = sealed(ARCHIVE, 'govuln9740-receipt-candidate-state.json')
    require(old_candidate == prior and old_candidate_ref['sha256'] == RECEIPT_SHA
            and prior['parityEvidenceHash'] == parity_ref['sha256']
            and prior['sourceTreeHash'] == old_context['inputs']['sourceTreeHash']
            and state['predecessorReceiptState'] == old_state_ref
            and old_state['candidate'] == {'path': 'reports/final-findings/govuln9740-hyperliquid-receipt-candidate.json',
                'sha256': RECEIPT_SHA}
            and old_context['revision'] == old_parity['revision'] == prior['sourceRevision'] == PREV,
            'Sealed predecessor differs from operative receipt')
    script = "import {collectBuildInputs} from './scripts/verify_exchange_implementation.js';console.log(JSON.stringify(collectBuildInputs(process.cwd())));"
    inputs = parse(subprocess.check_output([NODE,'--input-type=module','-e',script]))
    require(inputs['sourceTreeHash'] == CURRENT_TREE and len(inputs['files']) == 1002,
            'Current exact source tree differs')
    check_git_inputs(inputs)
    old = {r['path']:r['sha256'] for r in old_context['inputs']['files']}
    now = {r['path']:r['sha256'] for r in inputs['files']}
    changes = [{'path':p,'beforeSha256':old.get(p),'currentSha256':now.get(p),
                'status':'modified' if p in old and p in now else 'added' if p in now else 'removed'}
               for p in sorted(set(old)|set(now)) if old.get(p)!=now.get(p)]
    require(len(old) == len(old_context['inputs']['files'])
            == len(now) == len(inputs['files']) == 1002 and len(changes) == 1
            and changes[0]['status'] == 'modified'
            and {r['path'] for r in changes} == DELTAS
            and set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines()) == DELTAS,
            'Independent one-file source delta differs')
    require(changes[0]['currentSha256'] == check_ledger_change(),
            'Codacy ledger current source hash differs')
    review = read(bound(state['completeSourceReview']))
    delta = read(bound(review['deltas']))
    require(delta['revision'] == review['revision'] == HEAD
            and delta['predecessorContext'] == context_ref and delta['deltas'] == changes
            and delta['counts'] == {'priorInputs': 1002, 'currentInputs': 1002, 'changedAddedRemoved': 1}
            and delta['reviewed'] is False and delta['operativeReceiptOrPinsChanged'] is False
            and review['reviewed'] is True and review['providerAcceptanceVerified'] is False
            and review['operativeReceiptOrPinsChanged'] is False,
            'Source-review bindings differ')
    rows = {r['path']:r for r in review['reviews']}
    require(len(rows) == len(review['reviews']) == 1 and set(rows) == DELTAS,
            'Incomplete one-file source review')
    for change in changes:
        row = rows[change['path']]
        require(all(row[key] == change[key] for key in ('beforeSha256','currentSha256','status'))
                and row['reviewed'] is True and row['rationale'].strip() and row['evidence'],
                'Unreviewed individual source change')
        for evidence in row['evidence']:
            bound(evidence)
    prev = {(r['category'],r['check']):r for r in old_parity['rows']}
    current = {(r['category'],r['check']):r for r in parity['rows']}
    require(len(prev) == len(old_parity['rows'])
            == len(current) == len(parity['rows']) == 62 and set(prev) == set(current)
            and parity['priorParity'] == parity_ref
            and parity['counts'] == {'requirements':62,'witnessReferences':97,
                                     'changedWitnessReferences':0,'unchangedWitnessReferences':97},
            'Exact requirement identity inventory changed')
    count = 0
    for key, row in current.items():
        prior_w = prev[key]['witnessBindings']
        require(row['witnessBindings'] == prior_w and row['completeSourceReview'] == state['completeSourceReview']
                and row['currentExecution'] == state['execution']
                and row['sealedPriorRow'] == {'evidence':parity_ref,'lookup':{'category':key[0],'check':key[1]}},
                'Witness path/hash or row provenance changed')
        for witness in prior_w:
            require(old[witness['path']] == now[witness['path']] == witness['sha256'],
                    'Changed historical witness')
            count += 1
    require(count == 97 and len({w['path'] for r in current.values() for w in r['witnessBindings']}) == 30,
            'Historical witness count or unique path inventory differs')
    require(candidate['sourceRevision'] == HEAD and candidate['sourceTreeHash'] == CURRENT_TREE
            and candidate['parityEvidenceHash'] == state['parity']['sha256']
            and candidate['executionReportHash'] == state['execution']['sha256'],
            'Candidate source or evidence commitment differs')
    for key in ('schemaVersion','kind','exchange','ccxtVersion','profileVersion','profileHash','scope','providerAcceptanceVerified'):
        require(candidate[key] == prior[key], 'Receipt scope/identity changed: ' + key)
    for key in ('nodeSourcesHash','testSourcesHash','fixturesHash'):
        require(candidate[key] == inputs[key], 'Candidate input commitment differs: ' + key)
    return inputs, 97


def checked_attempt(group, tag, inputs, runtime, after, expected_pass):
    path = OUT / f'verification-{group}-{tag}.json'
    report = read(path)
    check_command_inventory(report, ROOT, NODE)
    require(report['kind'] == 'observed-final-offline-verification'
            and report['schemaVersion'] == 1 and report['group'] == group
            and report['attempt'] == tag and report['revision'] == report['revisionAfter'] == HEAD
            and report['inputsBefore'] == report['inputsAfter'] == inputs
            and report['observedInputsUnchanged'] is True
            and report['allCommandsPassed'] is expected_pass
            and report['providerAcceptanceVerified'] is False
            and report.get('completedAt')
            and report['runtime']['node'] == runtime['node']
            and report['runtime']['ccxt'] == runtime['ccxt']
            and report['runtime']['python'] == 'Python ' + runtime['python'].split()[0]
            and ts(report['startedAt']) <= ts(report['completedAt']) <= ts(after['startedAt']),
            'Verification report identity, source, runtime or terminal result differs: ' + group + '/' + tag)
    logs = []
    text = {}
    for command in report['commands']:
        require(type(command['exitCode']) is int and command.get('signal') is None
                and not command.get('error')
                and command['log'] == f"reports/final-findings/verification-{command['name']}-{tag}.log"
                and ts(report['startedAt']) <= ts(command['startedAt'])
                <= ts(command['completedAt']) <= ts(report['completedAt']),
                'Verification command, log path or timing differs')
        log = binding(ROOT / command['log'])
        require(log['sha256'] == command['logSha256'], 'Verification log bytes differ')
        logs.append(log)
        text[command['name']] = bytes_at(ROOT / command['log']).decode('utf-8-sig')
    require(len(logs) == len(report['commands']) and report['commands'],
            'Verification command/log count differs')
    return report, binding(path), logs, text


def check_isolated_diagnostic(reference, selected, after, inputs):
    require(reference['path'] == 'reports/final-findings/codacy-c232-protected-entry-diagnostic-r2.json',
            'Isolated diagnostic report path differs')
    report = read(bound(reference))
    require(report['kind'] == 'isolated-protected-entry-diagnostic'
            and report['schemaVersion'] == 1
            and report['revision'] == HEAD
            and report['sourceTreeHash'] == report['sourceTreeHashBefore']
            == report['sourceTreeHashAfter'] == inputs['sourceTreeHash'] == CURRENT_TREE
            and report['revisionBefore'] == report['revisionAfter'] == HEAD
            and Path(report['command']).resolve() == Path(NODE).resolve()
            and report['args'] == ['tests/run_all.js', 'test_trading_protected_entry_crash.js']
            and report['cwd'] == str(ROOT)
            and type(report['exitCode']) is int and report['exitCode'] == 0
            and report.get('signal') is None and not report.get('error')
            and report['inputsUnchanged'] is True and report['revisionUnchanged'] is True
            and type(report['elapsedMs']) is int and 0 < report['elapsedMs'] < 120_000
            and report['providerAcceptanceVerified'] is False
            and ts(selected['completedAt']) <= ts(report['startedAt'])
            <= ts(report['completedAt']) <= ts(after['startedAt']),
            'Isolated diagnostic command, source, result or timing differs')
    expected_log = binding(OUT/'codacy-c232-protected-entry-diagnostic-r2.log')
    require(report['log'] == expected_log and bound(report['log'])
            and 'Protected-entry hard process crashes preserve journal phases' in
                bytes_at(OUT/'codacy-c232-protected-entry-diagnostic-r2.log').decode('utf-8-sig')
            and 'ALL 1 TEST FILES PASSED!' in
                bytes_at(OUT/'codacy-c232-protected-entry-diagnostic-r2.log').decode('utf-8-sig'),
            'Isolated protected-entry diagnostic log differs')
    return report


def check_execution(execution, inputs):
    require(execution['revision'] == HEAD and execution['providerAcceptanceVerified'] is False
            and execution['operativeReceiptApproved'] is False
            and execution['pythonExecutionInheritance'] is False
            and execution['beforeContextPresent'] is False,
            'Execution claims unsupported authority or before context')
    progress = read(bound(execution['progressContext']))
    after = read(bound(execution['afterContext']))
    require(all(c['revision'] == HEAD and c['inputs'] == inputs and c['rawEqualsGit']
                and c['allInputsSingleLink'] and c['sourceStableDuringCapture'] for c in (progress,after))
            and progress['runtime'] == after['runtime'] == execution['runtime']
            and ts(progress['observedAt']) <= ts(after['startedAt']),
            'Intermediate/final Git context differs')
    groups = execution['groups']
    check_group_inventory(groups)
    actual = {}
    backend_failure_preserved = False
    for entry in groups:
        group = entry['group']
        if group == 'backend':
            first, first_ref, first_logs, first_text = checked_attempt(
                group, 'codacy-c232', inputs, after['runtime'], after, False)
            retry, retry_ref, retry_logs, retry_text = checked_attempt(
                group, 'codacy-c232-r1', inputs, after['runtime'], after, False)
            selected, selected_ref, selected_logs, selected_text = checked_attempt(
                group, 'codacy-c232-r2', inputs, after['runtime'], after, True)
            require(first_ref['sha256'] == FIRST_BACKEND_SHA
                    and [c['exitCode'] for c in first['commands']] == [0, 1]
                    and {c['name']: log['sha256'] for c, log in zip(first['commands'], first_logs)}
                    == FIRST_BACKEND_LOGS
                    and first_text['backend-module-coverage'].count('Error: Test timed out in 5000ms.') == 3,
                    'Original Vitest timeout attempt differs')
            require(retry_ref['sha256'] == SECOND_BACKEND_SHA
                    and [c['exitCode'] for c in retry['commands']] == [1, 0]
                    and {c['name']: log['sha256'] for c, log in zip(retry['commands'], retry_logs)}
                    == SECOND_BACKEND_LOGS
                    and 'test_trading_protected_entry_crash.js failed with signal SIGTERM.'
                    in retry_text['backend-coverage']
                    and 'ALL 229 TEST FILES PASSED!' in retry_text['backend-module-coverage']
                    and ts(first['completedAt']) <= ts(retry['startedAt']),
                    'Second complete failed attempt or SIGTERM evidence differs')
            require([c['exitCode'] for c in selected['commands']] == [0, 0]
                    and ts(retry['completedAt']) <= ts(selected['startedAt'])
                    and 'Module coverage ratchet passed.' in selected_text['backend-module-coverage']
                    and re.search(r'ALL [0-9]+ TEST FILES PASSED!', selected_text['backend-module-coverage']),
                    'Third full backend attempt is incomplete or not terminal green')
            review_ref = entry['attemptSelection']
            require(isinstance(review_ref, dict)
                    and review_ref['path'] == 'reports/final-findings/codacy-c232-backend-attempt-selection-review.json',
                    'Explicit backend selection review missing')
            selection = read(bound(review_ref))
            require(set(selection) == {'revision', 'group', 'sourceTreeHash',
                    'originalAttempt', 'firstRetryAttempt', 'selectedAttempt',
                    'originalReport', 'originalLogs', 'firstRetryReport', 'firstRetryLogs',
                    'selectedReport', 'selectedLogs', 'isolatedDiagnostic', 'reviewed',
                    'reviewedAt', 'originalFailureAssessment', 'firstRetryFailureAssessment',
                    'selectionAssessment', 'providerAcceptanceVerified', 'operativeReceiptApproved'}
                    and selection['revision'] == HEAD and selection['group'] == group
                    and selection['sourceTreeHash'] == CURRENT_TREE
                    and selection['originalAttempt'] == 'codacy-c232'
                    and selection['firstRetryAttempt'] == 'codacy-c232-r1'
                    and selection['selectedAttempt'] == 'codacy-c232-r2'
                    and selection['originalReport'] == first_ref
                    and selection['originalLogs'] == first_logs
                    and selection['firstRetryReport'] == retry_ref
                    and selection['firstRetryLogs'] == retry_logs
                    and selection['selectedReport'] == selected_ref
                    and selection['selectedLogs'] == selected_logs
                    and selection['reviewed'] is True
                    and selection['providerAcceptanceVerified'] is False
                    and selection['operativeReceiptApproved'] is False
                    and all(isinstance(selection[k], str) and selection[k].strip() for k in
                        ('originalFailureAssessment', 'firstRetryFailureAssessment', 'selectionAssessment')),
                    'Backend selection review does not bind all three full attempts')
            diagnostic = check_isolated_diagnostic(selection['isolatedDiagnostic'],
                                                   selected, after, inputs)
            require(ts(selection['reviewedAt']) >= ts(diagnostic['completedAt']),
                    'Backend selection review predates isolated diagnostic')
            preserved = entry['preservedEarlierAttempts']
            require(entry['report'] == selected_ref and entry['logs'] == selected_logs
                    and entry['freshAtFrozenRevision'] is True
                    and entry['originalAllCommandsPassed'] is False
                    and len(entry['reviewedReplacements']) == 1
                    and all(entry['reviewedReplacements'][0][k] == v for k, v in
                        {'report': selected_ref, 'logs': selected_logs,
                         'selectionReview': review_ref}.items())
                    and len(preserved) == 2
                    and all(preserved[0][k] == v for k, v in
                        {'report': first_ref, 'logs': first_logs,
                         'allCommandsPassed': False, 'exitCodes': [0, 1]}.items())
                    and all(preserved[1][k] == v for k, v in
                        {'report': retry_ref, 'logs': retry_logs,
                         'allCommandsPassed': False, 'exitCodes': [1, 0]}.items()),
                    'Execution supplement dropped a complete failed backend attempt')
            actual[group] = selected
            backend_failure_preserved = True
            continue
        report, report_ref, logs, text = checked_attempt(
            group, 'codacy-c232', inputs, after['runtime'], after, True)
        require(entry['report'] == report_ref and entry['logs'] == logs
                and entry['freshAtFrozenRevision'] is True
                and entry['originalAllCommandsPassed'] is True
                and not entry['reviewedReplacements'] and not entry['preservedEarlierAttempts']
                and entry['attemptSelection'] is None
                and all(c['exitCode'] == 0 for c in report['commands']),
                'Unreviewed selected verification attempt: ' + group)
        if group == 'foundation':
            mon = report['monitoringExecution']
            require(mon['mode'] == 'native-configuration-only'
                    and mon['containerAcceptanceVerified'] is False
                    and [t['key'] for t in mon['tools']] == ['PROMTOOL_PATH','AMTOOL_PATH'],
                    'Foundation native monitoring context differs')
            for tool in mon['tools']:
                require(sha(Path(tool['executable']).read_bytes()) == tool['sha256']
                        and tool['version'].strip(), 'Native monitoring executable changed')
        actual[group] = report
    mutation = actual['mutations']
    require(backend_failure_preserved
            and ts(mutation['startedAt']) <= ts(progress['startedAt'])
            <= ts(progress['observedAt']) <= ts(mutation['completedAt']),
            'Backend failure or intermediate mutation observation not preserved')
    return len(groups), len(actual['foundation']['commands'])


def check_mutation_artifacts(state, inputs):
    artifacts = state['mutationArtifacts']
    expected = ['queue','retry','schema','trading-risk']
    require([row['shard'] for row in artifacts] == expected,
            'Mutation shard artifact inventory differs')
    report = read(OUT/'verification-mutations-codacy-c232.json')
    require(len(report['commands']) == 1 and report['commands'][0]['name'] == 'mutations',
            'Mutation command identity differs')
    command = report['commands'][0]
    log = (OUT/'verification-mutations-codacy-c232.log').read_text(encoding='utf-8-sig')
    source_hashes = {r['path']:r['sha256'] for r in inputs['files']}
    last_mtime = None
    for row in artifacts:
        shard = row['shard']
        mutate_path, expected_command = MUTATION_SOURCES[shard]
        require(row['selectedCurrentRun']['path'] ==
                f"reports/final-findings/mutation-artifacts-codacy-c232/{shard}.json"
                and row['selectedCurrentRun']['sha256'] == row['sourceSha256AtCapture'],
                'Mutation artifact source/hash binding differs')
        artifact = read(bound(row['selectedCurrentRun']))
        config = artifact['config']
        require(artifact['schemaVersion'] == '1.0'
                and artifact['projectRoot'] == str(ROOT)
                and list(artifact['files']) == [mutate_path]
                and config['mutate'] == [mutate_path]
                and config['jsonReporter']['fileName'] == f'reports/mutation/{shard}.json'
                and config['testRunner'] == 'command'
                and config['commandRunner']['command'] == expected_command
                and config['coverageAnalysis'] == 'off'
                and config['incremental'] is False and config['force'] is True
                and artifact['thresholds'] == config['thresholds']
                == {'high':80,'low':70,'break':70},
                'Mutation artifact config does not match exact shard')
        original = artifact['files'][mutate_path]
        require(original['source'].encode('utf-8') == bytes_at(ROOT/mutate_path)
                and sha(original['source'].encode('utf-8')) == source_hashes[mutate_path],
                'Mutation artifact source differs from frozen Git')
        mutants = original['mutants']
        ids = [m['id'] for m in mutants]
        statuses = [m['status'] for m in mutants]
        require(mutants and len(ids) == len(set(ids))
                and set(statuses) <= {'Killed','Timeout','Survived'},
                'Mutation identities/statuses differ')
        counts = {status:statuses.count(status) for status in ('Killed','Timeout','Survived')}
        score = Decimal(100)*Decimal(counts['Killed']+counts['Timeout'])/Decimal(len(mutants))
        score_text = str(score.quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))
        marker = f'=== Mutation shard: {shard} ==='
        require(score >= Decimal(70) and row['mutantCounts'] == counts
                and row['mutationScorePercent'] == score_text and log.count(marker) == 1,
                'Mutation score or log marker differs')
        section = log.split(marker,1)[1].split('=== Mutation shard:',1)[0]
        logged_score = re.findall(r'Final mutation score of ([0-9]+\.[0-9]+) is greater than or equal to break threshold 70',section)
        instrumented = re.findall(r'Instrumented 1 source file\(s\) with (\d+) mutant\(s\)',section)
        require(logged_score == [score_text] and instrumented == [str(len(mutants))],
                'Mutation JSON score/count differs from run log')
        source_path = f'reports/mutation/{shard}.json'
        require(row['sourcePath'] == source_path, 'Mutation source path differs')
        source = plain_local(ROOT,source_path)
        mtime_ns = source.stat().st_mtime_ns
        mtime = datetime.datetime.fromtimestamp(mtime_ns/1_000_000_000,datetime.timezone.utc)
        require(sha(source.read_bytes()) == row['sourceSha256AtCapture']
                and mtime_ns == row['sourceMtimeNs']
                and ts(command['startedAt']) <= mtime <= ts(command['completedAt'])
                and (last_mtime is None or mtime_ns > last_mtime),
                'Mutation JSON was not written in ordered current command window')
        last_mtime = mtime_ns
    return len(artifacts)


def closure(state_path):
    queue = [state_path]
    visited = {}
    current = {}
    historical = {}
    def walk(value):
        if isinstance(value,list):
            for item in value: walk(item)
        elif isinstance(value,dict):
            if isinstance(value.get('archive'),dict) and isinstance(value.get('member'),str):
                archive = bound(value['archive']); member = value['member']
                require(not member.startswith('/') and '..' not in Path(member).parts
                        and '\\' not in member, 'Unsafe historical member')
                with tarfile.open(archive,'r:*') as handle:
                    entries = handle.getmembers()
                    require(len(entries) <= 20000 and len({e.name for e in entries}) == len(entries),
                            'Ambiguous historical archive')
                    item = handle.getmember(member)
                    require(item.isfile() and not item.issym() and not item.islnk()
                            and sha(handle.extractfile(item).read()) == value['sha256'],
                            'Historical member differs')
                historical[value['archive']['path']+':'+member] = value
                return
            if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
                item = {'path':value['path'],'sha256':value['sha256']}
                p = bound(item)
                current[item['path']] = item
                if p.is_relative_to(OUT): queue.append(p)
            if isinstance(value.get('log'),str) and isinstance(value.get('logSha256'),str):
                walk({'path':value['log'],'sha256':value['logSha256']})
            for item in value.values(): walk(item)
    while queue:
        p = plain_local(ROOT,queue.pop())
        relative = p.relative_to(ROOT).as_posix()
        if relative in visited: continue
        require(len(visited) < 20000, 'Current reference graph too large')
        raw = bytes_at(p);visited[relative] = sha(raw)
        if p.suffix == '.json': walk(parse(raw))
    for path,digest in visited.items():
        require(sha(bytes_at(ROOT/path)) == digest, 'Evidence changed during reference walk')
    return {'currentReports':len(visited),'currentReferences':len(current),
            'historicalMembers':len(historical),'unresolvedReferences':0}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--state', default='reports/final-findings/codacy-c232-receipt-candidate-state.json')
    args = parser.parse_args()
    state_path = plain_local(ROOT,args.state)
    require(state_path == OUT/'codacy-c232-receipt-candidate-state.json',
            'Candidate state path differs from frozen review scope')
    state = read(state_path)
    require(state['candidate']['path'] == 'reports/final-findings/codacy-c232-hyperliquid-receipt-candidate.json'
            and state['parity']['path'] == 'reports/final-findings/codacy-c232-receipt-parity-supplement.json'
            and state['execution']['path'] == 'reports/final-findings/codacy-c232-receipt-execution-supplement.json'
            and state['completeSourceReview']['path'] == 'reports/final-findings/codacy-c232-receipt-source-review.json',
            'Candidate evidence path inventory differs')
    candidate_path = bound(state['candidate'])
    candidate = read(candidate_path)
    parity = read(bound(state['parity']))
    execution = read(bound(state['execution']))
    inputs,witnesses = check_source(state,candidate,parity,execution)
    groups,foundation = check_execution(execution,inputs)
    artifacts = check_mutation_artifacts(state,inputs)
    network = closure(state_path)
    py = subprocess.check_output([PYTHON,'-I','-B','-c',
        "import sys,json;from pathlib import Path;r=Path(sys.argv[1]);p=Path(sys.argv[2]);sys.path.insert(0,str(r/'exchange_executor'));import ccxt;from ccxt_certification_evidence import validate_receipt;from ccxt_profiles import PROFILES;validate_receipt(json.loads(p.read_bytes()),'hyperliquid',ccxt.__version__,PROFILES['hyperliquid'],r/'exchange_executor',Path(ccxt.__file__).parent);print('PASS')",
        str(ROOT),str(candidate_path)],text=True).strip()
    require(py == 'PASS', 'Production Python receipt validator did not pass')
    node_script = "import fs from 'node:fs';import {compareBuildReceipt} from './scripts/verify_exchange_implementation.js';const r=compareBuildReceipt(fs.readFileSync("+json.dumps(str(candidate_path))+") ,{root:process.cwd(),exchange:'hyperliquid',profileVersion:1,approvedReceiptHashes:["+json.dumps(state['candidate']['sha256'])+"]});console.log(JSON.stringify(r));"
    comparison = parse(subprocess.check_output([NODE,'--input-type=module','-e',node_script]))
    require(comparison['buildInputsMatch'] is True and comparison['sourceTreeHash'] == inputs['sourceTreeHash']
            and all(comparison[key] is False for key in ('runtimeReceiptVerified','implementationVerified',
                    'providerAcceptanceVerified','performedGateExecution')),
            'Node comparison overclaims approval or differs from frozen inputs')
    require(sha(bytes_at(ROOT/'exchange_executor/certifications/hyperliquid.json')) == RECEIPT_SHA
            and sha(bytes_at(ROOT/'exchange_executor/ccxt_implementation_reviews.py')) == PINS_SHA,
            'Operative authority changed during independent review')
    print(json.dumps({'revision':HEAD,'sourceDeltas':1,'requirements':62,'witnesses':witnesses,
                      'terminalGreenGroups':groups,'foundationCommands':foundation,
                      'mutationArtifacts':artifacts,
                      'referenceClosure':network,'productionPythonValidation':py,
                      'productionNodeBuildInputsMatch':True,
                      'beforeContextPresent':False,'candidateApproved':False,
                      'operativeReceiptOrPinsChanged':False}))


if __name__ == '__main__':
    main()
