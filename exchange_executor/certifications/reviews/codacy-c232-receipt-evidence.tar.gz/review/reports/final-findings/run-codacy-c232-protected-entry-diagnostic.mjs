import { spawn, execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createWriteStream, existsSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { collectBuildInputs } from '../../scripts/verify_exchange_implementation.js';

const root = process.cwd();
const revision = 'c23272a3228a8e25c3604a556131b978822abe56';
const sourceTreeHash = '2e5fc760e96e35a029d632a1c2bf024c8a4448ee79a20196198b0a7b583e1c8c';
const logPath = 'reports/final-findings/codacy-c232-protected-entry-diagnostic-r2.log';
const reportPath = 'reports/final-findings/codacy-c232-protected-entry-diagnostic-r2.json';
const args = ['tests/run_all.js', 'test_trading_protected_entry_crash.js'];
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const head = () => execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim();
if (existsSync(logPath) || existsSync(reportPath)) throw Error('Diagnostic evidence already exists');
const before = collectBuildInputs(root);
const revisionBefore = head();
if (revisionBefore !== revision || before.sourceTreeHash !== sourceTreeHash || before.files.length !== 1002) {
  throw Error('Unexpected frozen source');
}
const startedAt = new Date().toISOString();
const started = process.hrtime.bigint();
const output = createWriteStream(logPath, { flags: 'wx' });
const child = spawn(process.execPath, args, { cwd: root, env: process.env,
  windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
child.stdout.pipe(output, { end: false });
child.stderr.pipe(output, { end: false });
const outcome = await new Promise(resolve => {
  child.on('error', error => resolve({ exitCode: null, signal: null, error: error.message }));
  child.on('close', (exitCode, signal) => resolve({ exitCode, signal, error: null }));
});
await new Promise(resolve => output.end(resolve));
const completedAt = new Date().toISOString();
const elapsedMs = Number((process.hrtime.bigint() - started) / 1000000n);
const after = collectBuildInputs(root);
const revisionAfter = head();
const report = { kind: 'isolated-protected-entry-diagnostic', schemaVersion: 1, revision,
  sourceTreeHash, sourceTreeHashBefore: before.sourceTreeHash,
  sourceTreeHashAfter: after.sourceTreeHash, revisionBefore, revisionAfter,
  startedAt, completedAt, elapsedMs,
  command: process.execPath, args, cwd: root, ...outcome,
  inputsUnchanged: JSON.stringify(before) === JSON.stringify(after),
  revisionUnchanged: revisionAfter === revision,
  log: { path: logPath, sha256: sha(readFileSync(logPath)) },
  providerAcceptanceVerified: false };
writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ report: reportPath, exitCode: outcome.exitCode, elapsedMs,
  inputsUnchanged: report.inputsUnchanged, revisionUnchanged: report.revisionUnchanged,
  logSha256: report.log.sha256, reportSha256: sha(readFileSync(reportPath)) }));
if (outcome.exitCode !== 0 || !report.inputsUnchanged || !report.revisionUnchanged) process.exitCode = 1;
