"""Prepare an unapproved receipt renewal for the exact c232 Codacy ledger delta.

All outputs are ignored review evidence. This helper never edits an operative
receipt, approval pin, tracked source, or a pre-existing evidence file.
"""
import argparse
import copy
import datetime
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

from receipt_renewal_safety_candidate import check_command_inventory, check_group_inventory, plain_local

ROOT = Path.cwd().resolve()
OUT = ROOT / 'reports/final-findings'
REVISION = 'c23272a3228a8e25c3604a556131b978822abe56'
PREVIOUS_REVISION = '9740c2973e1cd71e16bbf597cc22a88a12860118'
PREVIOUS_SOURCE_TREE = '9f2c35de40444d51a00d6dfbb9d1581f3ca0152e18af09ec4e63d8dadcd14b76'
CURRENT_SOURCE_TREE = '2e5fc760e96e35a029d632a1c2bf024c8a4448ee79a20196198b0a7b583e1c8c'
PREVIOUS_RECEIPT_HASH = 'eefcdd4d9af1c81482569577508b5e330ade162496073d7adb9ea7bc7e30cfc9'
PREVIOUS_AUTHORITY_HASH = '898d8dde7524cd5231f08b4ab078bbc217b121bda73d71302963b3b45127f468'
ARCHIVE_HASH = 'e726e4d83952063ed965fa83a9b946b2a3855eee213b08532d1ee0fb3e65a517'
MANIFEST_HASH = '70bdeedb4d0bc19032404b39cfd9b6a164f456115ba57ef86ecd1fe90506735b'
ARCHIVE = ROOT / 'exchange_executor/certifications/reviews/govuln9740-receipt-evidence.tar.gz'
MANIFEST = ROOT / 'exchange_executor/certifications/reviews/govuln9740-receipt-evidence-manifest.json'
NODE = 'C:/Users/nikla/AppData/Local/Programs/node22/node-v22.23.2-win-x64/node.exe'
TAG = 'codacy-c232'
BACKEND_FIRST_RETRY_TAG = 'codacy-c232-r1'
BACKEND_SELECTED_TAG = 'codacy-c232-r2'
BACKEND_SELECTION_REVIEW = OUT / 'codacy-c232-backend-attempt-selection-review.json'
ISOLATED_DIAGNOSTIC_REPORT = OUT / 'codacy-c232-protected-entry-diagnostic-r2.json'
ISOLATED_DIAGNOSTIC_LOG = OUT / 'codacy-c232-protected-entry-diagnostic-r2.log'
FAILED_BACKEND_REPORT_SHA = '9351527c03f951e400af1af3914417a9a159b20ba299afcb3e815d05cba6a6b6'
FAILED_BACKEND_LOG_SHAS = {
    'backend-coverage': '950ffeba493c7cf05208d636240eb6398396f278f317c560548f27ee7adc10c1',
    'backend-module-coverage': '6b67de70ca9548b44668cb354d1a49a56f10db1e29b1b1bb9dd9873f714d0628',
}
FAILED_BACKEND_R1_REPORT_SHA = '22afeac28d44d3140adc504e1103790061247edd166f7a7efe891ea75ffd65d5'
FAILED_BACKEND_R1_LOG_SHAS = {
    'backend-coverage': '50d8fdd9f980c793605849d07e640aba820b1dd65854c66fc7624cb53bbf2ab1',
    'backend-module-coverage': 'e6e0b8535c4dd5f6eef16487f6edbbc862a4c62e0e8e07c4cd4d2f70368fc985',
}
GROUPS = ['foundation', 'backend', 'python', 'frontend', 'build', 'browser', 'mutations', 'dependencies']
MUTATION_SOURCES = {
    'queue': ('src/queue.ts', 'node --import tsx tests/test_queue.js'),
    'retry': ('src/tdlib_retry.ts', 'node --import tsx tests/test_tdlib_retry.js'),
    'schema': ('src/signal_schema.ts', 'node --import tsx tests/test_signal_parser.js && node --import tsx tests/test_signal_contract_validation.js'),
    'trading-risk': ('src/trading_risk.ts', 'node --import tsx tests/test_trading_core.js && node --import tsx tests/test_trading_leverage_tiers.js'),
}
EXPECTED_DELTAS = {'docs/testing/final-codacy-2026-09-17.json'}
MEMBER_ROOT = 'review/reports/final-findings/'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def stamp(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key')
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))


def read(path):
    return parse(plain_local(ROOT, path).read_bytes())


def ref(path):
    p = plain_local(ROOT, path)
    return {'path': p.relative_to(ROOT).as_posix(), 'sha256': sha(p.read_bytes())}


def save(name, value):
    p = OUT / name
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    require(not p.exists() or p.read_bytes() == raw, 'Refusing to overwrite changed evidence: ' + name)
    if not p.exists():
        p.write_bytes(raw)
    return ref(p)


def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()


def current_inputs():
    script = "import {collectBuildInputs} from './scripts/verify_exchange_implementation.js';console.log(JSON.stringify(collectBuildInputs(process.cwd())));"
    return parse(subprocess.check_output([NODE, '--input-type=module', '-e', script]))


def sealed_archive():
    require(ref(ARCHIVE)['sha256'] == ARCHIVE_HASH, 'Predecessor archive hash differs')
    require(ref(MANIFEST)['sha256'] == MANIFEST_HASH, 'Predecessor manifest hash differs')
    manifest = read(MANIFEST)
    require(manifest['sourceRevision'] == PREVIOUS_REVISION and manifest['unresolvedReferences'] == [],
            'Predecessor manifest source or reference closure differs')
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        members = archive.getmembers()
        require(len(members) <= 20000 and len({m.name for m in members}) == len(members),
                'Ambiguous predecessor archive inventory')
        by_name = {m.name: m for m in members}
        manifest_bytes = archive.extractfile('manifest.json').read()
        require(parse(manifest_bytes) == manifest, 'Tracked predecessor manifest differs from archive manifest')
        require(set(by_name) == {'manifest.json'} | {entry['member'] for entry in manifest['files']},
                'Predecessor archive member inventory differs from manifest')
        for entry in manifest['files']:
            m = by_name[entry['member']]
            require(m.isfile() and not m.issym() and not m.islnk() and m.size == entry['bytes']
                    and sha(archive.extractfile(m).read()) == entry['sha256'],
                    'Predecessor archive member differs: ' + entry['member'])
        def sealed(name):
            member = MEMBER_ROOT + name
            raw = archive.extractfile(member).read()
            return parse(raw), {'archive': ref(ARCHIVE), 'member': member, 'sha256': sha(raw)}
        context, context_ref = sealed('receipt-context-govuln9740-after.json')
        parity, parity_ref = sealed('govuln9740-receipt-parity-supplement.json')
        state, state_ref = sealed('govuln9740-receipt-candidate-state.json')
        candidate, candidate_ref = sealed('govuln9740-hyperliquid-receipt-candidate.json')
    receipt = read(ROOT / 'exchange_executor/certifications/hyperliquid.json')
    require(ref(ROOT / 'exchange_executor/certifications/hyperliquid.json')['sha256'] == PREVIOUS_RECEIPT_HASH,
            'Operative receipt changed')
    require(ref(ROOT / 'exchange_executor/ccxt_implementation_reviews.py')['sha256'] == PREVIOUS_AUTHORITY_HASH,
            'Operative approval pins changed')
    require(candidate == receipt and candidate_ref['sha256'] == PREVIOUS_RECEIPT_HASH
            and state['candidate'] == {'path': 'reports/final-findings/govuln9740-hyperliquid-receipt-candidate.json', 'sha256': PREVIOUS_RECEIPT_HASH},
            'Archived candidate and operative receipt do not match')
    require(receipt['parityEvidenceHash'] == parity_ref['sha256']
            and state['parity'] == {'path': 'reports/final-findings/govuln9740-receipt-parity-supplement.json', 'sha256': parity_ref['sha256']}
            and state['execution'] == {'path': 'reports/final-findings/govuln9740-receipt-execution-supplement.json', 'sha256': receipt['executionReportHash']},
            'Archived parity and operative receipt commitments differ')
    require(context['revision'] == parity['revision'] == state['revision'] == receipt['sourceRevision'] == PREVIOUS_REVISION
            and context['inputs']['sourceTreeHash'] == receipt['sourceTreeHash'] == PREVIOUS_SOURCE_TREE
            and parity['counts']['requirements'] == 62 and parity['counts']['witnessReferences'] == 97,
            'Predecessor source or parity differs')
    return context, context_ref, parity, parity_ref, state_ref, receipt


def source_delta(context, context_ref, inputs):
    old = {r['path']: r['sha256'] for r in context['inputs']['files']}
    current = {r['path']: r['sha256'] for r in inputs['files']}
    require(len(old) == len(context['inputs']['files']) == len(current) == len(inputs['files']) == 1002,
            'Build input inventory differs')
    require(inputs['sourceTreeHash'] == CURRENT_SOURCE_TREE, 'Frozen current source tree differs')
    changes = [{'path': p, 'beforeSha256': old.get(p), 'currentSha256': current.get(p),
                'status': 'modified' if p in old and p in current else 'added' if p in current else 'removed'}
               for p in sorted(set(old) | set(current)) if old.get(p) != current.get(p)]
    require({r['path'] for r in changes} == EXPECTED_DELTAS and len(changes) == 1
            and all(r['status'] == 'modified' for r in changes), 'Expected exact one-file source delta')
    changed = set(subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', 'HEAD'], text=True).splitlines())
    require(changed == EXPECTED_DELTAS, 'Git commit does not contain exact one-file delta')
    return save('codacy-c232-receipt-source-deltas.json', {
        'revision': REVISION, 'predecessorContext': context_ref,
        'counts': {'priorInputs': len(old), 'currentInputs': len(current), 'changedAddedRemoved': len(changes)},
        'deltas': changes, 'reviewed': False, 'operativeReceiptOrPinsChanged': False,
    }), changes, old, current


def checked_group_report(group, attempt, inputs, runtime, after, passed):
    path = OUT / f'verification-{group}-{attempt}.json'
    report = read(path)
    check_command_inventory(report, ROOT, NODE)
    require(report['kind'] == 'observed-final-offline-verification' and report['schemaVersion'] == 1
            and report['group'] == group and report['attempt'] == attempt
            and report['revision'] == REVISION and report['inputsBefore'] == inputs
            and report['providerAcceptanceVerified'] is False,
            'Group source/identity differs: ' + group + '/' + attempt)
    require(report.get('completedAt') and report.get('revisionAfter') == REVISION
            and report.get('inputsAfter') == inputs and report.get('observedInputsUnchanged') is True
            and report.get('allCommandsPassed') is passed,
            'Group not terminal, stable or at expected result: ' + group + '/' + attempt)
    require(report['commands'] and all(type(c['exitCode']) is int
            and c.get('signal') is None and not c.get('error') for c in report['commands']),
            'A command has incomplete exit evidence: ' + group + '/' + attempt)
    require(stamp(report['startedAt']) <= stamp(report['completedAt']), 'Group timestamp differs')
    if runtime is not None:
        require(report['runtime']['node'] == runtime['node'] and report['runtime']['ccxt'] == runtime['ccxt']
                and report['runtime']['python'] == 'Python ' + runtime['python'].split()[0],
                'Group runtime differs: ' + group + '/' + attempt)
    if after is not None:
        require(stamp(report['completedAt']) <= stamp(after['startedAt']),
                'Group ended after final context: ' + group + '/' + attempt)
    bindings = []
    log_text = {}
    for command in report['commands']:
        require(command['log'] == f"reports/final-findings/verification-{command['name']}-{attempt}.log",
                'Command log attempt mismatch')
        lp = ROOT / command['log']
        binding = ref(lp)
        require(binding['sha256'] == command['logSha256'], 'Command log bytes changed')
        require(stamp(report['startedAt']) <= stamp(command['startedAt']) <= stamp(command['completedAt'])
                <= stamp(report['completedAt']), 'Command outside group time window')
        log_text[command['name']] = lp.read_text(encoding='utf-8-sig')
        bindings.append(binding)
    return report, ref(path), bindings, log_text


def reviewed_backend_retry(inputs, runtime, after, review_path):
    original, original_ref, original_logs, original_text = checked_group_report(
        'backend', TAG, inputs, runtime, after, False)
    require(original_ref['sha256'] == FAILED_BACKEND_REPORT_SHA
            and [c['exitCode'] for c in original['commands']] == [0, 1]
            and {c['name']: b['sha256'] for c, b in zip(original['commands'], original_logs)}
            == FAILED_BACKEND_LOG_SHAS
            and original_text['backend-module-coverage'].count('Error: Test timed out in 5000ms.') == 3,
            'Original failed backend attempt differs from observed evidence')
    first_retry, first_retry_ref, first_retry_logs, first_retry_text = checked_group_report(
        'backend', BACKEND_FIRST_RETRY_TAG, inputs, runtime, after, False)
    require(first_retry_ref['sha256'] == FAILED_BACKEND_R1_REPORT_SHA
            and [c['exitCode'] for c in first_retry['commands']] == [1, 0]
            and {c['name']: b['sha256'] for c, b in zip(first_retry['commands'], first_retry_logs)}
            == FAILED_BACKEND_R1_LOG_SHAS
            and 'test_trading_protected_entry_crash.js failed with signal SIGTERM.'
            in first_retry_text['backend-coverage']
            and 'ALL 229 TEST FILES PASSED!' in first_retry_text['backend-module-coverage']
            and stamp(original['completedAt']) <= stamp(first_retry['startedAt']),
            'First backend retry differs from complete observed failure')
    require(review_path is not None and plain_local(ROOT, review_path) == BACKEND_SELECTION_REVIEW,
            'Explicit root backend selection review required at fixed path')
    selected, selected_ref, selected_logs, selected_text = checked_group_report(
        'backend', BACKEND_SELECTED_TAG, inputs, runtime, after, True)
    require(all(c['exitCode'] == 0 for c in selected['commands'])
            and stamp(first_retry['completedAt']) <= stamp(selected['startedAt']),
            'Selected backend r2 is incomplete, failed or predates first retry')
    review = read(review_path)
    require(set(review) == {'revision', 'group', 'sourceTreeHash', 'originalAttempt', 'firstRetryAttempt',
            'selectedAttempt', 'originalReport', 'originalLogs', 'firstRetryReport', 'firstRetryLogs',
            'selectedReport', 'selectedLogs', 'isolatedDiagnostic', 'reviewed', 'reviewedAt',
            'originalFailureAssessment', 'firstRetryFailureAssessment', 'selectionAssessment',
            'providerAcceptanceVerified', 'operativeReceiptApproved'}
            and review['revision'] == REVISION and review['group'] == 'backend'
            and review['sourceTreeHash'] == inputs['sourceTreeHash']
            and review['originalAttempt'] == TAG
            and review['firstRetryAttempt'] == BACKEND_FIRST_RETRY_TAG
            and review['selectedAttempt'] == BACKEND_SELECTED_TAG
            and review['originalReport'] == original_ref and review['originalLogs'] == original_logs
            and review['firstRetryReport'] == first_retry_ref and review['firstRetryLogs'] == first_retry_logs
            and review['selectedReport'] == selected_ref and review['selectedLogs'] == selected_logs
            and review['isolatedDiagnostic'] == ref(ISOLATED_DIAGNOSTIC_REPORT)
            and review['reviewed'] is True and review['providerAcceptanceVerified'] is False
            and review['operativeReceiptApproved'] is False
            and all(isinstance(review[key], str) and review[key].strip() for key in (
                'originalFailureAssessment', 'firstRetryFailureAssessment', 'selectionAssessment'))
            and stamp(review['reviewedAt']) >= stamp(selected['completedAt']),
            'Root backend selection review is missing, incomplete or not bound to all three full attempts')
    diagnostic = read(ISOLATED_DIAGNOSTIC_REPORT)
    require(diagnostic['kind'] == 'isolated-protected-entry-diagnostic'
            and diagnostic['schemaVersion'] == 1
            and diagnostic['revision'] == REVISION
            and diagnostic['sourceTreeHash'] == inputs['sourceTreeHash']
            and Path(diagnostic['command']).resolve() == Path(NODE).resolve()
            and diagnostic['args'] == ['tests/run_all.js', 'test_trading_protected_entry_crash.js']
            and diagnostic['cwd'] == str(ROOT)
            and type(diagnostic['exitCode']) is int and diagnostic['exitCode'] == 0
            and diagnostic['signal'] is None and diagnostic['error'] is None
            and type(diagnostic['elapsedMs']) is int and 0 < diagnostic['elapsedMs'] < 120_000
            and diagnostic['inputsUnchanged'] is True and diagnostic['revisionUnchanged'] is True
            and diagnostic['providerAcceptanceVerified'] is False
            and stamp(first_retry['completedAt']) <= stamp(selected['completedAt'])
            <= stamp(diagnostic['startedAt']) <= stamp(diagnostic['completedAt'])
            <= stamp(review['reviewedAt']),
            'Isolated diagnostic is not a passing, source-stable post-r2 pinned-node run')
    diagnostic_log_ref = ref(ISOLATED_DIAGNOSTIC_LOG)
    diagnostic_text = ISOLATED_DIAGNOSTIC_LOG.read_text(encoding='utf-8-sig')
    require(diagnostic['log'] == diagnostic_log_ref
            and 'Protected-entry hard process crashes preserve journal phases, original intent and conservative runtime recovery.'
            in diagnostic_text and 'ALL 1 TEST FILES PASSED!' in diagnostic_text,
            'Isolated diagnostic log identity, hash or success markers differ')
    entry = {'group': 'backend', 'report': selected_ref, 'logs': selected_logs,
             'freshAtFrozenRevision': True, 'originalAllCommandsPassed': False,
             'reviewedReplacements': [{'report': selected_ref, 'logs': selected_logs,
                                       'selectionReview': ref(review_path)}],
             'preservedEarlierAttempts': [{'report': original_ref, 'logs': original_logs,
                                           'allCommandsPassed': False, 'exitCodes': [0, 1],
                                           'failure': 'Three Vitest tests timed out at 5000 ms in backend-module-coverage'},
                                          {'report': first_retry_ref, 'logs': first_retry_logs,
                                           'allCommandsPassed': False, 'exitCodes': [1, 0],
                                           'failure': 'Protected-entry test received scheduler SIGTERM at 120 seconds in backend-coverage'}],
             'attemptSelection': ref(review_path)}
    return entry, selected_text


def check_group_reports(inputs, runtime=None, after=None, backend_selection_review=None):
    reports = []
    logs = {}
    for group in GROUPS:
        if group == 'backend':
            entry, group_logs = reviewed_backend_retry(inputs, runtime, after, backend_selection_review)
            reports.append(entry)
            logs.update(group_logs)
            continue
        report, report_ref, bindings, group_logs = checked_group_report(
            group, TAG, inputs, runtime, after, True)
        require(all(c['exitCode'] == 0 for c in report['commands']), 'A command in group failed: ' + group)
        logs.update(group_logs)
        if group == 'foundation':
            mon = report['monitoringExecution']
            require(mon['mode'] == 'native-configuration-only' and mon['containerAcceptanceVerified'] is False
                    and [t['key'] for t in mon['tools']] == ['PROMTOOL_PATH', 'AMTOOL_PATH'],
                    'Native monitoring execution context differs')
            for tool in mon['tools']:
                require(sha(Path(tool['executable']).read_bytes()) == tool['sha256'] and tool['version'].strip(),
                        'Native monitoring tool bytes differ')
        reports.append({'group': group, 'report': report_ref, 'logs': bindings,
                        'freshAtFrozenRevision': True, 'originalAllCommandsPassed': True,
                        'reviewedReplacements': [], 'preservedEarlierAttempts': [], 'attemptSelection': None})
    check_group_inventory(reports)
    python_count = re.search(r'^Ran (\d+) tests? in ', logs['python-coverage'], re.M)
    frontend_count = re.search(r'Tests\s+(\d+) passed', logs['frontend-coverage'])
    frontend_files = re.search(r'Test Files\s+(\d+) passed', logs['frontend-coverage'])
    backend_files = re.search(r'ALL (\d+) TEST FILES PASSED', logs['backend-module-coverage'])
    require(python_count and re.search(r'^OK\s*$', logs['python-coverage'], re.M)
            and frontend_count and frontend_files and backend_files
            and 'Module coverage ratchet passed.' in logs['backend-module-coverage'],
            'Test suite summaries missing')
    counts = {'pythonTests': int(python_count[1]), 'frontendTests': int(frontend_count[1]),
              'frontendFiles': int(frontend_files[1]), 'backendModuleTestFiles': int(backend_files[1])}
    return reports, counts


def check_review(path, delta_ref, changes):
    require(path is not None, 'Candidate requires independently completed one-file source review')
    value = read(path)
    require(value['revision'] == REVISION and value['deltas'] == delta_ref
            and value['reviewed'] is True and value['providerAcceptanceVerified'] is False,
            'Root source review revision, delta or status differs')
    rows = {r['path']: r for r in value['reviews']}
    require(len(rows) == len(value['reviews']) == len(changes) and set(rows) == EXPECTED_DELTAS,
            'Incomplete source review')
    for change in changes:
        row = rows[change['path']]
        require(all(row[k] == change[k] for k in ('beforeSha256', 'currentSha256', 'status'))
                and row['reviewed'] is True and row['rationale'].strip() and row['evidence'],
                'Unreviewed changed source: ' + change['path'])
        for binding in row['evidence']:
            require(ref(ROOT / binding['path']) == binding, 'Source review evidence differs')
    return ref(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['inventory', 'candidate'], required=True)
    parser.add_argument('--source-review', type=Path)
    parser.add_argument('--backend-selection-review', type=Path)
    args = parser.parse_args()
    require(head() == REVISION, 'Frozen Codacy ledger HEAD changed')
    require(not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], text=True).strip(),
            'Tracked working tree changed')
    context, context_ref, parity, parity_ref, state_ref, prior = sealed_archive()
    inputs = current_inputs()
    delta_ref, changes, old, current = source_delta(context, context_ref, inputs)
    witness_keys = {(row['category'], row['check']) for row in parity['rows']}
    witness_bindings = [w for row in parity['rows'] for w in row['witnessBindings']]
    require(len(witness_keys) == len(parity['rows']) == 62 and len(witness_bindings) == 97
            and len({w['path'] for w in witness_bindings}) == 30
            and all(old[w['path']] == current[w['path']] == w['sha256'] for w in witness_bindings),
            'One of 97 sealed witness path/hash bindings changed')
    if args.mode == 'inventory':
        draft = {'revision': REVISION, 'deltas': delta_ref, 'reviewed': False,
                 'providerAcceptanceVerified': False,
                 'reviews': [{**c, 'reviewed': False, 'rationale': '', 'evidence': []} for c in changes]}
        draft_ref = save('codacy-c232-receipt-source-review-draft.json', draft)
        print(json.dumps({'delta': delta_ref, 'draft': draft_ref, 'changedInputs': len(changes),
                          'sealedWitnessesUnchanged': 97, 'candidateCreated': False}))
        return
    review_ref = check_review(args.source_review, delta_ref, changes)
    progress_path = OUT / 'receipt-context-codacy-c232-progress.json'
    after_path = OUT / 'receipt-context-codacy-c232-after.json'
    progress = read(progress_path)
    after = read(after_path)
    require(all(c['revision'] == REVISION and c['inputs'] == inputs
                and c['rawEqualsGit'] and c['allInputsSingleLink'] and c['sourceStableDuringCapture']
                for c in (progress, after))
            and progress['runtime'] == after['runtime']
            and stamp(progress['observedAt']) <= stamp(after['startedAt']),
            'Intermediate/final contexts do not prove exact stable Git inputs and runtime')
    groups, suite_counts = check_group_reports(inputs, after['runtime'], after,
                                               args.backend_selection_review)
    mutation = read(OUT / f'verification-mutations-{TAG}.json')
    require(stamp(mutation['startedAt']) <= stamp(progress['startedAt'])
            <= stamp(progress['observedAt']) <= stamp(mutation['completedAt']),
            'Intermediate context was not captured during the mutation group')
    mutation_artifacts = []
    artifact_dir = OUT / 'mutation-artifacts-codacy-c232'
    artifact_dir.mkdir(exist_ok=True)
    require(len(mutation['commands']) == 1 and mutation['commands'][0]['name'] == 'mutations',
            'Exact mutation command missing')
    mutation_command = mutation['commands'][0]
    mutation_log = (OUT / f'verification-mutations-{TAG}.log').read_text(encoding='utf-8-sig')
    source_hashes = {r['path']: r['sha256'] for r in inputs['files']}
    last_mtime = None
    for shard in ('queue', 'retry', 'schema', 'trading-risk'):
        source = ROOT / 'reports/mutation' / f'{shard}.json'
        source = plain_local(ROOT, source)
        original = source.read_bytes()
        data = parse(original)
        mutate_path, expected_command = MUTATION_SOURCES[shard]
        config = data['config']
        require(data['schemaVersion'] == '1.0'
                and data['projectRoot'] == str(ROOT)
                and list(data['files']) == [mutate_path]
                and config['mutate'] == [mutate_path]
                and config['jsonReporter']['fileName'] == f'reports/mutation/{shard}.json'
                and config['testRunner'] == 'command'
                and config['commandRunner']['command'] == expected_command
                and config['coverageAnalysis'] == 'off'
                and config['incremental'] is False
                and config['force'] is True
                and data['thresholds'] == config['thresholds']
                == {'high': 80, 'low': 70, 'break': 70},
                'Mutation configuration differs: ' + shard)
        file_data = data['files'][mutate_path]
        require(file_data['source'].encode('utf-8') == plain_local(ROOT, mutate_path).read_bytes()
                and sha(file_data['source'].encode('utf-8')) == source_hashes[mutate_path],
                'Mutation input source differs from frozen Git: ' + shard)
        mutants = file_data['mutants']
        ids = [m['id'] for m in mutants]
        require(mutants and len(ids) == len(set(ids)), 'Missing or duplicate mutant identities: ' + shard)
        statuses = [m['status'] for m in mutants]
        require(set(statuses) <= {'Killed', 'Timeout', 'Survived'},
                'Unreviewed mutation status affects score: ' + shard)
        mutant_counts = {status: statuses.count(status) for status in ('Killed', 'Timeout', 'Survived')}
        score = Decimal(100) * Decimal(mutant_counts['Killed'] + mutant_counts['Timeout']) / Decimal(len(mutants))
        score_text = str(score.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))
        require(score >= Decimal(70), 'Mutation score below exact break threshold: ' + shard)
        marker = f'=== Mutation shard: {shard} ==='
        require(mutation_log.count(marker) == 1, 'Mutation shard log marker differs: ' + shard)
        section = mutation_log.split(marker, 1)[1].split('=== Mutation shard:', 1)[0]
        logged_score = re.findall(r'Final mutation score of ([0-9]+\.[0-9]+) is greater than or equal to break threshold 70', section)
        instrumented = re.findall(r'Instrumented 1 source file\(s\) with (\d+) mutant\(s\)', section)
        require(logged_score == [score_text] and instrumented == [str(len(mutants))],
                'Mutation JSON score/count differs from current run log: ' + shard)
        mtime_ns = source.stat().st_mtime_ns
        mtime = datetime.datetime.fromtimestamp(mtime_ns / 1_000_000_000, datetime.timezone.utc)
        require(stamp(mutation_command['startedAt']) <= mtime <= stamp(mutation_command['completedAt'])
                and (last_mtime is None or mtime_ns > last_mtime),
                'Mutation JSON not written in ordered current command window: ' + shard)
        last_mtime = mtime_ns
        copy_path = artifact_dir / f'{shard}.json'
        require(not copy_path.exists() or copy_path.read_bytes() == original,
                'Refusing to overwrite changed mutation artifact: ' + shard)
        if not copy_path.exists():
            copy_path.write_bytes(original)
        mutation_artifacts.append({'shard': shard, 'selectedCurrentRun': ref(copy_path),
                                   'sourcePath': source.relative_to(ROOT).as_posix(),
                                   'sourceSha256AtCapture': sha(original),
                                   'sourceMtimeNs': mtime_ns,
                                   'mutantCounts': mutant_counts, 'mutationScorePercent': score_text})
    execution_ref = save('codacy-c232-receipt-execution-supplement.json', {
        'revision': REVISION, 'progressContext': ref(progress_path),
        'afterContext': ref(after_path), 'runtime': after['runtime'],
        'groups': groups, 'observedCounts': suite_counts, 'pythonExecutionInheritance': False,
        'beforeContextPresent': False,
        'sourceProof': 'Eight selected passing reports bind identical pre/post inputs to the exact Git revision. Both complete failed backend attempts remain hash-bound, as does the isolated passing diagnostic; only an independently reviewed complete passing r2 backend rerun can be selected. Independent raw-to-Git contexts were captured during mutation and after the selected groups. No pre-test context snapshot was captured.',
        'providerAcceptanceVerified': False, 'operativeReceiptApproved': False})
    category_review = ('All 97 original witness path/hash bindings are unchanged from the sealed '
                       'govuln9740 parity. The one changed build input is the historical Codacy '
                       'review ledger, independently reviewed for its three source renewals. The '
                       'current eight-group terminal execution is separately bound; no provider '
                       'or live-trading acceptance is claimed.')
    rows = []
    for previous in parity['rows']:
        bindings = [{'path': w['path'], 'sha256': current[w['path']]}
                    for w in previous['witnessBindings']]
        rows.append({'category': previous['category'], 'check': previous['check'],
                     'witnessBindings': bindings,
                     'sealedPriorRow': {'evidence': parity_ref,
                                        'lookup': {'category': previous['category'], 'check': previous['check']}},
                     'completeSourceReview': review_ref, 'currentExecution': execution_ref,
                     'currentDeltaAssessment': category_review,
                     'supplementalCurrentEvidence': [],
                     'scope': 'Offline implementation requirement; no provider execution or scope expansion.'})
    parity_new = save('codacy-c232-receipt-parity-supplement.json', {
        'revision': REVISION, 'priorParity': parity_ref,
        'counts': {'requirements': 62, 'witnessReferences': 97,
                   'changedWitnessReferences': 0, 'unchangedWitnessReferences': 97},
        'method': 'Exact original 62 requirement identities and all 97 witness path/hash pairs remain sealed and unchanged; the single changed non-witness Codacy ledger receives separate source review and fresh eight-group execution.',
        'rows': rows, 'providerAcceptanceVerified': False, 'operativeReceiptApproved': False})
    candidate = copy.deepcopy(prior)
    for key in ('sourceTreeHash', 'nodeSourcesHash', 'testSourcesHash', 'fixturesHash'):
        candidate[key] = inputs[key]
    for key in ('executorTreeHash', 'sdkTreeHash', 'profileHash'):
        candidate[key] = after['runtime'][key]
    candidate.update({'sourceRevision': REVISION, 'parityEvidenceHash': parity_new['sha256'],
                      'executionReportHash': execution_ref['sha256'],
                      'reviewedAt': datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')})
    sys.path.insert(0, str(ROOT / 'exchange_executor'))
    import ccxt
    from ccxt_certification_evidence import validate_receipt
    from ccxt_profiles import PROFILES
    validate_receipt(candidate, 'hyperliquid', ccxt.__version__, PROFILES['hyperliquid'],
                     ROOT / 'exchange_executor', Path(ccxt.__file__).parent)
    require(all(candidate[key] == prior[key] for key in ('schemaVersion', 'kind', 'exchange',
            'ccxtVersion', 'profileVersion', 'profileHash', 'scope', 'providerAcceptanceVerified')),
            'Receipt scope or identity changed')
    candidate_ref = save('codacy-c232-hyperliquid-receipt-candidate.json', candidate)
    state_ref = save('codacy-c232-receipt-candidate-state.json', {
        'revision': REVISION, 'candidate': candidate_ref, 'execution': execution_ref,
        'parity': parity_new, 'completeSourceReview': review_ref,
        'predecessorReceiptState': state_ref, 'predecessorArchive': ref(ARCHIVE),
        'mutationArtifacts': mutation_artifacts,
        'reproducibilityHelpers': [ref(OUT / p) for p in (
             'prepare-codacy-c232-receipt.py', 'collect-receipt-context.mjs',
             'receipt-runtime-snapshot.py', 'run-verification.mjs',
             'receipt_renewal_safety_candidate.py')],
        'operativeReceiptOrPinsChanged': False, 'operativeReceiptApproved': False,
        'remaining': ['Independent source, execution and reference-closure review',
                      'Deterministic evidence archive', 'Explicit bounded root adoption',
                      'Real post-adoption implementation gate and bridge regressions',
                      'Container and remote scanner checks']})
    print(json.dumps({'candidate': candidate_ref, 'state': state_ref,
                      'operativeReceiptOrPinsChanged': False, 'providerAcceptanceVerified': False}))


if __name__ == '__main__':
    main()
