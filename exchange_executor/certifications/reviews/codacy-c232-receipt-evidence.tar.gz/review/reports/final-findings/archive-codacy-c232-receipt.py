"""Deterministically seal a separately reviewed Codacy c232 receipt candidate.

Requires a completed candidate, a frozen independent validator review, and
explicit root approval for archiving only. Never installs a receipt or pin.
"""
import argparse
import datetime
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile

from receipt_renewal_safety_candidate import plain_local

ROOT = Path.cwd().resolve()
OUT = ROOT / 'reports/final-findings'
REVISION = 'c23272a3228a8e25c3604a556131b978822abe56'
SOURCE_REVIEW_HASH = '82aeb1226f906b741ceb06ac1e0c67050ccb11da05e19a6b7e6f96b6008c456e'
PREVIOUS_RECEIPT_HASH = 'eefcdd4d9af1c81482569577508b5e330ade162496073d7adb9ea7bc7e30cfc9'
PREVIOUS_PINS_HASH = '898d8dde7524cd5231f08b4ab078bbc217b121bda73d71302963b3b45127f468'
SOURCE_REVIEW = OUT/'codacy-c232-receipt-source-review.json'
STATE = OUT/'codacy-c232-receipt-candidate-state.json'
VALIDATOR = OUT/'validate-codacy-c232-candidate.py'
INDEPENDENT_REVIEW = OUT/'codacy-c232-independent-receipt-review-v2.json'
ARCHIVE_APPROVAL = OUT/'codacy-c232-receipt-archive-approval.json'
ARCHIVE = OUT/'codacy-c232-receipt-evidence.tar.gz'
MANIFEST = OUT/'codacy-c232-receipt-evidence-manifest.json'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def safe(path):
    return plain_local(ROOT, path)


def unique(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, 'Duplicate JSON key')
        value[key] = item
    return value


def parse(raw):
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))


def read(path):
    return parse(safe(path).read_bytes())


def ref(path):
    p = safe(path)
    return {'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p.read_bytes())}


def stamp(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))


def check_authority():
    require(sha(safe(ROOT/'exchange_executor/certifications/hyperliquid.json').read_bytes()) == PREVIOUS_RECEIPT_HASH,
            'Operative receipt changed')
    require(sha(safe(ROOT/'exchange_executor/ccxt_implementation_reviews.py').read_bytes()) == PREVIOUS_PINS_HASH,
            'Operative approval pins changed')
    require(subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == REVISION,
            'Frozen source revision changed')
    require(not subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).strip(),
            'Tracked working tree changed')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--review', required=True, type=Path)
    parser.add_argument('--approval', required=True, type=Path)
    parser.add_argument('--validator-sha256', required=True)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    check_authority()
    require(args.validator_sha256 == args.validator_sha256.lower()
            and len(args.validator_sha256) == 64
            and all(c in '0123456789abcdef' for c in args.validator_sha256),
            'Explicit validator SHA-256 must be lowercase hexadecimal')
    validator_path = VALIDATOR
    require(ref(validator_path)['sha256'] == args.validator_sha256,
            'Independent validator hash changed')
    source_path = SOURCE_REVIEW
    require(ref(source_path)['sha256'] == SOURCE_REVIEW_HASH,
            'Complete c232 source review changed')
    state_path = STATE
    state = read(state_path)
    require(state['revision'] == REVISION and state['completeSourceReview'] == ref(source_path)
            and state['candidate']['path'] == 'reports/final-findings/codacy-c232-hyperliquid-receipt-candidate.json'
            and state['execution']['path'] == 'reports/final-findings/codacy-c232-receipt-execution-supplement.json'
            and state['parity']['path'] == 'reports/final-findings/codacy-c232-receipt-parity-supplement.json'
            and state['operativeReceiptApproved'] is False
            and state['operativeReceiptOrPinsChanged'] is False,
            'Candidate state is not the unadopted reviewed revision')
    require(safe(args.review) == INDEPENDENT_REVIEW and safe(args.approval) == ARCHIVE_APPROVAL,
            'Review and archive-only approval must use fixed ignored paths')
    review = read(args.review)
    approval = read(args.approval)
    require(set(review) == {'schemaVersion','revision','candidate','candidateState',
            'completeSourceReview','reviewValidator','reviewedAt','reviewer',
            'validatorResult','referenceClosure','reviewNotes','providerAcceptanceVerified',
            'operativeReceiptApproved','operativeReceiptOrPinsChanged'}
            and review['schemaVersion'] == 1 and review['revision'] == REVISION
            and review['candidate'] == state['candidate']
            and review['candidateState'] == ref(state_path)
            and review['completeSourceReview'] == state['completeSourceReview']
            and review['reviewValidator'] == ref(validator_path)
            and isinstance(review['reviewer'],str) and review['reviewer'].strip()
            and isinstance(review['reviewNotes'],list) and len(review['reviewNotes']) >= 2
            and all(isinstance(note,str) and note.strip() for note in review['reviewNotes'])
            and review['providerAcceptanceVerified'] is False
            and review['operativeReceiptApproved'] is False
            and review['operativeReceiptOrPinsChanged'] is False,
            'Independent review does not bind the exact unadopted candidate and validator')
    require(set(approval) == {'schemaVersion','revision','candidate','candidateState',
            'completeSourceReview','independentReview','reviewValidator','approved',
            'reviewer','approvedAt','scope','rootChecks','archiveOnly',
            'providerAcceptanceVerified','operativeReceiptApproved','operativeReceiptOrPinsChanged'}
            and approval['schemaVersion'] == 1 and approval['revision'] == REVISION
            and approval['candidate'] == state['candidate']
            and approval['candidateState'] == ref(state_path)
            and approval['completeSourceReview'] == state['completeSourceReview']
            and approval['independentReview'] == ref(args.review)
            and approval['reviewValidator'] == ref(validator_path)
            and approval['approved'] is True and approval['archiveOnly'] is True
            and approval['reviewer'] == 'root'
            and stamp(review['reviewedAt']) <= stamp(approval['approvedAt'])
            and isinstance(approval['scope'],str) and len(approval['scope'].strip()) >= 80
            and 'archiv' in approval['scope'].lower()
            and isinstance(approval['rootChecks'],list) and len(approval['rootChecks']) >= 4
            and all(isinstance(value,str) and value.strip() for value in approval['rootChecks'])
            and approval['providerAcceptanceVerified'] is False
            and approval['operativeReceiptApproved'] is False
            and approval['operativeReceiptOrPinsChanged'] is False,
            'Explicit bounded root archive-only approval missing')
    independent = subprocess.check_output([
        str(ROOT.parent/'tsx-security-python-env/Scripts/python.exe'),
        '-E','-s','-B',str(validator_path),'--state',str(state_path)],
        cwd=ROOT,text=True)
    observed = parse(independent.encode())
    require(observed['revision'] == REVISION and observed['sourceDeltas'] == 1
            and observed['requirements'] == 62 and observed['witnesses'] == 97
            and observed['terminalGreenGroups'] == 8
            and observed['foundationCommands'] == 14
            and observed['mutationArtifacts'] == 4
            and observed['referenceClosure']['unresolvedReferences'] == 0
            and observed['productionPythonValidation'] == 'PASS'
            and observed['productionNodeBuildInputsMatch'] is True
            and observed['beforeContextPresent'] is False
            and observed['candidateApproved'] is False
            and observed['operativeReceiptOrPinsChanged'] is False
            and review['validatorResult'] == observed
            and review['referenceClosure'] == observed['referenceClosure'],
            'Fresh independent validation failed or overclaimed authority')
    spec = importlib.util.spec_from_file_location('codacy_c232_validator',validator_path)
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    closure_before = validator.closure(state_path)
    require(closure_before == review['referenceClosure'],
            'Reference graph changed since independent review')
    queue = [state_path, safe(args.review), safe(args.approval),
             Path(__file__).resolve(), validator_path,
             OUT/'receipt_renewal_safety_candidate.py',
             OUT/'run-codacy-c232-protected-entry-diagnostic.mjs']
    included = {}
    references = {}
    inherited = {}

    def walk(value):
        if isinstance(value,list):
            for child in value: walk(child)
        elif isinstance(value,dict):
            if isinstance(value.get('archive'),dict) and isinstance(value.get('member'),str):
                archive = safe(value['archive']['path'])
                require(ref(archive) == value['archive'], 'Historical archive changed')
                member = value['member']
                require(not member.startswith('/') and '..' not in Path(member).parts
                        and '\\' not in member, 'Unsafe historical member')
                with tarfile.open(archive,'r:*') as handle:
                    items = handle.getmembers()
                    require(len(items) <= 20000 and len({m.name for m in items}) == len(items),
                            'Ambiguous historical archive')
                    item = handle.getmember(member)
                    require(item.isfile() and not item.issym() and not item.islnk()
                            and sha(handle.extractfile(item).read()) == value['sha256'],
                            'Historical archive member changed')
                inherited[value['archive']['path']+':'+member] = value
                if archive.is_relative_to(OUT): queue.append(archive)
                return
            if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
                target = safe(value['path'])
                expected_path = str(target) if Path(value['path']).is_absolute() else target.relative_to(ROOT).as_posix()
                require(value['path'] == expected_path and sha(target.read_bytes()) == value['sha256'],
                        'Current reference changed')
                relative = target.relative_to(ROOT).as_posix()
                normalized = {'path':relative,'sha256':value['sha256']}
                if Path(value['path']).is_absolute():
                    normalized['originalBindingPath'] = value['path']
                references[value['path']] = normalized
                if target.is_relative_to(OUT): queue.append(target)
            if isinstance(value.get('log'),str) and isinstance(value.get('logSha256'),str):
                walk({'path':value['log'],'sha256':value['logSha256']})
            for child in value.values(): walk(child)

    while queue:
        path = safe(queue.pop())
        require(path.is_relative_to(OUT), 'Only ignored review evidence may be archived')
        relative = path.relative_to(ROOT).as_posix()
        if relative in included: continue
        require(len(included) < 20000 and path.stat().st_size <= 256*1024*1024,
                'Evidence archive budget exceeded')
        raw = path.read_bytes()
        included[relative] = raw
        if path.suffix == '.json': walk(parse(raw))

    manifest = {'schemaVersion':1,'sourceRevision':REVISION,
        'scope':'Unadopted offline Codacy c232 receipt candidate, independent review, two preserved failed backend attempts, selected r2 execution and exact source review; sealed govuln9740 archive retains predecessor context.',
        'files':[{'path':name,'member':'review/'+name,'sha256':sha(raw),'bytes':len(raw)}
                 for name,raw in sorted(included.items())],
        'verifiedCurrentReferences':[references[name] for name in sorted(references)],
        'inheritedExactReferences':[inherited[name] for name in sorted(inherited)],
        'unresolvedReferences':[],'providerAcceptanceVerified':False,
        'operativeReceiptOrPinsChanged':False}
    manifest_raw = (json.dumps(manifest,indent=2)+'\n').encode()
    payload = {'manifest.json':manifest_raw,
               **{'review/'+name:raw for name,raw in sorted(included.items())}}

    def pack():
        plain = io.BytesIO()
        with tarfile.open(fileobj=plain,mode='w',format=tarfile.PAX_FORMAT) as archive:
            for name,raw in payload.items():
                item = tarfile.TarInfo(name)
                item.size,item.mode = len(raw),0o444
                item.uid = item.gid = item.mtime = 0
                item.uname = item.gname = ''
                archive.addfile(item,io.BytesIO(raw))
        compressed = io.BytesIO()
        with gzip.GzipFile(filename='',fileobj=compressed,mode='wb',mtime=0,compresslevel=9) as stream:
            stream.write(plain.getvalue())
        return compressed.getvalue()

    raw = pack()
    require(raw == pack(), 'Evidence archive not reproducible byte-for-byte')
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
        require(len(archive.getmembers()) == len(payload), 'Archive inventory differs')
        for item in archive.getmembers():
            require(item.isfile() and item.mtime == 0
                    and archive.extractfile(item).read() == payload[item.name],
                    'Archive member read-back differs')
    for name,content in included.items():
        require(safe(name).read_bytes() == content, 'Current evidence changed during archiving')
    for item in references.values():
        target = safe(item['path'])
        original = item.get('originalBindingPath',item['path'])
        expected_path = str(target) if Path(original).is_absolute() else target.relative_to(ROOT).as_posix()
        require(original == expected_path and item['path'] == target.relative_to(ROOT).as_posix()
                and sha(target.read_bytes()) == item['sha256'],
                'Current reference changed during archiving')
    check_authority()
    require(validator.closure(state_path) == closure_before,
            'Reference graph changed during archiving')
    if args.dry_run:
        print(json.dumps({'dryRun':True,'wouldArchiveSha256':sha(raw),'files':len(included),
                          'everyMemberReadBack':True,'doubleBuildByteIdentical':True,
                          'archiveCreated':False,'operativeReceiptOrPinsChanged':False}))
        return
    archive_path = ARCHIVE
    manifest_path = MANIFEST
    require(not archive_path.exists() and not manifest_path.exists(),
            'Refusing to overwrite an existing receipt archive')
    with archive_path.open('xb') as stream: stream.write(raw)
    with manifest_path.open('xb') as stream: stream.write(manifest_raw)
    print(json.dumps({'archive':archive_path.relative_to(ROOT).as_posix(),
                      'sha256':sha(raw),'manifest':manifest_path.relative_to(ROOT).as_posix(),
                      'manifestSha256':sha(manifest_raw),'files':len(included),
                      'unresolvedReferences':0,'operativeReceiptOrPinsChanged':False}))


if __name__ == '__main__':
    main()
