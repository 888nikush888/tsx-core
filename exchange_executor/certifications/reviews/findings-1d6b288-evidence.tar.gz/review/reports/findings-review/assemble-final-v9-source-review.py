"""Bind 314 unchanged sealed reviews and two independently reviewed async return deltas."""
from pathlib import Path
import argparse, json, hashlib, subprocess, tarfile, copy, re

R = Path('reports/findings-review')
sha = lambda b: hashlib.sha256(b).hexdigest()
ref = lambda p: {'path': p.as_posix(), 'sha256': sha(p.read_bytes())}
parser = argparse.ArgumentParser()
parser.add_argument('--revision', required=True)
args = parser.parse_args()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert re.fullmatch(r'[a-f0-9]{40}', args.revision) and revision == args.revision
archive = Path('exchange_executor/certifications/reviews/findings-37c8d6f-evidence.tar.gz')
assert sha(archive.read_bytes()) == 'f6f770ccaabff380a8199b0ac77e15bb946a793984c1c9ec678838933f1cdf82'
member = 'review/reports/findings-review/final-v8-receipt-source-review.json'
with tarfile.open(archive) as handle:
    members = {entry.name: handle.extractfile(entry).read() for entry in handle.getmembers() if entry.isfile()}
raw = members[member]
assert sha(raw) == '1cc06c369daf1e9fe78e04eb063344808ec98882ae21dd748c1331aa09ecbee8'
prior_binding = {'archive': ref(archive), 'member': member, 'sha256': sha(raw)}
base = json.loads(raw)
old = {row['path']: row for row in base['reviews']}
assert len(old) == len(base['reviews']) == 316
delta_path = R / 'final-v9-receipt-source-deltas.json'
deltas = json.loads(delta_path.read_bytes())
assert deltas['revision'] == revision and deltas['counts'] == {'inputs': 974, 'changedOrAddedOrRemoved': 316}
review_path = R / 'final-v9-return-independent-review.json'
review = json.loads(review_path.read_bytes())
assert review['revision'] == revision and review['independent'] is True and review['status'] == 'pass' and not review['findings']
changed = {row['path']: row for row in review['files']}
assert len(changed) == len(review['files']) == 2
assert set(changed) == {'src/trade_journal.ts', 'src/web_server.ts'}
for path, row in changed.items():
    assert row['beforeSha256'] == old[path]['currentSha256']
    assert row['sha256'] == sha(Path(path).read_bytes()) and row['sha256'] != row['beforeSha256']
    assert isinstance(row['review'], str) and row['review'].strip()
assert set(old) == {row['path'] for row in deltas['deltas']}

def sealed(binding):
    """Keep original archived bindings or seal local evidence at its v8 context."""
    if 'archive' in binding:
        archive_path = Path(binding['archive']['path']).resolve()
        assert archive_path.is_relative_to(Path.cwd())
        assert sha(archive_path.read_bytes()) == binding['archive']['sha256']
        with tarfile.open(archive_path) as handle:
            entry = handle.getmember(binding['member'])
            assert entry.isfile() and not entry.issym() and not entry.islnk()
            evidence = handle.extractfile(entry).read()
        assert sha(evidence) == binding['sha256']
        return copy.deepcopy(binding)
    assert set(binding) == {'path', 'sha256'}
    evidence_member = 'review/' + binding['path']
    assert sha(members[evidence_member]) == binding['sha256']
    return {'archive': ref(archive), 'member': evidence_member, 'sha256': binding['sha256']}

rows = []
unchanged = 0
for delta in deltas['deltas']:
    path = delta['path']
    prior = old[path]
    assert prior['reviewed'] is True and sha(Path(path).read_bytes()) == delta['currentSha256']
    row = copy.deepcopy(prior)
    row['evidence'] = [sealed(binding) for binding in prior['evidence']]
    if path in changed:
        inspected = changed[path]
        assert prior['currentSha256'] == inspected['beforeSha256'] and delta['currentSha256'] == inspected['sha256']
        row['currentSha256'] = inspected['sha256']
        row['rationale'] = prior['rationale'] + ' Subsequent independent async-return review: ' + inspected['review']
        row['evidence'].extend([prior_binding, ref(review_path)])
    else:
        assert prior['currentSha256'] == delta['currentSha256']
        unchanged += 1
    rows.append(row)
assert len(rows) == 316 and unchanged == 314
result = {'revision': revision, 'deltas': ref(delta_path),
    'method': 'Preserve the exact source hashes, rationales and reviewed flags of 314 rows, with ordered evidence bytes held in their sealed historical contexts. Bind the two async-return source changes to the independent semantic review and prior sealed manifest. Fresh full execution remains mandatory; no operative adoption.',
    'priorSealedReview': prior_binding, 'supplements': [ref(review_path)],
    'frontendLintLog': ref(R / 'final-v9-frontend-lint.log'), 'reviews': rows}
destination = R / 'final-v9-receipt-source-review.json'
destination.open('x', encoding='utf-8', newline='\n').write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'manifest': ref(destination), 'reviewRows': len(rows), 'unchangedRows': unchanged}))
