"""Prepare an unapproved offline receipt; never mutate production files.

Run with the locked Python from repository root. Default writes review material;
--candidate requires final verification and an explicit source-review manifest.
The manifest is root's review record, not authorization manufactured by this tool.
"""
import argparse
import copy
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
OUT = ROOT / 'reports/findings-review'
ARCHIVE = ROOT / 'exchange_executor/certifications/reviews/fixer-1fd38d6a-evidence.tar.gz'
ARCHIVE_HASH = '1a0af4e9837aebc2be4a1dd1cbcceb1fe05cd2e1889cfbf4bdb7ad7d5482c0fa'
OLD_RECEIPT_HASH = 'b3ee8abb83d798cf1cac6f0793af797164b7e239df5cfa75bfe2480b35f3dad2'
NODE = Path('C:/Users/nikla/AppData/Local/Programs/node22/node-v22.23.2-win-x64/node.exe')
OUTPUT_TAG = None
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_bytes())

def ref(path):
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(path.read_bytes())}


def checked_binding(binding):
    if 'archive' not in binding:
        assert ref(ROOT / binding['path']) == binding
        return
    archive_path = (ROOT / binding['archive']['path']).resolve()
    assert archive_path.is_relative_to(ROOT) and ref(archive_path) == binding['archive']
    with tarfile.open(archive_path) as archive:
        member = archive.getmember(binding['member'])
        assert member.isfile() and not member.issym() and not member.islnk()
        raw = archive.extractfile(member).read()
    assert sha(raw) == binding['sha256']

def save(name, value):
    assert OUTPUT_TAG
    name = name.replace('current-', OUTPUT_TAG + '-', 1)
    path = OUT / name
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    if path.exists():
        assert path.read_bytes() == payload, f'Refusing to replace different evidence at {path}; preserve prior evidence'
    else:
        with path.open('xb') as handle:
            handle.write(payload)
    return ref(path)

def archived(suffix):
    assert sha(ARCHIVE.read_bytes()) == ARCHIVE_HASH
    member = 'next/reports/security-services/' + suffix
    with tarfile.open(ARCHIVE) as archive:
        raw = archive.extractfile(member).read()
    return json.loads(raw), {'archive': ref(ARCHIVE), 'member': member, 'sha256': sha(raw)}

def checked_log(report):
    path = ROOT / report['log']
    assert report['exitCode'] == 0 and sha(path.read_bytes()) == report['logSha256'], path
    return path.read_text(encoding='utf-8-sig')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tag', required=True)
    parser.add_argument('--frontend-tag', required=True)
    parser.add_argument('--revision', required=True)
    parser.add_argument('--frontend-delta-review', type=Path)
    parser.add_argument('--candidate', action='store_true')
    args = parser.parse_args()
    assert re.fullmatch(r'[a-zA-Z0-9_-]+', args.tag), 'Invalid evidence run tag'
    assert re.fullmatch(r'[a-zA-Z0-9_-]+', args.frontend_tag), 'Invalid frontend run tag'
    global OUTPUT_TAG
    OUTPUT_TAG = args.tag
    revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    assert re.fullmatch(r'[a-f0-9]{40}', args.revision) and revision == args.revision, 'Unexpected frozen revision'
    context_path = OUT / f'context-{args.tag}-before.json'
    context = read(context_path)
    assert context['revision'] == revision and context['rawEqualsGit'] and context['allInputsSingleLink']
    inputs = {row['path']: row['sha256'] for row in context['inputs']['files']}
    assert len(inputs) == len(context['inputs']['files']) == 974
    actual = json.loads(subprocess.check_output([str(NODE), '--input-type=module', '-e',
        "import {collectBuildInputs} from './scripts/verify_exchange_implementation.js';console.log(JSON.stringify(collectBuildInputs(process.cwd())));"], text=True))
    assert actual == context['inputs'], 'Source changed since recorded before-context'
    git_stream = subprocess.check_output(['git', 'cat-file', '--batch'],
        input=''.join(f'{revision}:{path}\n' for path in inputs).encode())
    offset = 0
    for path, digest in inputs.items():
        assert sha((ROOT / path).read_bytes()) == digest and (ROOT / path).stat().st_nlink == 1
        end = git_stream.index(b'\n', offset)
        size = int(git_stream[offset:end].split()[2])
        assert sha(git_stream[end + 1:end + 1 + size]) == digest, path
        offset = end + size + 2
    assert subprocess.check_output([str(NODE), '--version'], text=True).strip() == context['node']

    baseline, baseline_ref = archived('fixer-1fd38d6a-context-after.json')
    parity, parity_ref = archived('fixer-1fd38d6a-parity-supplement.json')
    old = {row['path']: row['sha256'] for row in baseline['inputs']['files']}
    deltas = [{'path': path, 'beforeSha256': old.get(path), 'currentSha256': inputs.get(path),
               'status': 'modified' if path in old and path in inputs else 'added' if path in inputs else 'removed'}
              for path in sorted(set(old) | set(inputs)) if old.get(path) != inputs.get(path)]
    assert len(deltas) == 316
    delta_ref = save('current-receipt-source-deltas.json', {'revision': revision, 'baselineContext': baseline_ref,
        'counts': {'inputs': len(inputs), 'changedOrAddedOrRemoved': len(deltas)}, 'deltas': deltas,
        'reviewStatus': 'requires-explicit-root-source-review'})

    sys.path.insert(0, str(ROOT / 'exchange_executor'))
    import ccxt
    from ccxt_certification_evidence import python_tree_hash, expected_profile_hash, validate_receipt
    from ccxt_profiles import PROFILES
    runtime = {'python': sys.version, 'ccxt': ccxt.__version__, 'node': context['node'],
        'executorTreeHash': python_tree_hash(ROOT / 'exchange_executor'),
        'sdkTreeHash': python_tree_hash(Path(ccxt.__file__).parent, sdk=True),
        'profileHash': expected_profile_hash(PROFILES['hyperliquid'])}
    assert sys.version_info[:2] == (3, 12) and ccxt.__version__ == '4.5.75'
    python_path = OUT / f'{args.tag}-python-full-unittest-execution.json'
    python = read(python_path)
    python_log = checked_log(python)
    assert python['inputsBefore'] == python['inputsAfter'] and python['relevantObservedInputsUnchanged']
    python_paths = {p.relative_to(ROOT).as_posix() for p in (ROOT / 'exchange_executor').rglob('*.py') if '__pycache__' not in p.parts}
    python_paths |= {p for p in ('docs/testing/ccxt-expansion-matrix.json', 'exchange_executor/requirements.txt') if (ROOT / p).exists()}
    assert python_paths == set(python['inputsAfter']), 'Python observed inventory changed'
    assert all(sha((ROOT / p).read_bytes()) == h for p, h in python['inputsAfter'].items())
    assert python['python'] == runtime['python'] and python['ccxt'] == runtime['ccxt']
    assert python['executorTreeHash'] == runtime['executorTreeHash'] and python['sdkTreeHash'] == runtime['sdkTreeHash']
    assert 'Ran 548 tests' in python_log and re.search(r'^OK\s*$', python_log, re.M)

    frontend_path = OUT / f'{args.frontend_tag}-frontend-execution.json'
    frontend = read(frontend_path)
    frontend_log = checked_log(frontend)
    frontend_context_path = ROOT / frontend['beforeContext'] if 'beforeContext' in frontend else OUT / f'context-{args.frontend_tag}-before.json'
    frontend_context = read(frontend_context_path)
    frontend_after_path = ROOT / frontend['afterContext'] if 'afterContext' in frontend else None
    if frontend_after_path:
        frontend_after = read(frontend_after_path)
        assert frontend_after['inputs'] == frontend_context['inputs'] and frontend_after['revision'] == frontend_context['revision']
    assert frontend['inputsUnchanged'] and frontend['sourceTreeHash'] == frontend_context['inputs']['sourceTreeHash']
    assert frontend['revision'] == frontend_context['revision']
    fi = {row['path']: row['sha256'] for row in frontend_context['inputs']['files']}
    # Inheritance cannot absorb production/config/tooling changes. Every changed
    # Node test must be explicitly reviewed for isolation from frontend execution.
    changed_since_frontend = sorted(p for p in set(inputs) | set(fi) if inputs.get(p) != fi.get(p))
    delta_review_path = (ROOT / args.frontend_delta_review).resolve() if args.frontend_delta_review else None
    delta_review = read(delta_review_path) if delta_review_path else {'reviews': []}
    if delta_review_path:
        assert delta_review['revision'] == revision and delta_review['frontendExecution'] == ref(frontend_path)
    scoped = {row['path']: row for row in delta_review['reviews']}
    assert len(scoped) == len(delta_review['reviews']) and set(scoped) == set(changed_since_frontend), 'Changed Node tests require explicit isolation review'
    for path in changed_since_frontend:
        assert path.startswith('tests/') and path.endswith(('.js', '.mjs', '.ts')), path
        row = scoped[path]
        assert row['beforeSha256'] == fi.get(path) and row['currentSha256'] == inputs.get(path)
        assert row['reviewed'] is True and row['frontendExecutionUnaffected'] is True and row['rationale'].strip()
        assert row['evidence']
        for binding in row['evidence']:
            assert ref(ROOT / binding['path']) == binding
    assert frontend_context['node'] == runtime['node']
    assert '402 passed (402)' in frontend_log and '44 passed (44)' in frontend_log
    inheritance = save('current-receipt-execution-continuity.json', {'revision': revision,
        'runtime': runtime, 'python': {'execution': ref(python_path), 'log': ref(ROOT / python['log']),
            'tests': 548, 'exactUnchangedObservedInputs': len(python['inputsAfter']), 'freshFinalRevisionRunClaimed': False,
            'note': 'Actual current-session execution; all observed Python inputs and runtime exactly match final source.'},
        'frontend': {'execution': ref(frontend_path), 'context': ref(frontend_context_path),
            'afterContext': ref(frontend_after_path) if frontend_after_path else None,
            'log': ref(ROOT / frontend['log']), 'tests': 402, 'files': 44,
            'sourceChangesSinceRun': changed_since_frontend,
            'freshFinalRevisionRunClaimed': not changed_since_frontend and frontend['revision'] == revision,
            'nodeTestDeltaIsolationReview': ref(delta_review_path) if delta_review_path else None,
            'note': 'Complete inputs/runtime compared; any differences require explicitly reviewed isolated Node tests. Fresh final revision is claimed only when complete inputs and revision match.'},
        'providerAcceptanceVerified': False})

    node_review_path = OUT / f'{args.tag}-strict-node-witness-assertion-review.json'
    subprocess.run([str(NODE), str(OUT / 'review-node-witnesses-strict.mjs'), str(node_review_path)], check=True, stdout=subprocess.DEVNULL)
    node_review = {row['path']: row for row in read(node_review_path)}
    py_review_path = OUT / 'python-evidence-review.json'
    py_review = {row['path']: row for row in read(py_review_path)['changes']}
    rows = []
    changed = 0
    for prior in parity['rows']:
        bindings = []
        for witness in prior['witnessBindings']:
            path = witness['path']
            assert old[path] == witness['sha256'], path
            now = inputs[path]
            binding = {'path': path, 'sha256': now, 'previousSha256': witness['sha256'], 'unchanged': now == witness['sha256']}
            if now != witness['sha256']:
                changed += 1
                if path in node_review:
                    review = node_review[path]
                    assert not review['missing']
                    assert review['currentSha256'] == now
                    # Report comparison is against current main: verify its baseline
                    # is exactly the historical witness, and its current input stable.
                    main_bytes = subprocess.check_output(['git', 'show', '486d175d2ed7a92783edac0882aa9a902bbc1450:' + path])
                    assert sha(main_bytes) == witness['sha256']
                    binding['review'] = {'evidence': ref(node_review_path), 'lookup': path,
                        'rationale': 'Every previous assertion retained under exact TypeScript-printer comparison without async callback normalization; native Promise-boundary assertions are preserved. Additional assertions strengthen current coverage.',
                        'previousAssertions': review['previousAssertions'], 'currentAssertions': review['currentAssertions'],
                        'execution': 'current full Node module suite'}
                else:
                    review = py_review[path]
                    assert review['beforeSha256'] == witness['sha256']
                    assert review['currentSha256'] == now and review['nextExpressionMultisetPreserved']
                    assert all(row['assertionsEquivalentAfterInliningNextLocals'] for row in review['assertionEquivalenceChecks'])
                    binding['review'] = {'evidence': ref(py_review_path), 'lookup': path,
                        'rationale': 'Existing selector expressions retained; all assertions equivalent after inlining extracted next() locals. Missing fixtures still fail. Current-session full Python548 execution uses exact same bytes.',
                        'execution': inheritance}
            bindings.append(binding)
        rows.append({'category': prior['category'], 'check': prior['check'],
            'historicalMapping': {'evidence': parity_ref, 'lookup': {'category': prior['category'], 'check': prior['check']}},
            'witnessBindings': bindings, 'sourceReviewStatus': 'pending-explicit-complete-delta-review'})
    assert len(rows) == 62 and len({(r['category'], r['check']) for r in rows}) == 62
    assert sum(len(r['witnessBindings']) for r in rows) == 97
    mapping_ref = save('current-receipt-witness-continuity.json', {'revision': revision, 'baselineParity': parity_ref,
        'counts': {'requirements': 62, 'witnessReferences': 97, 'changedWitnessReferences': changed,
            'unchangedWitnessReferences': 97 - changed}, 'rows': rows, 'providerAcceptanceVerified': False,
        'operativeReceiptApproved': False})
    if not args.candidate:
        print(json.dumps({'prepared': [delta_ref, inheritance, mapping_ref], 'candidateCreated': False}))
        return

    after_path = OUT / f'context-{args.tag}-after.json'
    after = read(after_path)
    assert after['revision'] == revision and after['inputs'] == context['inputs'] and after['node'] == context['node']
    assert after['rawEqualsGit'] and after['allInputsSingleLink']
    completion_path = OUT / f'{args.tag}-execution-completion.json'
    completion = read(completion_path)
    assert completion['revision'] == revision and completion['afterContextExit'] == 0
    assert len(completion['rows']) == 2
    assert {row['name'] for row in completion['rows']} == {'build', 'test:coverage:modules'}
    for row in completion['rows']:
        assert context['observedAt'] <= row['startedAt'] <= row['finishedAt'] <= after['observedAt']
        log = checked_log(row)
        if row['name'] == 'test:coverage:modules':
            assert 'ALL 226 TEST FILES PASSED' in log and 'Module coverage ratchet passed.' in log
    manifest_path = OUT / f'{args.tag}-receipt-source-review.json'
    manifest = read(manifest_path)
    assert manifest['revision'] == revision and manifest['deltas'] == delta_ref
    reviewed = {row['path']: row for row in manifest['reviews']}
    assert len(reviewed) == len(manifest['reviews']), 'Duplicate source review rows'
    assert set(reviewed) == {row['path'] for row in deltas}
    for delta in deltas:
        row = reviewed[delta['path']]
        assert row['currentSha256'] == delta['currentSha256'] and row['reviewed'] is True and row['rationale'].strip()
        assert row['evidence'], delta['path']
        for binding in row['evidence']:
            checked_binding(binding)
    execution_ref = save('current-receipt-execution-supplement.json', {'revision': revision,
        'node': {'testFiles': 226, 'build': 'PASS', 'coverageRatchet': 'PASS', 'completion': ref(completion_path),
            'logs': [ref(ROOT / row['log']) for row in completion['rows']]}, 'inheritedCurrentSessionExecution': inheritance,
        'beforeContext': ref(context_path), 'afterContext': ref(after_path), 'runtime': runtime,
        'providerAcceptanceVerified': False, 'operativeReceiptApproved': False})
    for row in rows:
        row['sourceReviewStatus'] = 'complete-source-deltas-reviewed'
        row['sourceReview'] = ref(manifest_path)
        row['execution'] = execution_ref
    parity_ref_new = save('current-receipt-parity-supplement.json', {'revision': revision, 'baselineParity': parity_ref,
        'rows': rows, 'counts': {'requirements': 62, 'witnessReferences': 97, 'changedWitnessReferences': changed},
        'providerAcceptanceVerified': False, 'operativeReceiptApproved': False})
    active = ROOT / 'exchange_executor/certifications/hyperliquid.json'
    assert sha(active.read_bytes()) == OLD_RECEIPT_HASH
    candidate = copy.deepcopy(read(active))
    candidate.update(sourceRevision=revision, reviewedAt=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
        parityEvidenceHash=parity_ref_new['sha256'], executionReportHash=execution_ref['sha256'])
    for key in ('sourceTreeHash', 'nodeSourcesHash', 'testSourcesHash', 'fixturesHash'):
        candidate[key] = context['inputs'][key]
    for key in ('executorTreeHash', 'sdkTreeHash', 'profileHash'):
        candidate[key] = runtime[key]
    validate_receipt(candidate, 'hyperliquid', ccxt.__version__, PROFILES['hyperliquid'], ROOT / 'exchange_executor', Path(ccxt.__file__).parent)
    final_inputs = json.loads(subprocess.check_output([str(NODE), '--input-type=module', '-e',
        "import {collectBuildInputs} from './scripts/verify_exchange_implementation.js';console.log(JSON.stringify(collectBuildInputs(process.cwd())));"], text=True))
    assert final_inputs == actual and subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == revision
    candidate_ref = save('current-hyperliquid-receipt-candidate.json', candidate)
    summary = {'revision': revision, 'candidate': candidate_ref, 'execution': execution_ref, 'parity': parity_ref_new,
        'completeSourceReview': ref(manifest_path), 'generator': ref(Path(__file__).resolve()),
        'reproducibilityHelpers': [ref(OUT / name) for name in ('collect-context.mjs', 'run-final.mjs',
            f'run-{args.frontend_tag}-frontend.mjs', f'run-{args.tag}-full-python.py', 'review-node-witnesses-strict.mjs',
            'review-python-evidence.py', 'finalize-python-evidence-review.py', 'assemble-final-v9-source-review.py')],
        'operativeReceiptOrPinsChanged': False, 'operativeReceiptApproved': False,
        'remaining': ['Independent exact candidate/source/reference graph review', 'Deterministic evidence archive and re-read',
            'Explicit root adoption of candidate and authority pin', 'Production build/runtime gate and bridge regression tests']}
    save('current-receipt-candidate-state.json', summary)
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
