import http from 'node:http';
import { promises as fsPromises } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash, randomUUID, timingSafeEqual } from 'node:crypto';
import { gzipSync } from 'node:zlib';
import { hasCurrentRestorableBackup } from './backup_evidence.js';
import { validateConfig, writeConfigSync, type Config } from './config.js';
import type { MetricPoint } from './metrics_tracker.js';
import type { OutboxTask } from './db.js';
import { configurationRevision, mergeConfiguration } from './ui_configuration.js';
import { addLog, getLogEntries } from './logger.js';
import {
  getIncomingMessages,
  getProcessedSignals,
  getSignalDashboardAnalytics,
  clearDb,
  deleteIncomingMessage,
  deleteProcessedSignal,
  SignalReferencedError,
  withDatabaseTransaction,
} from './db.js';
import type { EnterpriseAuditTrail } from './audit_trail.js';
import {
  dashboardAuthenticatorFromEnvironment,
  type AuthenticatedActor,
  type DashboardAuthenticator,
} from './dashboard_auth.js';
import type { ManagedSecretStore } from './secret_store.js';
import type { TelegramLoginSnapshot } from './telegram_login.js';
import type { ManagedRuntimeSettingsStore } from './runtime_settings.js';
import type { TradingWebControl } from './trading_web_control.js';
import {
  approveMcpProposal,
  createMcpAgent,
  deleteMcpAgent,
  getMcpRuntimeState,
  mcpDashboardSnapshot,
  rejectMcpProposal,
  rotateMcpAgentToken,
  setMcpRuntimeMode,
  updateMcpAgent,
} from './mcp_repository.js';
import {
  listTradeJournal,
  listTradeJournalPage,
  tradeJournalCsv,
  updateTradeJournalReview,
  type TradeJournalFilters,
} from './trade_journal.js';
import {
  archiveWorkflowResource,
  archiveWorkflowResourceFamily,
  createWorkflowResourceDraft,
  clearWorkflowBuilderHistory,
  deleteWorkflowResourceFamily,
  deleteWorkflowResourceDraft,
  getActiveWorkflow,
  getWorkflowBuilderHistoryStatus,
  listWorkflowResources,
  listWorkflowFallbackRuns,
  applyWorkflowBuilderHistory,
  publishWorkflowResource,
  previewWorkflowBuilderHistoryImpact,
  previewWorkflowImpact,
  saveWorkflowRevision,
  simulateWorkflow,
  updateWorkflowResourceDraft,
} from './workflow_repository.js';
import { getFilteredTradingAnalytics } from './trading_telemetry.js';
import { tradingExchangeId } from './trading_types.js';
import {
  applyPortableSetupBundle,
  assertSetupBundleContainsNoSecrets,
  exportPortableSetupBundle,
  suggestPortableAccountMappings,
  validatePortableSetupBundle,
  type PortableSetupBundle,
} from './setup_bundle.js';
import type { ManagedTelegramViewerSettingsStore } from './telegram_viewer_settings.js';
import type { TelegramViewerSecretStore } from './telegram_viewer_secrets.js';
import { constantTimeStringEqual } from './secure_compare.js';
import { uiIngressDetail, uiSignalPage, type UiSignalList } from './ui_signal_reads.js';
import { uiSignalOriginal } from './ui_signal_original.js';
import { uiDeployment } from './ui_deployment.js';
import { uiAttention } from './ui_attention.js';
import { uiMcpSnapshot } from './ui_mcp_reads.js';
import { uiCockpit } from './ui_cockpit.js';
import { uiAccountDetail, uiTradingPage, uiTradeSafety, type UiTradingList } from './ui_trading_reads.js';
import { uiTradeRelationPage, uiJournalDetail, uiJournalSummary, type UiTradeRelation } from './ui_trade_relations.js';
import { deleteUiWorkflowDraft, getUiWorkflowDraft, saveUiWorkflowDraft, activateUiWorkflowDraft } from './ui_workflow_drafts.js';
import { type UiOperationStore, type UiJobKind, UI_PROCESS_INSTANCE_ID } from './ui_operation_store.js';
import { UiRestartCoordinator } from './ui_restart_coordinator.js';
import { prepareUiParserTest, runUiParserTest, uiParserMetadata } from './ui_parser_lab.js';
import { uiMcpProposalReview, approveReviewedMcpProposal } from './ui_mcp_review.js';
import { redactReview, redactReviewRecord, reviewHash } from './ui_change_review.js';
import { setupReviewContent, setupContentReview, uiSetupCurrentState } from './ui_setup_review.js';
import { uiReviewTree } from './ui_review_tree.js';
import { uiWorkflowPage, uiWorkflowDetail, type UiWorkflowList } from './ui_workflow_reads.js';
import { uiModelPage, uiModelDetail, mutateUiModel } from './ui_workflow_models.js';
import { uiAccountEvidence, uiAccountReservations, uiAccountHistory } from './ui_account_evidence.js';
import { uiAdaptiveRisk, copyLegacyRiskPolicy } from './ui_adaptive_risk.js';
import { uiIngressRelations, type UiIngressRelation } from './ui_ingress_relations.js';
import { publishUiResourceWithDependency } from './ui_resource_publication.js';
import { uiSearch } from './ui_search.js';
import { uiCapabilities } from './ui_capabilities.js';
import { uiParameters } from './ui_parameter_catalog.js';
import { JOURNAL_INTENT_STATUSES } from './ui_contracts.js';
import {
  createTelegramViewerTestEvent,
  listTelegramViewerTestEvents,
  listTradingNotificationEvents,
} from './viewer_repository.js';
import {
  viewerAccounts,
  viewerIncidents,
  viewerOrders,
  viewerPerformance,
  viewerPositions,
  viewerRisk,
  viewerSummary,
  viewerSystem,
  viewerTrades,
} from './viewer_projection.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const STATIC_ROOT = path.resolve(__dirname, '../frontend/dist');
const SETUP_PREVIEW_TTL_MS = 15 * 60 * 1_000;
const SETUP_APPLY_CONFIRMATION = 'REPLACE EXISTING SETUP';
interface SetupBundlePreview {
  actorId: string;
  bundle: PortableSetupBundle;
  bundleHash: string;
  baseHash: string;
  expiresAt: number;
  automaticAccountMappings: Record<string, string>;
}
const setupBundlePreviews = new Map<string, SetupBundlePreview>();
const SECRET_CONFIG_KEYS = new Set([
  'apiHash',
  'openRouterApiKey',
  'telegramApiHash',
  'dashboardAdminToken',
  'dashboardViewerToken',
  'auditWebhookToken',
  'alertRelayToken',
  'alertWebhookToken',
  'backupOffsiteToken',
  'backupEncryptionKey',
  'OPENROUTER_API_KEY',
  'TELEGRAM_API_HASH',
  'DASHBOARD_ADMIN_TOKEN',
  'DASHBOARD_VIEWER_TOKEN',
  'BACKUP_OFFSITE_TOKEN',
  'BACKUP_ENCRYPTION_KEY',
  'ALERT_RELAY_TOKEN',
  'ALERT_WEBHOOK_TOKEN',
  'PROMETHEUS_TOKEN',
  'AUDIT_WEBHOOK_TOKEN',
]);
const MIME_TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.json': 'application/json',
};

interface WebServerState {
  startupAuthority?: Pick<import('./startup_authority.js').StartupAuthority, 'canMutate' | 'snapshot'>;
  config: Config;
  state: {
    isRunning: boolean;
    connectionState?: string;
    totalForwardedCount?: number;
    processedSinceRestart?: number;
    startupTime?: number | null;
    resolvedSourceChatIds?: Iterable<unknown>;
  };
  getQueueState: () => {
    running: number;
    queued: number;
    maxConcurrency: number;
    paused: boolean;
  };
  startForwarding: (config: Config) => Promise<void>;
  stopForwarding: () => Promise<void>;
  reloadConfig: () => void;
  applyRuntimeConfig: (config: Config) => void;
  persistConfig?: (config: Config) => void;
  getMetricsHistory?: () => MetricPoint[];
  getOutboxTasks?: (statuses?: string[]) => Promise<OutboxTask[]>;
  retryOutboxTask?: (id: string) => Promise<boolean>;
  acknowledgeOutboxTask?: (id: string, reason: string) => Promise<boolean>;
  auditTrail?: Pick<EnterpriseAuditTrail, 'record' | 'snapshot' | 'replayRemote' | 'flush'>;
  authenticator?: DashboardAuthenticator;
  secretStore?: Pick<ManagedSecretStore,
    | 'status'
    | 'set'
    | 'createDashboardAdminToken'
    | 'rotateDashboardToken'
    | 'removeDashboardViewerToken'
    | 'clear'
    | 'recoveryStatus'
  >;
  getTelegramLoginState?: () => TelegramLoginSnapshot;
  submitTelegramLogin?: (payload: unknown) => TelegramLoginSnapshot;
  getOperationsStatus?: () => Record<string, unknown>;
  runBackupNow?: () => Promise<string>;
  listBackups?: () => Promise<string[]>;
  verifyBackup?: (artifactName: string) => Promise<unknown>;
  runBackupDrill?: (artifactName: string) => Promise<unknown>;
  uiOperations?: UiOperationStore;
  recoverOffsiteBackup?: (objectName: string) => Promise<string>;
  restoreBackup?: (artifactName: string) => Promise<{ previousDatabase: string | null; previousConfig: string | null }>;
  performFactoryReset?: () => Promise<void>;
  requestRestart?: () => void;
  runtimeSettings?: Pick<ManagedRuntimeSettingsStore, 'snapshot' | 'set' | 'recoveryStatus'> & Partial<Pick<ManagedRuntimeSettingsStore, 'describe'>>;
  telegramViewerSettings?: Pick<ManagedTelegramViewerSettingsStore, 'snapshot' | 'set' | 'recoveryStatus'>;
  telegramViewerSecrets?: Pick<TelegramViewerSecretStore,
    'status' | 'readBotToken' | 'setBotToken' | 'deleteBotToken' | 'serviceToken' | 'rotateServiceToken'
  >;
  getTelegramViewerStatus?: () => Promise<Record<string, unknown>>;
  tradingControl?: TradingWebControl;
  recovery?: {
    active: boolean;
    allowLoopbackLocalSession: boolean;
    issues: Array<{ component: 'configuration' | 'runtimeSettings' | 'managedSecret'; name?: string; reason: string }>;
  };
}

interface RequestContext {
  req: http.IncomingMessage;
  res: http.ServerResponse;
  requestId: string;
  parsedUrl: URL;
  appState: WebServerState;
  authenticator: DashboardAuthenticator;
  actor?: AuthenticatedActor;
  mutationAudit?: MutationAuditContext;
}

interface MutationAuditContext {
  actor: AuthenticatedActor;
  action: string;
  target: unknown;
  before: unknown;
}

type ApiHandler = (context: RequestContext) => Promise<void> | void;

let server: http.Server | null = null;
let mutationInProgress = false;
const serverInstanceId = UI_PROCESS_INSTANCE_ID;
const serverVersion = fsPromises.readFile(new URL('../package.json', import.meta.url), 'utf8')
  .then(content => String(JSON.parse(content).version)).catch(() => 'unknown');
const requestContexts = new WeakMap<http.IncomingMessage, RequestContext>();

class HttpError extends Error {
  constructor(
    public readonly statusCode: number,
    message: string
  ) {
    super(message);
  }
}

function sendJson(res: http.ServerResponse, statusCode: number, payload: unknown): void {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Pragma', 'no-cache');
  res.end(JSON.stringify(payload));
}

function errorStatus(error: unknown): number {
  return error instanceof HttpError ? error.statusCode : 500;
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : 'Unexpected server error.';
}

function sendError(context: RequestContext, error: unknown): void {
  sendJson(context.res, errorStatus(error), {
    error: errorMessage(error),
    requestId: context.requestId,
  });
}

function isAllowedOrigin(origin: string | undefined): boolean {
  if (!origin) return true;
  const configuredOrigin = process.env.DASHBOARD_ALLOWED_ORIGIN?.trim();
  if (configuredOrigin && origin === configuredOrigin) return true;
  try {
    const parsed = new URL(origin);
    return (
      parsed.protocol === 'http:' &&
      ['127.0.0.1', 'localhost', '::1', '[::1]'].includes(parsed.hostname)
    );
  } catch {
    return false;
  }
}

function isLoopbackBrowserOrigin(origin: string): boolean {
  try {
    const parsed = new URL(origin);
    return parsed.protocol === 'http:' && ['127.0.0.1', 'localhost', '::1', '[::1]'].includes(parsed.hostname);
  } catch {
    return false;
  }
}

function isDirectLoopbackRequest(req: http.IncomingMessage): boolean {
  const remoteAddress = req.socket.remoteAddress?.toLowerCase();
  const loopback = remoteAddress === '127.0.0.1' || remoteAddress === '::1'
    || remoteAddress?.startsWith('::ffff:127.') === true;
  const proxyHeaders = ['forwarded', 'x-forwarded-for', 'x-real-ip', 'x-client-ip'];
  return loopback && proxyHeaders.every(header => req.headers[header] === undefined);
}

function configuredBootstrapProof(): string | null {
  const proof = process.env.DASHBOARD_BOOTSTRAP_PROOF?.trim() || '';
  if (proof.length < 32 || proof.length > 1024 || /^(?:replace_|change-?me|example|placeholder)/i.test(proof)) return null;
  return proof;
}

function validBootstrapProof(candidate: unknown): boolean {
  const expected = configuredBootstrapProof();
  if (!expected || typeof candidate !== 'string' || candidate.length > 1024) return false;
  const candidateDigest = createHash('sha256').update(candidate).digest();
  const expectedDigest = createHash('sha256').update(expected).digest();
  return timingSafeEqual(candidateDigest, expectedDigest);
}

function setSecurityHeaders(res: http.ServerResponse, origin?: string): void {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
  );
  if (origin && isAllowedOrigin(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
}

async function readJsonBody(req: http.IncomingMessage, maxBytes = 256 * 1024): Promise<Record<string, unknown>> {
  const declaredLength = Number(req.headers['content-length']);
  if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
    throw new HttpError(413, `Request body exceeds ${maxBytes} bytes.`);
  }
  const chunks: Buffer[] = [];
  let receivedBytes = 0;
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    receivedBytes += buffer.length;
    if (receivedBytes > maxBytes) {
      throw new HttpError(413, `Request body exceeds ${maxBytes} bytes.`);
    }
    chunks.push(buffer);
  }
  assertBodyMutationAllowed(req);
  if (chunks.length === 0) return {};
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    const context = requestContexts.get(req);
    if (context?.mutationAudit) {
      context.mutationAudit.target = {
        ...(typeof context.mutationAudit.target === 'object' && context.mutationAudit.target
          ? context.mutationAudit.target as Record<string, unknown>
          : {}),
        request: safeAuditValue(parsed),
      };
    }
    return parsed;
  } catch {
    throw new HttpError(400, 'Request body is not valid JSON.');
  }
}

function publicConfig(config: Config): Record<string, unknown> {
  return JSON.parse(
    JSON.stringify(config || {}, (key, value) => (SECRET_CONFIG_KEYS.has(key) ? undefined : value))
  );
}

const AUDIT_SECRET_KEY = /(secret|token|password|private.?key|api.?key|api.?hash|authorization|credential|bootstrap.?proof|sourceText)/i;

function safeAuditValue(value: unknown, depth = 0): unknown {
  if (value === null || typeof value === 'boolean') return value;
  if (typeof value === 'number') return Number.isFinite(value) ? value : '[INVALID_NUMBER]';
  if (typeof value === 'string') return value.length <= 1024 ? value : `${value.slice(0, 1024)}...[TRUNCATED]`;
  if (depth >= 6) return '[MAX_DEPTH]';
  if (Array.isArray(value)) {
    return value.slice(0, 100).map((item) => safeAuditValue(item, depth + 1));
  }
  if (typeof value === 'bigint') return value.toString();
  if (!value || typeof value !== 'object') return '[UNSUPPORTED_VALUE]';
  return Object.fromEntries(
    Object.entries(value as Record<string, unknown>)
      .slice(0, 100)
      .map(([key, item]) => [key, SECRET_CONFIG_KEYS.has(key) || AUDIT_SECRET_KEY.test(key)
        ? '[REDACTED]'
        : safeAuditValue(item, depth + 1)])
  );
}

function semanticMutationAction(method: string, url: string): string {
  const known: Record<string, string> = {
    '/api/config': 'configuration.update',
    '/api/import': 'configuration.import',
    '/api/setup-bundle/preview': 'setup-bundle.preview',
    '/api/setup-bundle/apply': 'setup-bundle.apply',
    '/api/secrets': 'secrets.update',
    '/api/control': 'routing.control',
    '/api/telegram-login': 'telegram.authentication.update',
    '/api/runtime-settings': 'runtime.settings.update',
    '/api/mcp/runtime': 'mcp.runtime.update',
    '/api/factory-reset': 'system.factory-reset',
    '/api/restart': 'system.restart',
    '/api/access-tokens': 'access-token.rotate',
    '/api/access-tokens/viewer': 'access-token.disable-viewer',
    '/api/operations/backup': 'backup.create',
    '/api/operations/audit-replay': 'audit.replay',
    '/api/backups/recover-offsite': 'backup.recover-offsite',
    '/api/backups/restore': 'backup.restore',
    '/api/database': 'database.clear',
    '/api/outbox/retry': 'outbox.retry',
    '/api/outbox/acknowledge': 'outbox.acknowledge',
    '/api/workflow/history/impact': 'workflow.history.impact',
    '/api/workflow/history/apply': 'workflow.history.apply',
    '/api/workflow/history/reset': 'workflow.history.reset',
    '/api/telegram-viewer/settings': 'telegram-viewer.settings.update',
    '/api/telegram-viewer/token': method === 'DELETE'
      ? 'telegram-viewer.token.delete' : 'telegram-viewer.token.update',
    '/api/telegram-viewer/service-token/rotate': 'telegram-viewer.service-token.rotate',
    '/api/telegram-viewer/test': 'telegram-viewer.test.create',
  };
  if (known[url]) return known[url];
  if (url.startsWith('/api/trading/')) {
    const target = url.slice('/api/trading/'.length).replace(/[^a-z0-9]+/gi, '.').replace(/^\.|\.$/g, '');
    return `trading.${target || 'control'}.${method.toLowerCase()}`.slice(0, 128);
  }
  const target = url.slice('/api/'.length).replace(/[^a-z0-9]+/gi, '.').replace(/^\.|\.$/g, '');
  return `dashboard.${target || 'mutation'}.${method.toLowerCase()}`.slice(0, 128);
}

function auditTargetFromRequest(context: RequestContext): unknown {
  const query = Object.fromEntries(context.parsedUrl.searchParams.entries());
  return safeAuditValue(Object.keys(query).length > 0 ? { query } : { resource: context.parsedUrl.pathname });
}

function secretAuditState(context: RequestContext): unknown {
  return safeAuditValue(context.appState.secretStore?.status() ?? { available: false });
}

function runtimeAuditState(context: RequestContext): unknown {
  return safeAuditValue(context.appState.runtimeSettings?.snapshot() ?? { available: false });
}

function routingAuditState(context: RequestContext): unknown {
  const { appState } = context;
  return safeAuditValue({
    isRunning: appState.state.isRunning,
    connectionState: appState.state.connectionState,
    forwardingEnabled: appState.config.forwardOptions?.forwardToTarget ?? true,
    queue: appState.getQueueState(),
    telegramLogin: appState.getTelegramLoginState?.(),
  });
}

function auditDomainState(context: RequestContext, action: string): unknown {
  const { appState } = context;
  if (action.startsWith('configuration.')) return safeAuditValue(publicConfig(appState.config));
  if (action.startsWith('secrets.') || action.startsWith('access-token.')) return secretAuditState(context);
  if (action.startsWith('runtime.settings.')) return runtimeAuditState(context);
  if (action.startsWith('telegram-viewer.')) {
    return safeAuditValue({
      settings: context.appState.telegramViewerSettings?.snapshot(),
      secrets: context.appState.telegramViewerSecrets?.status(),
    });
  }
  if (action.startsWith('routing.') || action.startsWith('telegram.')) return routingAuditState(context);
  if (action.startsWith('system.')) {
    return safeAuditValue({ recovery: appState.recovery?.active ?? false, isRunning: appState.state.isRunning });
  }
  return safeAuditValue({ domain: action.split('.')[0], stateSnapshot: 'captured-in-domain-result' });
}

function installMutationAuditBarrier(context: RequestContext): void {
  const audit = context.mutationAudit;
  const trail = context.appState.auditTrail;
  if (!audit || !trail) return;
  const response = context.res;
  type AuditResponseEnd = (chunk?: unknown, encodingOrCallback?: unknown, callback?: unknown) => unknown;
  const originalEnd = response.end.bind(response) as unknown as AuditResponseEnd;
  let finalizing = false;
  (response as unknown as { end: AuditResponseEnd }).end = (chunk?: unknown, encodingOrCallback?: unknown, callback?: unknown) => {
    if (finalizing) return response;
    finalizing = true;
    const originalStatus = response.statusCode;
    let callbackFunction: (() => void) | undefined;
    if (typeof encodingOrCallback === 'function') callbackFunction = encodingOrCallback as () => void;
    else if (typeof callback === 'function') callbackFunction = callback as () => void;
    let responsePayload: unknown;
    if (typeof chunk === 'string') {
      try { responsePayload = JSON.parse(chunk); } catch { responsePayload = '[NON_JSON_RESPONSE]'; }
    }
    let outcome: 'succeeded' | 'rejected' | 'failed' = 'failed';
    if (originalStatus < 400) outcome = 'succeeded';
    else if (originalStatus < 500) outcome = 'rejected';
    trail.record({
      phase: 'completed',
      action: audit.action,
      requestId: context.requestId,
      actorId: audit.actor.id,
      actorRole: audit.actor.role,
      method: context.req.method,
      path: context.parsedUrl.pathname,
      statusCode: originalStatus,
      target: safeAuditValue(audit.target),
      before: safeAuditValue(audit.before),
      after: safeAuditValue({ state: auditDomainState(context, audit.action), response: responsePayload }),
      outcome,
    }).then(() => {
      addLog(`[AUDIT] request_id=${context.requestId} action=${audit.action} actor_role=${audit.actor.role} outcome=${outcome} status=${originalStatus}`);
      originalEnd(chunk, callbackFunction);
    }).catch((error: Error) => {
      addLog(`[CRITICAL] request_id=${context.requestId} Audit outcome persistence failed: ${error.message}`, {
        request_id: context.requestId,
        event: 'audit_outcome_persistence_failed',
        action: audit.action,
      });
      if (originalStatus < 400 && !response.headersSent) {
        response.statusCode = 503;
        response.removeHeader('Content-Length');
        originalEnd(JSON.stringify({
          error: 'Audit outcome could not be durably persisted; mutation result is not acknowledged.',
          requestId: context.requestId,
        }), callbackFunction);
        return;
      }
      originalEnd(chunk, callbackFunction);
    });
    return response;
  };
}

function containsSecretConfig(input: unknown): boolean {
  if (!input || typeof input !== 'object') return false;
  return Object.entries(input).some(
    ([key, value]) => SECRET_CONFIG_KEYS.has(key) || containsSecretConfig(value)
  );
}

function requireMutationHeaders(req: http.IncomingMessage): void {
  if (req.headers['x-requested-with'] !== 'forwarder-dashboard') {
    throw new HttpError(400, 'Missing X-Requested-With header.');
  }
}

async function authorizeMutationAudit(
  context: RequestContext,
  actor: AuthenticatedActor,
  method: string,
  url: string
): Promise<boolean> {
  try {
    requireMutationHeaders(context.req);
    if (!context.appState.auditTrail) {
      if (context.appState.recovery?.active
        && context.appState.recovery.allowLoopbackLocalSession
        && recoveryAllowsRoute(method, url)) {
        addLog(`[CRITICAL] request_id=${context.requestId} Recovery repair mutation accepted without an audit trail.`, {
          request_id: context.requestId,
          event: 'recovery_unaudited_repair',
          path: url,
        });
        return true;
      }
      throw new Error('Audit trail is unavailable.');
    }
    const action = semanticMutationAction(method, url);
    context.mutationAudit = {
      actor,
      action,
      target: auditTargetFromRequest(context),
      before: auditDomainState(context, action),
    };
    await context.appState.auditTrail.record({
      phase: 'authorized',
      action,
      requestId: context.requestId,
      actorId: actor.id,
      actorRole: actor.role,
      method,
      path: url,
      target: context.mutationAudit.target,
      before: context.mutationAudit.before,
    });
    installMutationAuditBarrier(context);
    return true;
  } catch (error) {
    context.mutationAudit = undefined;
    if (error instanceof HttpError) {
      sendError(context, error);
      return false;
    }
    addLog(`[CRITICAL] Audit precondition failed; dashboard mutation blocked: ${errorMessage(error)}`, {
      request_id: context.requestId,
      event: 'audit_precondition_failed',
    });
    sendJson(context.res, 503, {
      error: 'Audit trail unavailable; mutation blocked.',
      requestId: context.requestId,
    });
    return false;
  }
}

async function authenticateApiRequest(
  context: RequestContext,
  authenticator: DashboardAuthenticator,
  method: string,
  url: string
): Promise<AuthenticatedActor | null> {
  const { res, requestId } = context;
  if (!authenticator.isConfigured()) {
    sendJson(res, 503, { error: 'Dashboard authentication is not configured.', requestId });
    return null;
  }
  const actor = await authenticator.authenticate(
    context.req.headers.authorization,
    context.req.headers as Record<string, string | string[] | undefined>,
  );
  if (!actor) {
    res.setHeader('WWW-Authenticate', 'Bearer realm="forwarder-dashboard"');
    sendJson(res, 401, { error: 'Valid dashboard bearer token required.', requestId });
    return null;
  }
  context.actor = actor;
  res.setHeader('X-Authenticated-Role', actor.role);
  if (method === 'GET') return actor;
  if (actor.role !== 'admin') {
    sendJson(res, 403, { error: 'Administrator role required.', requestId });
    return null;
  }
  return (await authorizeMutationAudit(context, actor, method, url)) ? actor : null;
}

function firstConfigured(...values: Array<string | undefined>): string {
  return values.find(Boolean) ?? '';
}

async function statusHandler({ res, appState }: RequestContext): Promise<void> {
  const xmlConfig: Partial<Config['xmlParsing']> = appState.config.xmlParsing ?? {};
  const apiKey = process.env.OPENROUTER_API_KEY;
  sendJson(res, 200, {
    startup: appState.startupAuthority?.snapshot(),
    isRunning: appState.state.isRunning,
    connectionState: firstConfigured(appState.state.connectionState, 'disconnected'),
    totalForwardedCount: appState.state.totalForwardedCount ?? 0,
    processedSinceRestart: appState.state.processedSinceRestart ?? 0,
    forwardingEnabled: appState.config.forwardOptions?.forwardToTarget ?? true,
    forwardXmlToTarget: xmlConfig.forwardXmlToTarget ?? false,
    startTime: appState.state.startupTime
      ? new Date(appState.state.startupTime * 1000).toISOString()
      : null,
    queue: appState.getQueueState(),
    resolvedSources: Array.from(appState.state.resolvedSourceChatIds ?? []),
    openRouterModel: firstConfigured(
      process.env.OPENROUTER_MODEL,
      xmlConfig.primaryModel,
      'google/gemini-flash-1.5'
    ),
    openRouterFallbackModel: firstConfigured(
      process.env.OPENROUTER_FALLBACK_MODEL,
      xmlConfig.fallbackModel,
      'anthropic/claude-3-haiku'
    ),
    openRouterApiKeyConfigured: Boolean(apiKey && apiKey !== 'your_openrouter_api_key_here'),
    telegramLogin: appState.getTelegramLoginState?.() ?? { state: 'idle' },
    mcp: await getMcpRuntimeState(),
    config: {
      sourceChannels: appState.config.sourceChannels,
      targetChannel: appState.config.targetChannel,
    },
  });
}

function secretsHandler({ res, appState }: RequestContext): void {
  if (!appState.secretStore) {
    sendJson(res, 503, { error: 'Managed secret storage is unavailable.' });
    return;
  }
  sendJson(res, 200, { secrets: appState.secretStore.status() });
}

async function postSecretsHandler(context: RequestContext): Promise<void> {
  if (!context.appState.secretStore) {
    sendJson(context.res, 503, {
      error: 'Managed secret storage is unavailable.',
      requestId: context.requestId,
    });
    return;
  }
  try {
    const payload = await readJsonBody(context.req, 8 * 1024);
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      throw new HttpError(400, 'Managed secrets must be a JSON object.');
    }
    const allowed = new Set([
      'telegramApiHash',
      'openRouterApiKey',
      'auditWebhookToken',
      'alertRelayToken',
      'alertWebhookToken',
      'backupOffsiteToken',
      'backupEncryptionKey',
    ]);
    const entries = Object.entries(payload);
    if (entries.length === 0 || entries.some(([name]) => !allowed.has(name))) {
      throw new HttpError(400, 'The request contains an unsupported managed secret.');
    }
    await context.appState.secretStore.set(payload);
    addLog(`[INFO] request_id=${context.requestId} Managed dashboard secrets updated.`);
    sendJson(context.res, 200, {
      success: true,
      secrets: context.appState.secretStore.status(),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error)));
  }
}

function logsHandler(context: RequestContext): void {
  const afterValue = context.parsedUrl.searchParams.get('after') ?? '0';
  const limitValue = context.parsedUrl.searchParams.get('limit') ?? '1000';
  if (!/^\d+$/.test(afterValue) || !/^\d+$/.test(limitValue)) {
    sendJson(context.res, 400, { error: 'Log cursor and limit must be unsigned integers.' });
    return;
  }
  try {
    const page = getLogEntries(Number(afterValue), Number(limitValue));
    sendJson(context.res, 200, {
      entries: page.entries,
      logs: page.entries.map(entry => entry.line),
      nextCursor: page.nextCursor,
      dropped: page.dropped,
      serverInstanceId,
    });
  } catch (error) {
    sendError(context, error instanceof Error ? new HttpError(400, error.message) : error);
  }
}

function sendDownload(
  res: http.ServerResponse,
  contentType: string,
  filename: string,
  content: string,
): void {
  res.statusCode = 200;
  res.setHeader('Content-Type', `${contentType}; charset=utf-8`);
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.end(content);
}

function requireActor(context: RequestContext): AuthenticatedActor {
  const actor = context.actor;
  if (!actor) throw new HttpError(401, 'Valid dashboard bearer token required.');
  return actor;
}

function accessStatusHandler(context: RequestContext): void {
  const actor = requireActor(context);
  sendJson(context.res, 200, {
    mode: actor.identity?.provider ?? 'bearer',
    role: actor.role,
    actorId: actor.id,
    identity: actor.identity ?? null,
    remoteAccess: {
      provider: actor.identity?.provider ?? null,
      connected: actor.identity?.provider === 'tailscale',
      origin: process.env.DASHBOARD_ALLOWED_ORIGIN?.trim() || null,
    },
  });
}

function metricsHistoryHandler({ res, appState }: RequestContext): void {
  sendJson(res, 200, { history: appState.getMetricsHistory?.() ?? [] });
}

async function incomingMessagesHandler(context: RequestContext): Promise<void> {
  try {
    sendJson(context.res, 200, { messages: await getIncomingMessages(100) });
  } catch (error) {
    sendError(context, error);
  }
}

function signalPageHandler(kind: UiSignalList): ApiHandler {
  return async context => {
    try { sendJson(context.res, 200, await uiSignalPage(kind, context.parsedUrl.searchParams)); }
    catch (error) { sendError(context, new HttpError(400, errorMessage(error))); }
  };
}

async function ingressDetailHandler(context: RequestContext): Promise<void> {
  try {
    const detail = await uiIngressDetail(context.parsedUrl.searchParams.get('id') || '');
    if (!detail) throw new HttpError(404, 'Incoming work not found.');
    sendJson(context.res, 200, detail);
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

async function signalOriginalHandler(context: RequestContext): Promise<void> {
  try {
    const original = await uiSignalOriginal(context.parsedUrl.searchParams);
    if (!original) throw new HttpError(404, 'Stored original not found.');
    sendJson(context.res, 200, original);
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

async function uiDeploymentHandler(context: RequestContext): Promise<void> {
  try { sendJson(context.res, 200, await uiDeployment({ address: context.req.socket.localAddress, port: context.req.socket.localPort })); }
  catch (error) { sendError(context, error); }
}

async function uiAttentionHandler(context: RequestContext): Promise<void> {
  try { sendJson(context.res, 200, await uiAttention(context.parsedUrl.searchParams)); }
  catch (error) { sendError(context, new HttpError(400, errorMessage(error))); }
}

async function processedSignalsHandler(context: RequestContext): Promise<void> {
  try {
    sendJson(context.res, 200, { signals: await getProcessedSignals(100) });
  } catch (error) {
    sendError(context, error);
  }
}

async function dashboardAnalyticsHandler(context: RequestContext): Promise<void> {
  try {
    sendJson(context.res, 200, { analytics: await getSignalDashboardAnalytics() });
  } catch (error) {
    sendError(context, error);
  }
}

async function outboxHandler(context: RequestContext): Promise<void> {
  const getTasks = context.appState.getOutboxTasks;
  if (!getTasks) {
    sendJson(context.res, 503, {
      error: 'Outbox inspection is unavailable.',
      requestId: context.requestId,
    });
    return;
  }
  const allowed = new Set(['pending', 'preparing', 'sending', 'completed', 'failed', 'unknown', 'needs_review']);
  const statuses = (context.parsedUrl.searchParams.get('status') || '')
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean);
  if (statuses.some((status) => !allowed.has(status))) {
    sendJson(context.res, 400, {
      error: 'Invalid outbox status filter.',
      requestId: context.requestId,
    });
    return;
  }
  try {
    sendJson(context.res, 200, {
      tasks: await getTasks(statuses.length > 0 ? statuses : undefined),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error);
  }
}

function requireConfirmation(context: RequestContext, expected: string, message: string): boolean {
  if (context.req.headers['x-destructive-confirmation'] === expected) return true;
  sendJson(context.res, 412, { error: message, requestId: context.requestId });
  return false;
}

function requireTaskId(payload: Record<string, unknown>): string {
  if (typeof payload.id !== 'string' || payload.id.length < 1 || payload.id.length > 256) {
    throw new HttpError(400, 'A valid outbox task id is required.');
  }
  return payload.id;
}

async function retryOutboxHandler(context: RequestContext): Promise<void> {
  const retryTask = context.appState.retryOutboxTask;
  if (!retryTask) {
    sendJson(context.res, 503, {
      error: 'Outbox retry is unavailable.',
      requestId: context.requestId,
    });
    return;
  }
  if (
    !requireConfirmation(
      context,
      'retry-unknown-delivery',
      'Explicit retry-unknown-delivery confirmation header required.'
    )
  )
    return;
  try {
    const retried = await retryTask(requireTaskId(await readJsonBody(context.req)));
    if (!retried) throw new HttpError(409, 'Only failed or unknown outbox tasks can be retried.');
    sendJson(context.res, 202, { success: true, requestId: context.requestId });
  } catch (error) {
    sendError(context, error);
  }
}

async function acknowledgeOutboxHandler(context: RequestContext): Promise<void> {
  const acknowledgeTask = context.appState.acknowledgeOutboxTask;
  if (!acknowledgeTask) {
    sendJson(context.res, 503, {
      error: 'Outbox reconciliation is unavailable.',
      requestId: context.requestId,
    });
    return;
  }
  if (
    !requireConfirmation(
      context,
      'acknowledge-unknown-delivery',
      'Explicit acknowledge-unknown-delivery confirmation header required.'
    )
  )
    return;
  try {
    const payload = await readJsonBody(context.req);
    const id = requireTaskId(payload);
    if (typeof payload.reason !== 'string' || payload.reason.trim().length < 10) {
      throw new HttpError(400, 'A reconciliation reason of at least 10 characters is required.');
    }
    const acknowledged = await acknowledgeTask(id, payload.reason.trim());
    if (!acknowledged) throw new HttpError(409, 'Only unknown outbox tasks can be acknowledged.');
    sendJson(context.res, 200, { success: true, requestId: context.requestId });
  } catch (error) {
    sendError(context, error);
  }
}

async function deleteIncomingHandler(context: RequestContext): Promise<void> {
  const idValue = context.parsedUrl.searchParams.get('id');
  const id = idValue === null ? Number.NaN : Number(idValue);
  if (!Number.isSafeInteger(id) || id < 1) {
    sendJson(context.res, 400, { error: 'Missing or invalid id.' });
    return;
  }
  if (!requireConfirmation(context, 'delete-incoming-message', 'Explicit message deletion confirmation required.')) return;
  try {
    await deleteIncomingMessage(id);
    sendJson(context.res, 200, { success: true });
  } catch (error) {
    sendError(context, error);
  }
}

async function deleteSignalHandler(context: RequestContext): Promise<void> {
  const id = context.parsedUrl.searchParams.get('id');
  if (!id) {
    sendJson(context.res, 400, { error: 'Missing id.' });
    return;
  }
  if (!requireConfirmation(context, 'delete-processed-signal', 'Explicit signal deletion confirmation required.')) return;
  try {
    await deleteProcessedSignal(id);
    sendJson(context.res, 200, { success: true });
  } catch (error) {
    if (error instanceof SignalReferencedError) {
      sendError(context, new HttpError(409, error.message));
      return;
    }
    sendError(context, error);
  }
}

async function controlHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req);
    if (payload.action === 'start') {
      if (
        context.appState.state.isRunning
        || ['connecting', 'authentication-required'].includes(context.appState.state.connectionState)
      ) {
        throw new HttpError(409, 'Routing is already active.');
      }
      context.appState.startForwarding(context.appState.config).catch((error) => {
        addLog(`[ERROR] request_id=${context.requestId} Web start failed: ${error.message}`);
      });
      sendJson(context.res, 202, {
        success: true,
        message: 'Routing start requested.',
        requestId: context.requestId,
      });
      return;
    }
    if (payload.action !== 'stop') throw new HttpError(400, 'Invalid action.');
    const routingStarted = context.appState.state.isRunning
      || ['connecting', 'authentication-required'].includes(context.appState.state.connectionState);
    if (!routingStarted) throw new HttpError(409, 'Routing is not active.');
    await context.appState.stopForwarding();
    sendJson(context.res, 200, {
      success: true,
      message: 'Routing stopped.',
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error);
  }
}

function telegramLoginHandler(context: RequestContext): void {
  sendJson(context.res, 200, {
    telegramLogin: context.appState.getTelegramLoginState?.() ?? { state: 'idle' },
  });
}

async function postTelegramLoginHandler(context: RequestContext): Promise<void> {
  if (!context.appState.submitTelegramLogin) {
    sendJson(context.res, 503, {
      error: 'Telegram web login is unavailable.',
      requestId: context.requestId,
    });
    return;
  }
  try {
    const snapshot = context.appState.submitTelegramLogin(await readJsonBody(context.req, 8 * 1024));
    sendJson(context.res, 202, { telegramLogin: snapshot, requestId: context.requestId });
  } catch (error) {
    sendError(context, new HttpError(400, errorMessage(error)));
  }
}

function getConfigHandler({ res, appState }: RequestContext): void {
  const configuration = publicConfig(appState.config);
  sendJson(res, 200, { ...configuration, configRevision: configurationRevision(configuration) });
}

function applyConfiguration(context: RequestContext, update: unknown, logMessage: string): void {
  const candidateConfig = validateConfig(mergeConfiguration(context.appState.config, update));
  (context.appState.persistConfig ?? writeConfigSync)(candidateConfig);
  Object.assign(context.appState.config, candidateConfig);
  context.appState.reloadConfig();
  context.appState.applyRuntimeConfig(context.appState.config);
  addLog(`[INFO] request_id=${context.requestId} ${logMessage}`);
}

async function postConfigHandler(context: RequestContext): Promise<void> {
  try {
    const newConfig = await readJsonBody(context.req);
    if (!newConfig || typeof newConfig !== 'object' || Array.isArray(newConfig)) {
      throw new HttpError(400, 'Configuration must be a JSON object.');
    }
    if (containsSecretConfig(newConfig)) {
      throw new HttpError(400, 'Secrets must be submitted through the dedicated managed-secret endpoint.');
    }
    const expected = context.req.headers['if-match'];
    if (expected !== undefined && expected !== configurationRevision(publicConfig(context.appState.config))) {
      throw new HttpError(409, 'Configuration changed. Reload and compare before saving.');
    }
    delete newConfig.configRevision;
    applyConfiguration(context, newConfig, 'Dashboard configuration updated.');
    sendJson(context.res, 200, {
      success: true,
      message: 'Configuration saved successfully.',
      configuration: publicConfig(context.appState.config),
      configRevision: configurationRevision(publicConfig(context.appState.config)),
      queue: context.appState.getQueueState(),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error);
  }
}

async function importHandler(context: RequestContext): Promise<void> {
  try {
    const bundle = await readJsonBody(context.req);
    if (!bundle.config || typeof bundle.config !== 'object' || Array.isArray(bundle.config)) {
      throw new HttpError(400, 'Import file does not contain a valid "config" section.');
    }
    if (bundle.env !== undefined || containsSecretConfig(bundle.config)) {
      throw new HttpError(400, 'Imports may contain non-secret configuration only.');
    }
    try {
      assertSetupBundleContainsNoSecrets(bundle.config);
    } catch (error) {
      throw new HttpError(400, errorMessage(error));
    }
    applyConfiguration(context, bundle.config, 'Dashboard configuration imported.');
    sendJson(context.res, 200, {
      success: true,
      message: 'Configuration imported successfully.',
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error);
  }
}

function pruneSetupBundlePreviews(now = Date.now()): void {
  for (const [key, preview] of setupBundlePreviews) {
    if (preview.expiresAt <= now) setupBundlePreviews.delete(key);
  }
}

async function exportSetupBundleHandler(context: RequestContext): Promise<void> {
  try {
    const bundle = await exportPortableSetupBundle(publicConfig(context.appState.config));
    const date = new Date().toISOString().slice(0, 10);
    sendDownload(
      context.res,
      'application/json',
      `tsx-core-setup-${date}.json`,
      JSON.stringify(bundle, null, 2),
    );
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function previewSetupBundleHandler(context: RequestContext): Promise<void> {
  try {
    pruneSetupBundlePreviews();
    if (setupBundlePreviews.size >= 20) throw new HttpError(409, 'Setup preview capacity reached. Apply an existing preview or wait until it expires.');
    const payload = await readJsonBody(context.req, 4 * 1024 * 1024);
    const bundle = validatePortableSetupBundle(payload?.bundle ?? payload);
    const mappings = await suggestPortableAccountMappings(bundle);
    const active = await getActiveWorkflow();
    const key = randomUUID();
    const expiresAt = Date.now() + SETUP_PREVIEW_TTL_MS;
    const current = await withDatabaseTransaction(() => uiSetupCurrentState(publicConfig(context.appState.config)));
    const baseHash = reviewHash(current);
    setupBundlePreviews.set(key, {
      actorId: requireActor(context).id,
      bundle,
      bundleHash: bundle.checksum,
      baseHash,
      expiresAt,
      automaticAccountMappings: mappings.automatic,
    });
    sendJson(context.res, 200, {
      previewKey: key,
      baseHash,
      contentReview: setupContentReview(current, bundle),
      bundleHash: bundle.checksum,
      expiresAt,
      mode: 'replace',
      diff: {
        current: {
          revision: active?.revision ?? null,
          nodes: active?.graph.nodes.length ?? 0,
          edges: active?.graph.edges.length ?? 0,
        },
        imported: {
          nodes: bundle.workflow.graph.nodes.length,
          edges: bundle.workflow.graph.edges.length,
          resources: bundle.workflow.resources.length,
          contracts: bundle.models.contracts.length,
          schemas: bundle.models.schemas.length,
          strategies: bundle.models.strategies.length,
          channelRiskPolicies: bundle.models.channelRiskPolicies.length,
        },
      },
      accountMapping: mappings,
      accountReferences: bundle.accountReferences,
      confirmation: SETUP_APPLY_CONFIRMATION,
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error)));
  }
}

function consumeSetupBundlePreview(payload: Record<string, unknown>, actorId: string): SetupBundlePreview {
  if (typeof payload.previewKey !== 'string' || typeof payload.confirmation !== 'string') {
    throw new HttpError(400, 'Preview key and confirmation are required.');
  }
  if (payload.confirmation !== SETUP_APPLY_CONFIRMATION) {
    throw new HttpError(409, `Setup replacement requires the exact confirmation '${SETUP_APPLY_CONFIRMATION}'.`);
  }
  const preview = setupBundlePreviews.get(payload.previewKey);
  setupBundlePreviews.delete(payload.previewKey);
  if (!preview || preview.expiresAt <= Date.now()) throw new HttpError(409, 'Setup preview is missing or expired.');
  if (preview.actorId !== actorId) throw new HttpError(403, 'Setup preview belongs to another authenticated user.');
  return preview;
}

async function setupReviewTreeHandler(context: RequestContext): Promise<void> {
  if (context.actor?.role !== 'admin') { sendError(context, new HttpError(403, 'Administrator role required.')); return; }
  try {
    const query = context.parsedUrl.searchParams; const key = query.get('key') || '';
    const preview = setupBundlePreviews.get(key);
    if (!preview || preview.expiresAt <= Date.now()) throw new HttpError(409, 'Setup preview is missing or expired.');
    if (preview.actorId !== context.actor.id) throw new HttpError(403, 'Setup preview belongs to another authenticated user.');
    const current = await withDatabaseTransaction(() => uiSetupCurrentState(publicConfig(context.appState.config)));
    if (reviewHash(current) !== preview.baseHash) throw new HttpError(409, 'SETUP_PREVIEW_CONFLICT: Reviewed source changed. Create a new preview.');
    const side = query.get('side') || 'before';
    const values: Record<string, unknown> = { before: current.content, after: setupReviewContent(preview.bundle), library: current.library };
    if (!Object.hasOwn(values, side)) throw new HttpError(400, 'Invalid review side.');
    sendJson(context.res, 200, uiReviewTree(values[side], query, { key, side, baseHash: preview.baseHash, bundleHash: preview.bundleHash }));
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

function setupBundleAccountMappings(payload: Record<string, unknown>, preview: SetupBundlePreview): Record<string, string> {
  if (!payload.accountMappings || typeof payload.accountMappings !== 'object' || Array.isArray(payload.accountMappings)) {
    throw new HttpError(400, 'Account mappings must be an object.');
  }
  const accountMappings = { ...preview.automaticAccountMappings };
  for (const [source, target] of Object.entries(payload.accountMappings)) {
    if (typeof target !== 'string' || source.length > 128 || target.length > 128) {
      throw new HttpError(400, 'Account mapping contains an invalid identifier.');
    }
    accountMappings[source] = target;
  }
  return accountMappings;
}

function activateSetupConfiguration(context: RequestContext, replacement: Config): void {
  // skipcq: JS-0320 - in-place key removal preserves the shared appState.config identity consumed across modules.
  for (const key of Object.keys(context.appState.config)) delete context.appState.config[key];
  Object.assign(context.appState.config, replacement);
  context.appState.reloadConfig();
  context.appState.applyRuntimeConfig(context.appState.config);
}

function restoreSetupConfiguration(context: RequestContext, previousConfig: Config): void {
  (context.appState.persistConfig ?? writeConfigSync)(previousConfig);
  activateSetupConfiguration(context, previousConfig);
}

async function applySetupBundleHandler(context: RequestContext): Promise<void> {
  let previousConfig: Config | null = null;
  let configPersisted = false;
  try {
    pruneSetupBundlePreviews();
    const payload = await readJsonBody(context.req, 256 * 1024);
    const preview = consumeSetupBundlePreview(payload, requireActor(context).id);
    const accountMappings = setupBundleAccountMappings(payload, preview);
    const assertPreviewCurrent = async () => {
      if (reviewHash(await uiSetupCurrentState(publicConfig(context.appState.config))) !== preview.baseHash) {
        throw new HttpError(409, 'SETUP_PREVIEW_CONFLICT: Current configuration, library, account state or workflow changed. Create a new preview.');
      }
    };
    await withDatabaseTransaction(assertPreviewCurrent);
    if (!context.appState.runBackupNow) throw new HttpError(503, 'A verified backup is required before setup replacement.');
    const backupArtifact = await context.appState.runBackupNow();
    previousConfig = structuredClone(context.appState.config);
    const replacementInput = structuredClone(preview.bundle.systemConfig);
    if (containsSecretConfig(replacementInput)) throw new HttpError(400, 'Setup replacement contains forbidden secret configuration.');
    const replacementConfig = validateConfig(replacementInput);
    const result = await applyPortableSetupBundle({
      bundle: preview.bundle,
      accountMappings,
      actorId: requireActor(context).id,
      beforeImport: assertPreviewCurrent,
      beforeCommit: () => {
        (context.appState.persistConfig ?? writeConfigSync)(replacementConfig);
        configPersisted = true;
        activateSetupConfiguration(context, replacementConfig);
      },
    });
    addLog(`[SECURITY] request_id=${context.requestId} Portable setup bundle ${preview.bundleHash} applied after verified backup.`);
    sendJson(context.res, 200, {
      success: true,
      mode: 'replace',
      backupArtifact: path.basename(backupArtifact),
      ...result,
      requestId: context.requestId,
    });
  } catch (error) {
    if (configPersisted && previousConfig) {
      try {
        restoreSetupConfiguration(context, previousConfig);
      } catch (rollbackError) {
        addLog(`[ERROR] request_id=${context.requestId} Setup configuration rollback failed: ${errorMessage(rollbackError)}`);
      }
    }
    sendError(context, error instanceof HttpError ? error : new HttpError(409, errorMessage(error)));
  }
}

function requireCurrentVerifiedBackup(context: RequestContext): void {
  const operations = context.appState.getOperationsStatus?.();
  const backup = operations?.backup;
  if (!hasCurrentRestorableBackup(backup)) {
    throw new HttpError(409, 'A healthy, integrity-verified, configuration-coherent and artifact-local restore-eligible backup with matching SHA proofs no older than 30 minutes is required for this destructive action.');
  }
}

async function factoryResetHandler(context: RequestContext): Promise<void> {
  if (
    !requireConfirmation(
      context,
      'factory-reset',
      'Explicit factory-reset confirmation header required.'
    )
  )
    return;
  try {
    const payload = await readJsonBody(context.req, 4 * 1024);
    if (payload.confirmation !== 'FACTORY RESET') {
      throw new HttpError(412, "Factory reset requires the exact written confirmation 'FACTORY RESET'.");
    }
    if (!context.appState.performFactoryReset || !context.appState.requestRestart) {
      throw new HttpError(503, 'Complete factory reset is unavailable in this runtime.');
    }
    const performFactoryReset = context.appState.performFactoryReset;
    await runRestartCommand(context, {
      id: payload.jobId, kind: 'factory-reset', scope: { service: 'TSX Core' }, request: { confirmation: 'FACTORY RESET' }, status: 200,
      operation: async () => {
        requireCurrentVerifiedBackup(context);
        await performFactoryReset.call(context.appState);
        addLog('[SECURITY] Complete factory reset executed through the web dashboard.');
        return { message: 'Factory reset completed. Restart into first-run setup requested.' };
      },
    });
  } catch (error) {
    sendRestartCommandError(context, error);
  }
}

async function accessTokenHandler(context: RequestContext): Promise<void> {
  if (!context.appState.secretStore) {
    sendJson(context.res, 503, { error: 'Managed secret storage is unavailable.', requestId: context.requestId });
    return;
  }
  try {
    const payload = await readJsonBody(context.req, 4 * 1024);
    if (payload?.role !== 'admin' && payload?.role !== 'viewer') {
      throw new HttpError(400, 'Access-token role must be admin or viewer.');
    }
    const token = await context.appState.secretStore.rotateDashboardToken(payload.role);
    if (payload.role === 'admin') context.authenticator.revokeLocalAdminSessions?.();
    addLog(`[SECURITY] request_id=${context.requestId} Dashboard ${payload.role} token rotated.`);
    sendJson(context.res, 201, {
      token,
      role: payload.role,
      shownOnce: true,
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error instanceof HttpError ? error : new HttpError(409, errorMessage(error)));
  }
}

async function disableViewerTokenHandler(context: RequestContext): Promise<void> {
  if (!requireConfirmation(context, 'disable-viewer-token', 'Explicit viewer-token disable confirmation required.')) return;
  if (!context.appState.secretStore) {
    sendJson(context.res, 503, { error: 'Managed secret storage is unavailable.', requestId: context.requestId });
    return;
  }
  try {
    await context.appState.secretStore.removeDashboardViewerToken();
    addLog(`[SECURITY] request_id=${context.requestId} Dashboard viewer token disabled.`);
    sendJson(context.res, 200, { success: true, requestId: context.requestId });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

function operationsHandler({ res, appState }: RequestContext): void {
  sendJson(res, 200, {
    operations: appState.getOperationsStatus?.() ?? {},
  });
}

async function backupJobArtifact(context: RequestContext) {
  if (!context.appState.runBackupNow) throw new HttpError(503, 'Backup control is unavailable.');
  return { artifactName: path.basename(await context.appState.runBackupNow()) };
}

async function recoveredBackupJobArtifact(context: RequestContext, objectName: string) {
  if (!context.appState.recoverOffsiteBackup) throw new HttpError(503, 'Off-site backup recovery is unavailable.');
  return { artifactName: await context.appState.recoverOffsiteBackup(objectName) };
}

function runBackupDrillJob(context: RequestContext, name: string) {
  if (!context.appState.runBackupDrill) throw new HttpError(503, 'Isolated restore drills are unavailable.');
  return context.appState.runBackupDrill(name);
}

async function runBackupHandler(context: RequestContext): Promise<void> {
  if (!context.appState.runBackupNow) {
    sendJson(context.res, 503, { error: 'Backup control is unavailable.', requestId: context.requestId });
    return;
  }
  try {
    const jobId = context.req.headers['x-operator-job-id'];
    if (typeof jobId === 'string') {
      const store = context.appState.uiOperations;
      if (!store) throw new HttpError(503, 'Durable operator jobs are unavailable.');
      const accepted = await store.accept({ id: jobId, kind: 'backup-create', actorId: requireActor(context).id, scope: { database: 'current', configuration: 'current' }, request: { action: 'backup-create' } });
      sendJson(context.res, 202, { job: accepted.job, created: accepted.created, requestId: context.requestId });
      if (accepted.created) store.run(jobId, () => backupJobArtifact(context)).catch(error => addLog(`[ERROR] Backup job persistence failed: ${errorMessage(error)}`));
      return;
    }
    const artifact = await context.appState.runBackupNow();
    sendJson(context.res, 201, { success: true, artifact: path.basename(artifact), requestId: context.requestId });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function replayAuditHandler(context: RequestContext): Promise<void> {
  if (!requireConfirmation(context, 'replay-audit', 'Explicit audit replay confirmation required.')) return;
  if (!context.appState.auditTrail) {
    sendJson(context.res, 503, { error: 'Audit control is unavailable.', requestId: context.requestId });
    return;
  }
  try {
    const replayed = await context.appState.auditTrail.replayRemote();
    sendJson(context.res, 200, { success: true, replayed, requestId: context.requestId });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

function runtimeSettingsHandler({ res, appState }: RequestContext): void {
  if (!appState.runtimeSettings) {
    sendJson(res, 503, { error: 'Managed runtime settings are unavailable.' });
    return;
  }
  sendJson(res, 200, { settings: appState.runtimeSettings.snapshot(), ...appState.runtimeSettings.describe?.() });
}

function availableRecoveryRepairs(appState: WebServerState, actor: RequestContext['actor']): string[] {
  if (actor?.role !== 'admin') return [];
  return ['config', ...(appState.secretStore ? ['secrets'] : []),
    ...(appState.runtimeSettings && appState.secretStore ? ['runtime-settings'] : []), ...(appState.requestRestart ? ['restart'] : [])];
}
async function recoveryStatusHandler({ res, appState, actor }: RequestContext): Promise<void> {
  sendJson(res, 200, {
    contractVersion: 1,
    backendVersion: await serverVersion,
    observedAt: Date.now(),
    serverInstanceId,
    session: { role: actor?.role, actorId: actor?.id, provider: actor?.identity?.provider ?? 'bearer' },
    active: appState.recovery?.active === true,
    issues: appState.recovery?.issues ?? [],
    restartRequired: appState.recovery?.active === true,
    startup: appState.startupAuthority?.snapshot() ?? null,
    availableRepairs: availableRecoveryRepairs(appState, actor),
  });
}

async function postRuntimeSettingsHandler(context: RequestContext): Promise<void> {
  if (!context.appState.runtimeSettings || !context.appState.secretStore) {
    sendJson(context.res, 503, { error: 'Managed runtime settings are unavailable.', requestId: context.requestId });
    return;
  }
  try {
    const payload = await readJsonBody(context.req, 128 * 1024);
    if (payload?.enterpriseMode === true) {
      const secrets = context.appState.secretStore.status();
      const missing = ['auditWebhookToken', 'alertRelayToken', 'alertWebhookToken', 'backupOffsiteToken', 'backupEncryptionKey']
        .filter((name) => !secrets[name as keyof typeof secrets]?.configured);
      if (missing.length > 0) {
        throw new HttpError(409, `Enterprise mode requires configured managed secrets: ${missing.join(', ')}.`);
      }
    }
    const expected = context.req.headers['if-match'];
    const settings = await context.appState.runtimeSettings.set(payload, typeof expected === 'string' ? expected : undefined);
    if (!settings.dashboardLocalTrust || settings.enterpriseMode || settings.dashboardAuthMode !== 'token') {
      context.authenticator.revokeLocalAdminSessions?.();
    }
    addLog(`[SECURITY] request_id=${context.requestId} Managed runtime settings updated; restart required.`);
    sendJson(context.res, 200, { success: true, settings, ...context.appState.runtimeSettings.describe?.(), restartRequired: true, requestId: context.requestId });
  } catch (error) {
    const statusCode = errorMessage(error).includes('Runtime settings changed') ? 409 : 400;
    sendError(context, error instanceof HttpError ? error : new HttpError(statusCode, errorMessage(error)));
  }
}

async function restartHandler(context: RequestContext): Promise<void> {
  if (!requireConfirmation(context, 'restart-service', 'Explicit service restart confirmation required.')) return;
  if (!context.appState.requestRestart) {
    sendJson(context.res, 503, { error: 'Service restart is unavailable.', requestId: context.requestId });
    return;
  }
  try {
    await runRestartCommand(context, {
      id: context.req.headers['x-operator-job-id'], kind: 'restart', scope: { service: 'TSX Core' }, request: { action: 'restart' }, status: 202,
      operation: async () => {
        if (context.appState.state.isRunning) await context.appState.stopForwarding();
        return { message: 'Container restart requested.' };
      },
    });
  } catch (error) {
    sendRestartCommandError(context, error);
  }
}

const restartCoordinators = new WeakMap<WebServerState, UiRestartCoordinator>();

function restartCoordinator(app: WebServerState): UiRestartCoordinator {
  if (!app.uiOperations || !app.requestRestart) throw new HttpError(503, 'Durable restart coordination is unavailable.');
  let coordinator = restartCoordinators.get(app);
  if (!coordinator) {
    coordinator = new UiRestartCoordinator(app.uiOperations, app.requestRestart);
    restartCoordinators.set(app, coordinator);
  }
  return coordinator;
}

async function runRestartCommand(context: RequestContext, command: {
  id: unknown; kind: UiJobKind; scope: Record<string, unknown>; request: unknown; status: number;
  operation: () => Promise<Record<string, unknown>>;
}): Promise<void> {
  const coordinator = restartCoordinator(context.appState);
  const store = context.appState.uiOperations;
  if (!store) throw new HttpError(503, 'Operator store is unavailable.');
  const id = command.id ?? randomUUID();
  if (typeof id !== 'string') throw new HttpError(400, 'Invalid operator job ID.');
  // Lookup may cross a maintenance hold, but creating/executing a new destructive
  // command still requires the original startup gate. accept verifies the actor and payload.
  if (!(await store.get(id))) assertStartupMutationAllowed(context, 'POST');
  const accepted = await store.accept({ id, kind: command.kind, actorId: requireActor(context).id, scope: command.scope, request: command.request });
  const job = accepted.created ? await store.runRestart(id, command.operation) : accepted.job;
  coordinator.schedule(job, context.res);
  const restartScheduled = job.restart?.sourceInstanceId === store.processInstanceId;
  if (!accepted.created) {
    sendJson(context.res, 202, { job, replayed: true, restartScheduled, serverInstanceId, requestId: context.requestId });
    return;
  }
  sendJson(context.res, command.status, { ...(job.result as Record<string, unknown>), success: true, job, restartScheduled,
    receiptUncertain: job.restart?.receipt === 'uncertain', serverInstanceId, requestId: context.requestId });
}

function sendRestartCommandError(context: RequestContext, error: unknown): void {
  sendError(context, error instanceof HttpError ? error : new HttpError(409, errorMessage(error)));
}

function backupArtifactName(value: unknown): string {
  if (typeof value !== 'string' || !/^backup-\d{4}-[a-zA-Z0-9_.:-]{1,160}$/.test(value)) {
    throw new HttpError(400, 'Invalid backup artifact name.');
  }
  return value;
}

function offsiteBackupObjectName(value: unknown): string {
  if (typeof value !== 'string' || !/^backup-\d{4}-[a-zA-Z0-9_.:-]{1,160}\.tgfb$/.test(value)) {
    throw new HttpError(400, 'Invalid off-site backup object name.');
  }
  return value;
}

async function backupsHandler(context: RequestContext): Promise<void> {
  if (!context.appState.listBackups) {
    sendJson(context.res, 503, { error: 'Backup inventory is unavailable.' });
    return;
  }
  try {
    sendJson(context.res, 200, { backups: await context.appState.listBackups() });
  } catch (error) {
    sendError(context, error);
  }
}

async function verifyBackupHandler(context: RequestContext): Promise<void> {
  if (!context.appState.verifyBackup) {
    sendJson(context.res, 503, { error: 'Backup verification is unavailable.' });
    return;
  }
  try {
    const name = backupArtifactName(context.parsedUrl.searchParams.get('name'));
    const evidence = await context.appState.verifyBackup(name);
    sendJson(context.res, 200, { success: true, name, evidence });
  } catch (error) {
    sendError(context, error);
  }
}

async function recoverOffsiteBackupHandler(context: RequestContext): Promise<void> {
  if (!requireConfirmation(context, 'recover-offsite-backup', 'Explicit off-site recovery confirmation required.')) return;
  if (!context.appState.recoverOffsiteBackup) {
    sendJson(context.res, 503, { error: 'Off-site backup recovery is unavailable.', requestId: context.requestId });
    return;
  }
  try {
    const payload = await readJsonBody(context.req, 4 * 1024);
    const objectName = offsiteBackupObjectName(payload.objectName);
    if (payload.jobId !== undefined) {
      const store = context.appState.uiOperations;
      if (!store) throw new HttpError(503, 'Durable operator jobs are unavailable.');
      const accepted = await store.accept({ id: payload.jobId as string, kind: 'backup-recover', actorId: requireActor(context).id, scope: { objectName }, request: { objectName } });
      sendJson(context.res, 202, { job: accepted.job, created: accepted.created, requestId: context.requestId });
      if (accepted.created) store.run(accepted.job.id, () => recoveredBackupJobArtifact(context, objectName)).catch(error => addLog(`[ERROR] Offsite recovery job persistence failed: ${errorMessage(error)}`));
      return;
    }
    const artifactName = await context.appState.recoverOffsiteBackup(objectName);
    sendJson(context.res, 201, { success: true, objectName, artifactName, requestId: context.requestId });
  } catch (error) {
    sendError(context, error);
  }
}

async function restoreBackupHandler(context: RequestContext): Promise<void> {
  if (!requireConfirmation(context, 'restore-backup', 'Explicit backup restore confirmation required.')) return;
  if (!context.appState.restoreBackup || !context.appState.requestRestart) {
    sendJson(context.res, 503, { error: 'Backup restore is unavailable.', requestId: context.requestId });
    return;
  }
  const restoreBackup = context.appState.restoreBackup;
  try {
    const payload = await readJsonBody(context.req, 4 * 1024);
    const name = backupArtifactName(payload.name);
    await runRestartCommand(context, {
      id: payload.jobId, kind: 'backup-restore', scope: { artifactName: name }, request: { name }, status: 200,
      operation: async () => {
        const restored = await restoreBackup.call(context.appState, name);
        return { name, artifactName: name, rollbackPreserved: Boolean(restored.previousDatabase || restored.previousConfig) };
      },
    });
  } catch (error) {
    sendRestartCommandError(context, error);
  }
}

async function clearDatabaseHandler(context: RequestContext): Promise<void> {
  if (
    !requireConfirmation(
      context,
      'clear-database',
      'Explicit clear-database confirmation header required.'
    )
  )
    return;
  try {
    const payload = await readJsonBody(context.req, 4 * 1024);
    if (payload.confirmation !== 'DATENBANK LEEREN') {
      throw new HttpError(412, "Database clearing requires the exact written confirmation 'DATENBANK LEEREN'.");
    }
    requireCurrentVerifiedBackup(context);
    const routingStopped = Boolean(context.appState.state.isRunning);
    if (routingStopped) await context.appState.stopForwarding();
    if (context.appState.state.isRunning) {
      throw new HttpError(409, 'Routing could not be stopped safely; no database data was deleted.');
    }
    const cleared = await clearDb();
    addLog(`[INFO] request_id=${context.requestId} Operational SQLite data cleared through the web dashboard; retained_trading_signals=${cleared.retainedTradingSignals}.`);
    sendJson(context.res, 200, {
      success: true,
      message: 'Operational database data cleared successfully; trading state was preserved.',
      routingStopped,
      cleared,
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error);
  }
}

function requireTradingControl(context: RequestContext): TradingWebControl {
  if (!context.appState.tradingControl) throw new HttpError(503, 'Trading control is unavailable in this runtime.');
  return context.appState.tradingControl;
}

async function tradingSnapshotHandler(context: RequestContext): Promise<void> {
  try {
    if (context.parsedUrl.searchParams.get('view') === 'cockpit') { sendJson(context.res, 200, await uiCockpit()); return; }
    if (context.parsedUrl.searchParams.get('view') === 'overview') {
      sendJson(context.res, 200, await requireTradingControl(context).operatorOverview()); return;
    }
    if (context.parsedUrl.searchParams.get('view') === 'accounts') {
      const control = requireTradingControl(context);
      try { sendJson(context.res, 200, await control.accountPage(context.parsedUrl.searchParams)); }
      catch (error) { throw new HttpError(400, errorMessage(error)); }
      return;
    }
    const snapshot = await requireTradingControl(context).snapshot();
    const configuredChannels = Array.isArray(context.appState.config?.sourceChannels)
      ? context.appState.config.sourceChannels.map((channel: unknown) => {
          const record = channel as { id?: unknown; channelId?: unknown; name?: unknown; title?: unknown } | null | undefined;
          return {
            id: String(record?.id ?? record?.channelId ?? channel),
            name: String(record?.name ?? record?.title ?? record?.id ?? channel),
          };
        })
      : [];
    sendJson(context.res, 200, { ...snapshot, configuredChannels });
  } catch (error) {
    sendError(context, error);
  }
}

async function tradingPortfolioHandler(context: RequestContext): Promise<void> {
  try {
    const refresh = context.parsedUrl.searchParams.get('refresh') === 'true';
    sendJson(context.res, 200, await requireTradingControl(context).portfolioSnapshot(refresh));
  } catch (error) {
    sendError(context, error);
  }
}

function analyticsQueryValues(context: RequestContext, name: string): string[] {
  const values = context.parsedUrl.searchParams.getAll(name)
    .flatMap(value => value.split(','))
    .map(value => value.trim())
    .filter(Boolean);
  if (values.length > 100 || values.some(value => value.length > 128 || /[\r\n\0]/.test(value))) {
    throw new HttpError(400, `Trading analytics ${name} filter is invalid.`);
  }
  return [...new Set(values)];
}

async function tradingAnalyticsHandler(context: RequestContext): Promise<void> {
  try {
    const now = Date.now();
    const since = Number(context.parsedUrl.searchParams.get('since') ?? now - 90 * 86_400_000);
    const until = Number(context.parsedUrl.searchParams.get('until') ?? now);
    if (!Number.isSafeInteger(since) || !Number.isSafeInteger(until) || since < 0 || since > until || until > now + 60_000) {
      throw new HttpError(400, 'Trading analytics time range is invalid.');
    }
    const exchanges = analyticsQueryValues(context, 'exchange');
    const modes = analyticsQueryValues(context, 'mode');
    try {
      exchanges.forEach(tradingExchangeId);
    } catch {
      throw new HttpError(400, 'Trading analytics exchange filter is invalid.');
    }
    if (modes.some(value => !['paper', 'testnet', 'live'].includes(value))) {
      throw new HttpError(400, 'Trading analytics mode filter is invalid.');
    }
    const statuses = analyticsQueryValues(context, 'status');
    if (statuses.some(status => !(JOURNAL_INTENT_STATUSES as readonly string[]).includes(status))) throw new HttpError(400, 'Trading analytics requires an intent status.');
    sendJson(context.res, 200, await getFilteredTradingAnalytics({
      since,
      until,
      channelIds: analyticsQueryValues(context, 'channelId'),
      accountIds: analyticsQueryValues(context, 'accountId'),
      exchanges,
      modes,
      statuses,
    }));
  } catch (error) {
    sendError(context, error);
  }
}

async function tradingMutation(
  context: RequestContext,
  operation: (control: TradingWebControl, payload: Record<string, unknown>) => unknown,
  statusCode = 200,
): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 256 * 1024);
    const result = await operation(requireTradingControl(context), payload);
    sendJson(context.res, statusCode, { success: true, result, requestId: context.requestId });
  } catch (error) {
    sendError(context, error instanceof HttpError ? error : new HttpError(409, errorMessage(error)));
  }
}

const createTradingStrategyHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.createStrategy(payload), 201);
const updateTradingStrategyHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.updateStrategy(payload));
const publishTradingStrategyHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.publishStrategy(payload.id));
const archiveTradingStrategyHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.archiveStrategy(payload.id));
const deleteTradingStrategyHandler = async (context: RequestContext) => {
  if (!requireConfirmation(
    context,
    'delete-trading-strategy',
    'Explicit trading strategy deletion confirmation required.',
  )) return;
  await tradingMutation(context, (control, payload) => control.removeStrategy(payload.id));
};
const createTradingSignalSchemaHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.createSignalSchema(payload), 201);
const updateTradingSignalSchemaHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.updateSignalSchema(payload));
const deleteTradingSignalSchemaHandler = async (context: RequestContext) => {
  if (!requireConfirmation(
    context,
    'delete-trading-signal-schema',
    'Explicit trading signal schema deletion confirmation required.',
  )) return;
  await tradingMutation(context, (control, payload) => control.removeSignalSchema(payload.id));
};
const createSignalContractHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.createSignalContract(payload), 201);
const createSignalContractVersionHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.createSignalContractVersion(payload), 201);
const updateSignalContractHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.updateSignalContract(payload));
const duplicateSignalContractHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.duplicateSignalContract(payload), 201);
const publishSignalContractHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.publishSignalContract(payload.versionId));
const archiveSignalContractHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.archiveSignalContract(payload.versionId));
const deleteSignalContractDraftHandler = async (context: RequestContext) => {
  if (!requireConfirmation(
    context,
    'delete-signal-contract-draft',
    'Explicit signal contract draft deletion confirmation required.',
  )) return;
  await tradingMutation(context, (control, payload) => control.removeSignalContractDraft(payload.versionId));
};
const deleteSignalContractVersionHandler = async (context: RequestContext) => {
  if (!requireConfirmation(
    context,
    'delete-signal-contract-version',
    'Explicit published signal contract deletion confirmation required.',
  )) return;
  await tradingMutation(context, (control, payload) => control.removeSignalContractVersion(payload.versionId));
};
const validateSignalContractHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.validateSignalContract(payload));
const setChannelRiskPolicyHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.setChannelRiskPolicy(payload));
const deleteChannelRiskPolicyHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.removeChannelRiskPolicy(payload.channelId));
const createTradingAccountHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.createAccount(payload), 201);
const replaceTradingCredentialsHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.replaceAccountCredentials(payload));
const verifyTradingAccountHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.verifyAccount(payload.id));
const updateTradingAccountHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.setAccountEnabled(payload.id, payload.enabled));
const configureTradingAccountHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.configureAccount(payload));
const releaseTradingAccountKillSwitchHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.releaseAccountKillSwitch(payload));
const deleteTradingAccountHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.removeAccount(payload.id));
const setTradingRouteHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.setRoute(payload));
const deleteTradingRouteHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.removeRoute(payload.channelId));
const updateTradingRuntimeHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.setRuntime(payload));
const configurePaperTradingHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.configurePaper(payload));
const reconcileTradingHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.reconcile(payload.accountId));
const cancelTradingEntriesHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.cancelEntries(payload.accountId));
const emergencyFlattenHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.emergencyFlatten(payload));
const acknowledgeTradingRiskHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.acknowledgeRisk(payload.id));

async function workflowSnapshotHandler(context: RequestContext): Promise<void> {
  try {
    const [workflow, resources, fallbackRuns] = await Promise.all([
      getActiveWorkflow(), listWorkflowResources(), listWorkflowFallbackRuns(200),
    ]);
    sendJson(context.res, 200, { workflow, resources, fallbackRuns, requestId: context.requestId });
  } catch (error) {
    sendError(context, error);
  }
}

async function uiWorkflowObjectsHandler(context: RequestContext): Promise<void> {
  try {
    const query = context.parsedUrl.searchParams; const kind = query.get('kind') as UiWorkflowList;
    if (!['resources', 'paths', 'revisions'].includes(kind)) throw new HttpError(400, 'Invalid workflow object kind.');
    const idParam = query.get('id');
    const result = idParam !== null ? await uiWorkflowDetail(kind, idParam) : await uiWorkflowPage(kind, query);
    if (!result) throw new HttpError(404, 'Workflow object not found.');
    sendJson(context.res, 200, result);
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

async function uiWorkflowModelsHandler(context: RequestContext): Promise<void> {
  try {
    if (context.req.method === 'GET') {
      const query = context.parsedUrl.searchParams;
      const result = query.has('id') ? await uiModelDetail(query.get('kind'), query.get('id')) : await uiModelPage(query.get('kind'), query);
      if (!result) throw new HttpError(404, 'Workflow model not found.');
      sendJson(context.res, 200, result);
    } else {
      if (!requireConfirmation(context, 'mutate-workflow-model', 'Explicit reviewed model action required.')) return;
      sendJson(context.res, 200, await mutateUiModel((await readJsonBody(context.req, 4096)) as Parameters<typeof mutateUiModel>[0]));
    }
  } catch (error) {
    const statusCode = context.req.method === 'GET' ? 400 : 409;
    sendError(context, error instanceof HttpError ? error : new HttpError(statusCode, errorMessage(error)));
  }
}

async function uiSearchHandler(context: RequestContext): Promise<void> {
  try {
    const encoded = context.req.headers['x-ui-search'];
    if (typeof encoded !== 'string' || encoded.length > 800) throw new HttpError(400, 'Bounded search header required.');
    const query = context.parsedUrl.searchParams;
    sendJson(context.res, 200, await uiSearch(decodeURIComponent(encoded), query.get('kind') || 'all', query.get('cursor')));
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

async function workflowHistoryStatusHandler(context: RequestContext): Promise<void> {
  if (context.actor?.role !== 'admin') {
    sendJson(context.res, 403, { error: 'Administrator role required.', requestId: context.requestId });
    return;
  }
  try {
    sendJson(context.res, 200, await getWorkflowBuilderHistoryStatus());
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function saveWorkflowHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 2 * 1024 * 1024);
    const input: Parameters<typeof saveWorkflowRevision>[0] = {
      baseRevisionId: (payload.baseRevisionId ?? null) as string | null,
      graph: payload.graph,
      actorId: context.actor?.id || 'dashboard:admin',
      confirmation: (payload.confirmation ?? null) as string | null,
      history: { mode: 'record', label: payload.historyLabel as string },
    };
    const result = await withDatabaseTransaction(async () => {
      const activation = payload.draft ? await activateUiWorkflowDraft(input, payload.draft as { id: string; version: number }) : { workflow: await saveWorkflowRevision(input) };
      return { ...activation, history: await getWorkflowBuilderHistoryStatus() };
    });
    sendJson(context.res, 201, { success: true, ...result, requestId: context.requestId });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function previewWorkflowHistoryImpactHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 64 * 1024);
    const impact = await previewWorkflowBuilderHistoryImpact({
      direction: payload.direction as Parameters<typeof applyWorkflowBuilderHistory>[0]['direction'],
      baseRevisionId: (payload.baseRevisionId ?? null) as string | null,
    });
    sendJson(context.res, 200, { success: true, impact, requestId: context.requestId });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function applyWorkflowHistoryHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 64 * 1024);
    const result = await applyWorkflowBuilderHistory({
      direction: payload.direction as Parameters<typeof applyWorkflowBuilderHistory>[0]['direction'],
      baseRevisionId: (payload.baseRevisionId ?? null) as string | null,
      actorId: context.actor?.id || 'dashboard:admin',
      confirmation: (payload.confirmation ?? null) as string | null,
    });
    if (context.mutationAudit) context.mutationAudit.target = result.audit;
    sendJson(context.res, 200, {
      success: true,
      workflow: result.workflow,
      history: result.history,
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function resetWorkflowHistoryHandler(context: RequestContext): Promise<void> {
  if (!requireConfirmation(
    context,
    'reset-workflow-history',
    'Explicit workflow-history reset confirmation required.',
  )) return;
  try {
    const payload = await readJsonBody(context.req, 4 * 1024);
    if (payload.confirmation !== 'WORKFLOW-HISTORIE ZURÜCKSETZEN') {
      throw new HttpError(
        412,
        "Workflow history reset requires the exact written confirmation 'WORKFLOW-HISTORIE ZURÜCKSETZEN'.",
      );
    }
    const activeWorkflow = await getActiveWorkflow();
    await clearWorkflowBuilderHistory('administrator recovery reset');
    const history = await getWorkflowBuilderHistoryStatus();
    if (context.mutationAudit) {
      context.mutationAudit.target = {
        reason: 'administrator recovery reset',
        activeWorkflowRevisionId: activeWorkflow?.id ?? null,
      };
    }
    sendJson(context.res, 200, { success: true, history, requestId: context.requestId });
  } catch (error) {
    sendError(context, error);
  }
}

async function previewWorkflowImpactHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 2 * 1024 * 1024);
    sendJson(context.res, 200, {
      success: true,
      impact: await previewWorkflowImpact({
        baseRevisionId: (payload.baseRevisionId ?? null) as string | null,
        graph: payload.graph,
      }),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function exchangeCatalogHandler(context: RequestContext): Promise<void> {
  try {
    const catalog = await requireTradingControl(context).exchangeCatalog();
    sendJson(context.res, 200, { ...catalog, requestId: context.requestId });
  } catch (error) {
    sendError(context, new HttpError(503, `Exchange catalog unavailable: ${errorMessage(error)}`));
  }
}

const probeExchangeHandler = (context: RequestContext) =>
  tradingMutation(context, (control, payload) => control.probeExchange(payload.exchange));

async function simulateWorkflowHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 256 * 1024);
    if (typeof payload.channelId !== 'string' || typeof payload.text !== 'string') {
      throw new HttpError(400, 'channelId and text are required.');
    }
    sendJson(context.res, 200, { success: true, result: await simulateWorkflow(payload as Parameters<typeof simulateWorkflow>[0]), requestId: context.requestId });
  } catch (error) {
    sendError(context, error instanceof HttpError ? error : new HttpError(409, errorMessage(error)));
  }
}

async function createWorkflowResourceHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 256 * 1024);
    sendJson(context.res, 201, {
      success: true,
      resource: await createWorkflowResourceDraft(payload as Parameters<typeof createWorkflowResourceDraft>[0]),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function updateWorkflowResourceHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 256 * 1024);
    sendJson(context.res, 200, {
      success: true,
      resource: await updateWorkflowResourceDraft(payload.id as string, payload as Parameters<typeof updateWorkflowResourceDraft>[1]),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function publishWorkflowResourceHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 8 * 1024);
    if (payload.publishDependencies === true) {
      if (!requireConfirmation(context, 'publish-workflow-dependencies', 'Explicit publication of resource and referenced model required.')) return;
      const result = await publishUiResourceWithDependency(payload.id as string, payload.baseEditRevision as number, payload.publicationHash);
      sendJson(context.res, 200, { success: true, ...result, requestId: context.requestId });
      return;
    }
    sendJson(context.res, 200, {
      success: true,
      resource: await publishWorkflowResource(payload.id as string, Date.now(), payload.baseEditRevision as number | undefined),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function deleteWorkflowResourceHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 8 * 1024);
    const operation = payload.operation ?? 'archive';
    if (operation !== 'archive' && operation !== 'delete') {
      throw new HttpError(400, 'Workflow resource operation must be archive or delete.');
    }
    const confirmation = operation === 'delete'
      ? 'delete-workflow-resource-permanently'
      : 'delete-workflow-resource';
    const message = operation === 'delete'
      ? 'Explicit permanent workflow resource deletion confirmation required.'
      : 'Explicit workflow resource archival confirmation required.';
    if (!requireConfirmation(context, confirmation, message)) return;
    if (typeof payload.resourceId === 'string') {
      if (operation === 'delete') {
        const deleted = await deleteWorkflowResourceFamily(payload.resourceId);
        sendJson(context.res, 200, { success: true, result: { deleted }, requestId: context.requestId });
        return;
      }
      const archived = await archiveWorkflowResourceFamily(payload.resourceId);
      sendJson(context.res, 200, { success: true, result: { archived }, requestId: context.requestId });
      return;
    }
    if (operation === 'delete') {
      throw new Error('Permanent workflow resource deletion requires a logical resource identifier.');
    }
    const resource = (await listWorkflowResources()).find(item => item.id === payload.id);
    if (!resource) throw new Error('Workflow resource does not exist.');
    const result = resource.status === 'draft'
      ? { deleted: await deleteWorkflowResourceDraft(resource.id) }
      : { archived: await archiveWorkflowResource(resource.id) };
    sendJson(context.res, 200, { success: true, result, requestId: context.requestId });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

function configuredMcpEndpoint(): string | null {
  const value = process.env.MCP_ENDPOINT_URL?.trim();
  if (!value) return null;
  try {
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.hash) return null;
    return url.toString();
  } catch {
    return null;
  }
}

function journalFilters(context: RequestContext): TradeJournalFilters {
  const query = context.parsedUrl.searchParams;
  const timestamp = (name: string): number | undefined => {
    const value = query.get(name);
    if (!value) return undefined;
    const parsed = Number(value);
    if (!Number.isSafeInteger(parsed) || parsed < 0) throw new HttpError(400, `${name} is invalid.`);
    return parsed;
  };
  const reviewedValue = query.get('reviewed');
  if (reviewedValue && reviewedValue !== 'true' && reviewedValue !== 'false') {
    throw new HttpError(400, 'reviewed must be true or false.');
  }
  const limitValue = query.get('limit');
  return {
    from: timestamp('from'),
    to: timestamp('to'),
    accountId: query.get('accountId') || undefined,
    channelId: query.get('channelId') || undefined,
    symbol: query.get('symbol') || undefined,
    status: query.get('status') || undefined,
    reviewed: reviewedValue ? reviewedValue === 'true' : undefined,
    limit: limitValue ? Number(limitValue) : undefined,
  };
}

async function tradingJournalHandler(context: RequestContext): Promise<void> {
  try {
    const page = await listTradeJournalPage(journalFilters(context), context.parsedUrl.searchParams.get('cursor'));
    sendJson(context.res, 200, {
      ...page, entries: context.parsedUrl.searchParams.get('view') === 'summary' ? page.entries.map(uiJournalSummary) : page.entries,
      redacted: true,
    });
  } catch (error) {
    sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error)));
  }
}

async function tradingJournalExportHandler(context: RequestContext): Promise<void> {
  try {
    const page = await listTradeJournalPage(journalFilters(context), context.parsedUrl.searchParams.get('cursor'));
    const entries = page.entries;
    context.res.setHeader('X-Export-Scope', 'page');
    context.res.setHeader('X-Export-Count', String(entries.length));
    const date = new Date().toISOString().slice(0, 10);
    const format = context.parsedUrl.searchParams.get('format') || 'json';
    if (format === 'csv') {
      sendDownload(context.res, 'text/csv', `tsx-core-trade-journal-${date}.csv`, tradeJournalCsv(entries));
      return;
    }
    if (format !== 'json') throw new HttpError(400, 'Journal export format must be json or csv.');
    sendDownload(
      context.res,
      'application/json',
      `tsx-core-trade-journal-${date}.json`,
      JSON.stringify({ exportedAt: Date.now(), redacted: true, scope: 'page', ...page }, null, 2),
    );
  } catch (error) {
    sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error)));
  }
}

const updateTradingJournalHandler = (context: RequestContext) =>
  tradingMutation(context, async (_control, payload) => uiJournalDetail(await updateTradeJournalReview(payload as Parameters<typeof updateTradeJournalReview>[0])));

async function tradingIntentDetailHandler(context: RequestContext): Promise<void> {
  try {
    const id = context.parsedUrl.searchParams.get('id');
    if (!id || id.length > 64 || /[\r\n\0]/.test(id)) throw new HttpError(400, 'Valid intent ID required.');
    const [entry] = await listTradeJournal({ intentId: id, limit: 1 });
    if (!entry) throw new HttpError(404, 'Trade intent not found.');
    sendJson(context.res, 200, { contractVersion: 1, observedAt: Date.now(), redacted: true, entry: uiJournalDetail(entry), safety: await uiTradeSafety(id, entry.accountId) });
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

async function uiTradeRelationsHandler(context: RequestContext): Promise<void> {
  try {
    const query = context.parsedUrl.searchParams;
    const result = await uiTradeRelationPage(query.get('intentId') ?? '', query.get('kind') as UiTradeRelation, query);
    if (!result) throw new HttpError(404, 'Trade intent not found.');
    sendJson(context.res, 200, result);
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

async function uiTradingListHandler(context: RequestContext): Promise<void> {
  try { sendJson(context.res, 200, await uiTradingPage(context.parsedUrl.searchParams.get('kind') as UiTradingList, context.parsedUrl.searchParams)); }
  catch (error) { sendError(context, new HttpError(400, errorMessage(error))); }
}

async function uiAccountDetailHandler(context: RequestContext): Promise<void> {
  try {
    const result = await uiAccountDetail(context.parsedUrl.searchParams.get('id') ?? '');
    if (!result) throw new HttpError(404, 'Account not found.');
    sendJson(context.res, 200, result);
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

async function uiAccountEvidenceHandler(context: RequestContext): Promise<void> {
  try {
    const query = context.parsedUrl.searchParams; const id = query.get('accountId') ?? ''; const kind = query.get('kind') || 'overview';
    if (!['overview', 'reservations', 'history'].includes(kind)) throw new HttpError(400, 'Invalid account evidence kind.');
    const result = await accountEvidenceResult(kind, id, query);
    if (!result) throw new HttpError(404, 'Account or requested observation not found.');
    sendJson(context.res, 200, result);
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

async function uiAdaptiveRiskHandler(context: RequestContext): Promise<void> {
  try {
    if (context.req.method === 'POST') {
      if (!requireConfirmation(context, 'copy-legacy-risk-policy', 'Explicit reviewed Legacy policy copy required.')) return;
      sendJson(context.res, 200, await copyLegacyRiskPolicy((await readJsonBody(context.req, 4096)) as Parameters<typeof copyLegacyRiskPolicy>[0]));
    } else {
      const result = await uiAdaptiveRisk(context.parsedUrl.searchParams);
      if (!result) throw new HttpError(404, 'Adaptive evidence not found.');
      sendJson(context.res, 200, result);
    }
  } catch (error) {
    const statusCode = context.req.method === 'GET' ? 400 : 409;
    sendError(context, error instanceof HttpError ? error : new HttpError(statusCode, errorMessage(error)));
  }
}

async function uiIngressRelationsHandler(context: RequestContext): Promise<void> {
  try {
    const query = context.parsedUrl.searchParams;
    const result = await uiIngressRelations(query.get('id') ?? '', query.get('kind') as UiIngressRelation, query);
    if (!result) throw new HttpError(404, 'Ingress work not found.');
    sendJson(context.res, 200, result);
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

async function uiWorkflowDraftHandler(context: RequestContext): Promise<void> {
  try {
    if (context.req.method === 'GET') {
      sendJson(context.res, 200, { contractVersion: 1, draft: await getUiWorkflowDraft(context.parsedUrl.searchParams.get('id') ?? 'operator') });
    } else {
      const payload = await readJsonBody(context.req, 1_048_576);
      if (context.req.method === 'DELETE') {
        if (!requireConfirmation(context, 'delete-workflow-draft', 'Explicit graph draft deletion confirmation required.')) return;
        sendJson(context.res, 200, { result: await deleteUiWorkflowDraft(payload.id as string, payload.baseVersion) });
      } else sendJson(context.res, 200, { draft: await saveUiWorkflowDraft(payload as Parameters<typeof saveUiWorkflowDraft>[0], requireActor(context).id) });
    }
  } catch (error) { sendError(context, new HttpError(409, errorMessage(error))); }
}

async function uiJobsHandler(context: RequestContext): Promise<void> {
  try {
    const store = context.appState.uiOperations;
    if (!store) throw new HttpError(503, 'Durable operator jobs are unavailable.');
    const id = context.parsedUrl.searchParams.get('id');
    if (id) {
      const job = await store.get(id);
      if (!job) throw new HttpError(404, 'Operator job not found. An unobserved transport result is not a completion receipt.');
      sendJson(context.res, 200, { job, observedAt: Date.now() });
    } else sendJson(context.res, 200, await store.page(context.parsedUrl.searchParams));
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(409, errorMessage(error))); }
}

function requireParserConsent(payload: Record<string, unknown>, prepared: Awaited<ReturnType<typeof prepareUiParserTest>>): void {
  if (payload.externalDataConsent !== true || !prepared.preview.externalDataPolicyAccepted) throw new HttpError(412, 'Global external data policy and explicit test consent are required.');
  if (!prepared.preview.providerConfigured) throw new HttpError(503, 'AI provider credential is not configured.');
  if (payload.previewHash !== prepared.preview.previewHash || !Number.isSafeInteger(payload.previewObservedAt)
    || (payload.previewObservedAt as number) > Date.now() || Date.now() - (payload.previewObservedAt as number) > 300_000) throw new HttpError(409, 'Parser preview is stale or does not match this source and configuration. Preview again.');
}

async function uiParserLabHandler(context: RequestContext): Promise<void> {
  try {
    if (context.req.method === 'GET') {
      sendJson(context.res, 200, await uiParserMetadata(context.appState.config, context.appState.getQueueState())); return;
    }
    const payload = await readJsonBody(context.req, 450_000);
    const prepared = await prepareUiParserTest(context.appState.config, payload);
    if (context.parsedUrl.pathname.endsWith('/preview')) { sendJson(context.res, 200, prepared.preview); return; }
    if (!requireConfirmation(context, 'run-parser-test', 'Explicit external AI parser test confirmation required.')) return;
    requireParserConsent(payload, prepared);
    const store = context.appState.uiOperations;
    if (!store) throw new HttpError(503, 'Durable operator jobs are unavailable.');
    const accepted = await store.accept({ id: payload.jobId as string, kind: 'parser-test', actorId: requireActor(context).id,
      scope: { pathId: prepared.preview.pathId, sourceSha256: prepared.preview.sourceSha256, sourceChars: prepared.preview.sourceChars, previewHash: prepared.preview.previewHash }, request: { previewHash: payload.previewHash } });
    sendJson(context.res, 202, { job: accepted.job, created: accepted.created, requestId: context.requestId });
    if (accepted.created) store.run(accepted.job.id, () => runUiParserTest(prepared)).catch(() => addLog('[ERROR] Parser test result could not be persisted. Inspect the job; do not repeat automatically.'));
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error))); }
}

async function uiBackupDrillHandler(context: RequestContext): Promise<void> {
  if (!requireConfirmation(context, 'run-backup-drill', 'Explicit isolated restore drill confirmation required.')) return;
  try {
    const store = context.appState.uiOperations;
    if (!store || !context.appState.runBackupDrill) throw new HttpError(503, 'Isolated restore drills are unavailable.');
    const payload = await readJsonBody(context.req, 4096);
    const name = backupArtifactName(payload.name);
    const accepted = await store.accept({ id: payload.jobId as string, kind: 'backup-drill', actorId: requireActor(context).id, scope: { artifactName: name }, request: { name } });
    sendJson(context.res, 202, { job: accepted.job, created: accepted.created, requestId: context.requestId });
    if (accepted.created) store.run(accepted.job.id, () => runBackupDrillJob(context, name)).catch(error => addLog(`[ERROR] Operator drill result persistence failed: ${errorMessage(error)}`));
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(409, errorMessage(error))); }
}

async function mcpSnapshotHandler(context: RequestContext): Promise<void> {
  if (context.actor?.role !== 'admin') {
    sendJson(context.res, 403, { error: 'Administrator role required.', requestId: context.requestId });
    return;
  }
  try {
    sendJson(context.res, 200, {
      ...redactReviewRecord(context.parsedUrl.searchParams.get('view') === 'operator' ? await uiMcpSnapshot(context.parsedUrl.searchParams) : await mcpDashboardSnapshot()),
      endpoint: configuredMcpEndpoint(),
    });
  } catch (error) {
    sendError(context, context.parsedUrl.searchParams.get('view') === 'operator' ? new HttpError(400, errorMessage(error)) : error);
  }
}

async function mcpProposalDetailHandler(context: RequestContext): Promise<void> {
  if (context.actor?.role !== 'admin') { sendError(context, new HttpError(403, 'Administrator role required.')); return; }
  try {
    const rawUrl = context.req.url;
    if (!rawUrl) throw new HttpError(400, 'Invalid proposal identifier.');
    const id = new URL(rawUrl, 'http://localhost').searchParams.get('id');
    if (!id || !/^[a-zA-Z0-9_-]{1,64}$/.test(id)) throw new HttpError(400, 'Invalid proposal identifier.');
    const review = await uiMcpProposalReview(id);
    if (!review) throw new HttpError(404, 'Proposal not found.');
    sendJson(context.res, 200, review);
  } catch (error) { sendError(context, error instanceof HttpError ? error : new HttpError(409, errorMessage(error))); }
}

async function updateMcpRuntimeHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 8 * 1024);
    if (payload.mode === 'active' && !requireConfirmation(
      context,
      'set-mcp-runtime-active',
      'Explicit MCP runtime activation confirmation required.',
    )) return;
    if (payload.mode === 'disabled' && !requireConfirmation(
      context,
      'set-mcp-runtime-disabled',
      'Explicit MCP runtime disable confirmation required.',
    )) return;
    sendJson(context.res, 200, {
      success: true,
      ...await setMcpRuntimeMode(payload.mode, context.actor?.id || 'dashboard:admin'),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function createMcpAgentHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 64 * 1024);
    const result = await createMcpAgent(payload as Parameters<typeof createMcpAgent>[0]);
    sendJson(context.res, 201, {
      success: true,
      ...result,
      tokenNotice: 'This token is shown once. Store it in the agent secret store now.',
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function updateMcpAgentHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 64 * 1024);
    sendJson(context.res, 200, {
      success: true,
      agent: await updateMcpAgent(payload as Parameters<typeof updateMcpAgent>[0]),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function rotateMcpAgentTokenHandler(context: RequestContext): Promise<void> {
  if (!requireConfirmation(
    context,
    'rotate-mcp-agent-token',
    'Explicit MCP agent token rotation confirmation required.',
  )) return;
  try {
    const payload = await readJsonBody(context.req, 8 * 1024);
    const result = await rotateMcpAgentToken(payload.id);
    sendJson(context.res, 200, {
      success: true,
      ...result,
      tokenNotice: 'The previous token and active sessions are revoked. This replacement token is shown once.',
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function deleteMcpAgentHandler(context: RequestContext): Promise<void> {
  if (!requireConfirmation(
    context,
    'delete-mcp-agent',
    'Explicit MCP agent deletion confirmation required.',
  )) return;
  try {
    const payload = await readJsonBody(context.req, 8 * 1024);
    sendJson(context.res, 200, {
      success: true,
      deleted: await deleteMcpAgent(payload.id),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function approveMcpProposalHandler(context: RequestContext): Promise<void> {
  if (!requireConfirmation(
    context,
    'approve-mcp-proposal',
    'Explicit MCP proposal approval confirmation required.',
  )) return;
  try {
    const payload = await readJsonBody(context.req, 8 * 1024);
    sendJson(context.res, 200, {
      success: true,
      proposal: redactReview(payload.reviewHash === undefined
        ? await approveMcpProposal(payload.id, context.actor?.id || 'dashboard:admin')
        : await approveReviewedMcpProposal(payload.id as string, context.actor?.id || 'dashboard:admin', payload.reviewHash)),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

async function rejectMcpProposalHandler(context: RequestContext): Promise<void> {
  try {
    const payload = await readJsonBody(context.req, 16 * 1024);
    sendJson(context.res, 200, {
      success: true,
      proposal: await rejectMcpProposal(
        payload.id,
        context.actor?.id || 'dashboard:admin',
        payload.reason,
      ),
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, new HttpError(409, errorMessage(error)));
  }
}

function requireTelegramViewerControl(context: RequestContext): {
  settings: NonNullable<WebServerState['telegramViewerSettings']>;
  secrets: NonNullable<WebServerState['telegramViewerSecrets']>;
} {
  const settings = context.appState.telegramViewerSettings;
  const secrets = context.appState.telegramViewerSecrets;
  if (!settings || !secrets) throw new HttpError(503, 'Telegram viewer control is unavailable.');
  return { settings, secrets };
}

async function telegramViewerStatusHandler(context: RequestContext): Promise<void> {
  try {
    const { settings, secrets } = requireTelegramViewerControl(context);
    let service: Record<string, unknown> = { healthy: false, ready: false, reachable: false };
    try {
      service = context.appState.getTelegramViewerStatus
        ? { ...(await context.appState.getTelegramViewerStatus()), reachable: true }
        : service;
    } catch (error) {
      service = { ...service, error: errorMessage(error) };
    }
    sendJson(context.res, 200, {
      settings: settings.snapshot(),
      settingsRevision: configurationRevision(settings.snapshot()),
      settingsRecovery: settings.recoveryStatus(),
      secrets: secrets.status(),
      service,
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error);
  }
}

async function updateTelegramViewerSettingsHandler(context: RequestContext): Promise<void> {
  try {
    const { settings } = requireTelegramViewerControl(context);
    const expected = context.req.headers['if-match'];
    const result = await settings.set(await readJsonBody(context.req, 64 * 1024), typeof expected === 'string' ? expected : undefined);
    sendJson(context.res, 200, { settings: result, settingsRevision: configurationRevision(result) });
  } catch (error) {
    let statusCode;
    if (error instanceof HttpError) statusCode = error.statusCode;
    else statusCode = errorMessage(error).includes('settings changed') ? 409 : 400;
    sendError(context, new HttpError(statusCode, errorMessage(error)));
  }
}

async function updateTelegramViewerTokenHandler(context: RequestContext): Promise<void> {
  try {
    const { secrets } = requireTelegramViewerControl(context);
    const payload = await readJsonBody(context.req, 2 * 1024);
    await secrets.setBotToken(payload?.token);
    sendJson(context.res, 200, { success: true, secrets: secrets.status() });
  } catch (error) {
    sendError(context, new HttpError(error instanceof HttpError ? error.statusCode : 400, errorMessage(error)));
  }
}

async function deleteTelegramViewerTokenHandler(context: RequestContext): Promise<void> {
  try {
    const { secrets } = requireTelegramViewerControl(context);
    await secrets.deleteBotToken();
    sendJson(context.res, 200, { success: true, secrets: secrets.status() });
  } catch (error) {
    sendError(context, error);
  }
}

async function rotateTelegramViewerServiceTokenHandler(context: RequestContext): Promise<void> {
  try {
    const { secrets } = requireTelegramViewerControl(context);
    await secrets.rotateServiceToken();
    sendJson(context.res, 200, { success: true, secrets: secrets.status(), restartRecommended: true });
  } catch (error) {
    sendError(context, error);
  }
}

async function createTelegramViewerTestHandler(context: RequestContext): Promise<void> {
  try {
    requireTelegramViewerControl(context);
    const payload = await readJsonBody(context.req, 4 * 1024);
    const event = await createTelegramViewerTestEvent({
      createdBy: context.actor?.id || 'dashboard:admin',
      message: typeof payload?.message === 'string' ? payload.message : 'TSX Core Telegram Viewer test',
    });
    sendJson(context.res, 202, { accepted: true, event: { id: event.id, seq: event.seq, createdAt: event.createdAt } });
  } catch (error) {
    sendError(context, new HttpError(error instanceof HttpError ? error.statusCode : 400, errorMessage(error)));
  }
}

function uiCapabilitiesHandler(context: RequestContext): void {
  try {
    const authority = context.appState.startupAuthority;
    const startup = authority?.snapshot();
    sendJson(context.res, 200, uiCapabilities(context.parsedUrl.searchParams, {
      role: context.actor?.role ?? 'viewer', recovery: context.appState.recovery?.active === true,
      canMutate: authority ? authority.canMutate() : true, mutationInProgress,
      startupPhase: startup?.phase ?? null, startupReason: startup?.reason ?? null,
    }));
  } catch (error) { sendError(context, new HttpError(400, errorMessage(error))); }
}
function uiParametersHandler(context: RequestContext): void {
  try { sendJson(context.res, 200, uiParameters(context.parsedUrl.searchParams)); }
  catch (error) { sendError(context, new HttpError(400, errorMessage(error))); }
}
const API_ROUTES = new Map<string, ApiHandler>([
  ['GET /api/ui/capabilities', uiCapabilitiesHandler],
  ['GET /api/ui/parameters', uiParametersHandler],
  ['GET /api/ui/search', uiSearchHandler],
  ['GET /api/status', statusHandler],
  ['GET /api/access', accessStatusHandler],
  ['GET /api/logs', logsHandler],
  ['GET /api/metrics-history', metricsHistoryHandler],
  ['GET /api/incoming-messages', incomingMessagesHandler],
  ['GET /api/processed-signals', processedSignalsHandler],
  ['GET /api/signals/ingress', signalPageHandler('ingress')],
  ['GET /api/signals/processed', signalPageHandler('processed')],
  ['GET /api/signals/messages', signalPageHandler('messages')],
  ['GET /api/signals/original', signalOriginalHandler],
  ['GET /api/ui/deployment', uiDeploymentHandler],
  ['GET /api/ui/attention', uiAttentionHandler],
  ['GET /api/setup-bundle/review', setupReviewTreeHandler],
  ['GET /api/signals/ingress/detail', ingressDetailHandler],
  ['GET /api/signals/ingress/relations', uiIngressRelationsHandler],
  ['GET /api/outbox/page', signalPageHandler('outbox')],
  ['GET /api/dashboard-analytics', dashboardAnalyticsHandler],
  ['GET /api/outbox', outboxHandler],
  ['POST /api/outbox/retry', retryOutboxHandler],
  ['POST /api/outbox/acknowledge', acknowledgeOutboxHandler],
  ['DELETE /api/incoming-messages', deleteIncomingHandler],
  ['DELETE /api/processed-signals', deleteSignalHandler],
  ['POST /api/control', controlHandler],
  ['GET /api/telegram-login', telegramLoginHandler],
  ['POST /api/telegram-login', postTelegramLoginHandler],
  ['GET /api/config', getConfigHandler],
  ['POST /api/config', postConfigHandler],
  ['GET /api/secrets', secretsHandler],
  ['POST /api/secrets', postSecretsHandler],
  ['POST /api/access-tokens', accessTokenHandler],
  ['DELETE /api/access-tokens/viewer', disableViewerTokenHandler],
  ['POST /api/import', importHandler],
  ['GET /api/setup-bundle/export', exportSetupBundleHandler],
  ['POST /api/setup-bundle/preview', previewSetupBundleHandler],
  ['POST /api/setup-bundle/apply', applySetupBundleHandler],
  ['POST /api/factory-reset', factoryResetHandler],
  ['POST /api/clear-database', clearDatabaseHandler],
  ['GET /api/operations', operationsHandler],
  ['POST /api/operations/backup', runBackupHandler],
  ['POST /api/operations/audit-replay', replayAuditHandler],
  ['GET /api/runtime-settings', runtimeSettingsHandler],
  ['POST /api/runtime-settings', postRuntimeSettingsHandler],
  ['GET /api/recovery', recoveryStatusHandler],
  ['POST /api/restart', restartHandler],
  ['GET /api/backups', backupsHandler],
  ['GET /api/backups/verify', verifyBackupHandler],
  ['POST /api/backups/recover-offsite', recoverOffsiteBackupHandler],
  ['POST /api/backups/restore', restoreBackupHandler],
  ['GET /api/trading', tradingSnapshotHandler],
  ['GET /api/exchanges/catalog', exchangeCatalogHandler],
  ['POST /api/exchanges/probe', probeExchangeHandler],
  ['GET /api/trading/portfolio', tradingPortfolioHandler],
  ['GET /api/trading/analytics', tradingAnalyticsHandler],
  ['GET /api/trading/journal', tradingJournalHandler],
  ['GET /api/trading/intents/detail', tradingIntentDetailHandler],
  ['GET /api/trading/intents/relations', uiTradeRelationsHandler],
  ['GET /api/trading/objects', uiTradingListHandler],
  ['GET /api/trading/accounts/detail', uiAccountDetailHandler],
  ['GET /api/trading/accounts/evidence', uiAccountEvidenceHandler],
  ['GET /api/trading/risk/adaptive', uiAdaptiveRiskHandler],
  ['POST /api/trading/risk/adaptive/copy-legacy', uiAdaptiveRiskHandler],
  ['GET /api/workflow/drafts', uiWorkflowDraftHandler],
  ['GET /api/operations/jobs', uiJobsHandler],
  ['POST /api/operations/backup-drill', uiBackupDrillHandler],
  ['GET /api/workflow/parser-test', uiParserLabHandler],
  ['POST /api/workflow/parser-test/preview', uiParserLabHandler],
  ['POST /api/workflow/parser-test', uiParserLabHandler],
  ['POST /api/workflow/drafts', uiWorkflowDraftHandler],
  ['DELETE /api/workflow/drafts', uiWorkflowDraftHandler],
  ['GET /api/trading/journal/export', tradingJournalExportHandler],
  ['POST /api/trading/journal', updateTradingJournalHandler],
  ['POST /api/trading/strategies', createTradingStrategyHandler],
  ['POST /api/trading/strategies/update', updateTradingStrategyHandler],
  ['POST /api/trading/strategies/publish', publishTradingStrategyHandler],
  ['POST /api/trading/strategies/archive', archiveTradingStrategyHandler],
  ['DELETE /api/trading/strategies', deleteTradingStrategyHandler],
  ['POST /api/trading/signal-schemas', createTradingSignalSchemaHandler],
  ['POST /api/trading/signal-schemas/update', updateTradingSignalSchemaHandler],
  ['DELETE /api/trading/signal-schemas', deleteTradingSignalSchemaHandler],
  ['POST /api/trading/signal-contracts', createSignalContractHandler],
  ['POST /api/trading/signal-contracts/versions', createSignalContractVersionHandler],
  ['POST /api/trading/signal-contracts/update', updateSignalContractHandler],
  ['POST /api/trading/signal-contracts/duplicate', duplicateSignalContractHandler],
  ['POST /api/trading/signal-contracts/publish', publishSignalContractHandler],
  ['POST /api/trading/signal-contracts/archive', archiveSignalContractHandler],
  ['DELETE /api/trading/signal-contracts/versions', deleteSignalContractVersionHandler],
  ['DELETE /api/trading/signal-contracts/drafts', deleteSignalContractDraftHandler],
  ['POST /api/trading/signal-contracts/validate', validateSignalContractHandler],
  ['POST /api/trading/channel-risk', setChannelRiskPolicyHandler],
  ['DELETE /api/trading/channel-risk', deleteChannelRiskPolicyHandler],
  ['POST /api/trading/accounts', createTradingAccountHandler],
  ['POST /api/trading/accounts/credentials', replaceTradingCredentialsHandler],
  ['POST /api/trading/accounts/verify', verifyTradingAccountHandler],
  ['POST /api/trading/accounts/state', updateTradingAccountHandler],
  ['POST /api/trading/accounts/configuration', configureTradingAccountHandler],
  ['POST /api/trading/accounts/kill-switch/release', releaseTradingAccountKillSwitchHandler],
  ['DELETE /api/trading/accounts', deleteTradingAccountHandler],
  ['POST /api/trading/routes', setTradingRouteHandler],
  ['DELETE /api/trading/routes', deleteTradingRouteHandler],
  ['POST /api/trading/runtime', updateTradingRuntimeHandler],
  ['POST /api/trading/paper', configurePaperTradingHandler],
  ['POST /api/trading/reconcile', reconcileTradingHandler],
  ['POST /api/trading/cancel-entries', cancelTradingEntriesHandler],
  ['POST /api/trading/emergency-flatten', emergencyFlattenHandler],
  ['POST /api/trading/risk/acknowledge', acknowledgeTradingRiskHandler],
  ['GET /api/workflow', workflowSnapshotHandler],
  ['GET /api/workflow/objects', uiWorkflowObjectsHandler],
  ['GET /api/workflow/models', uiWorkflowModelsHandler],
  ['POST /api/workflow/models', uiWorkflowModelsHandler],
  ['GET /api/workflow/history', workflowHistoryStatusHandler],
  ['POST /api/workflow/mutate', saveWorkflowHandler],
  ['POST /api/workflow/impact', previewWorkflowImpactHandler],
  ['POST /api/workflow/history/impact', previewWorkflowHistoryImpactHandler],
  ['POST /api/workflow/history/apply', applyWorkflowHistoryHandler],
  ['POST /api/workflow/history/reset', resetWorkflowHistoryHandler],
  ['POST /api/workflow/simulate', simulateWorkflowHandler],
  ['POST /api/workflow/resources', createWorkflowResourceHandler],
  ['POST /api/workflow/resources/update', updateWorkflowResourceHandler],
  ['POST /api/workflow/resources/publish', publishWorkflowResourceHandler],
  ['DELETE /api/workflow/resources', deleteWorkflowResourceHandler],
  ['GET /api/mcp', mcpSnapshotHandler],
  ['GET /api/mcp/proposals/detail', mcpProposalDetailHandler],
  ['POST /api/mcp/runtime', updateMcpRuntimeHandler],
  ['POST /api/mcp/agents', createMcpAgentHandler],
  ['POST /api/mcp/agents/update', updateMcpAgentHandler],
  ['POST /api/mcp/agents/rotate', rotateMcpAgentTokenHandler],
  ['DELETE /api/mcp/agents', deleteMcpAgentHandler],
  ['POST /api/mcp/proposals/approve', approveMcpProposalHandler],
  ['POST /api/mcp/proposals/reject', rejectMcpProposalHandler],
  ['GET /api/telegram-viewer', telegramViewerStatusHandler],
  ['POST /api/telegram-viewer/settings', updateTelegramViewerSettingsHandler],
  ['POST /api/telegram-viewer/token', updateTelegramViewerTokenHandler],
  ['DELETE /api/telegram-viewer/token', deleteTelegramViewerTokenHandler],
  ['POST /api/telegram-viewer/service-token/rotate', rotateTelegramViewerServiceTokenHandler],
  ['POST /api/telegram-viewer/test', createTelegramViewerTestHandler],
]);

function bootstrapStatusHandler(
  context: RequestContext,
  authenticator: DashboardAuthenticator
): void {
  const required = authenticator.mode === 'token' && !authenticator.isConfigured();
  const directLoopback = isDirectLoopbackRequest(context.req);
  // This public status must never invite an anonymous client to call the
  // authenticated local-session endpoint as an automatic login mechanism.
  const localSessionAvailable = false;
  sendJson(context.res, 200, {
    mode: authenticator.mode,
    required,
    available: required && Boolean(context.appState.secretStore)
      && (directLoopback || configuredBootstrapProof() !== null),
    localSessionAvailable,
    ...(required && !directLoopback ? { bootstrapProofRequired: true } : {}),
    ...(required && context.appState.recovery?.allowLoopbackLocalSession === true
      ? { recoveryBootstrap: true }
      : {}),
  });
}

function bootstrapTokenState(authenticator: DashboardAuthenticator): void {
  if (authenticator.mode !== 'token') {
    throw new HttpError(409, 'Token bootstrap is unavailable in OIDC mode.');
  }
  if (authenticator.isConfigured()) {
    throw new HttpError(409, 'Dashboard authentication is already configured.');
  }
}

function requireBootstrapSecretStore(context: RequestContext): NonNullable<WebServerState['secretStore']> {
  if (!context.appState.secretStore) {
    throw new HttpError(503, 'Managed secret storage is unavailable.');
  }
  return context.appState.secretStore;
}

async function requireBootstrapProof(context: RequestContext): Promise<void> {
  if (isDirectLoopbackRequest(context.req)) return;
  const payload = await readJsonBody(context.req, 4 * 1024);
  if (!validBootstrapProof(payload.bootstrapProof)) {
    throw new HttpError(403, 'Dashboard bootstrap requires the one-time container bootstrap proof.');
  }
}

function requireBootstrapOrigin(context: RequestContext): void {
  const origin = typeof context.req.headers.origin === 'string' ? context.req.headers.origin : '';
  if (!origin || !isAllowedOrigin(origin)) {
    throw new HttpError(403, 'Dashboard bootstrap requires an allowed browser origin.');
  }
}

async function bootstrapHandler(
  context: RequestContext,
  authenticator: DashboardAuthenticator
): Promise<void> {
  try {
    bootstrapTokenState(authenticator);
    requireBootstrapSecretStore(context);
    await requireBootstrapProof(context);
    requireBootstrapOrigin(context);
    const actor: AuthenticatedActor = { role: 'admin', id: 'bootstrap:proved-operator' };
    if (context.appState.recovery?.active && context.appState.recovery.allowLoopbackLocalSession) {
      addLog(`[CRITICAL] request_id=${context.requestId} Recovery-mode proved bootstrap initialized without an audit trail.`, {
        request_id: context.requestId,
        event: 'recovery_proved_bootstrap',
      });
    } else if (!(await authorizeMutationAudit(context, actor, 'POST', '/api/bootstrap'))) return;
    const token = await context.appState.secretStore.createDashboardAdminToken();
    delete process.env.DASHBOARD_BOOTSTRAP_PROOF;
    addLog(`[SECURITY] request_id=${context.requestId} Dashboard administrator token bootstrapped.`);
    sendJson(context.res, 201, {
      token,
      recoveryLocation: 'secrets/dashboard_admin_token',
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error instanceof HttpError ? error : new HttpError(409, errorMessage(error)));
  }
}

function localDashboardStartupEnabled(): boolean {
  return process.env.DASHBOARD_LOCAL_TRUST?.trim().toLowerCase() === 'true'
    && process.env.ENTERPRISE_MODE?.trim().toLowerCase() !== 'true';
}

function requireLocalSessionSecretStore(
  context: RequestContext,
  authenticator: DashboardAuthenticator
): NonNullable<WebServerState['secretStore']> {
  if (!localDashboardStartupEnabled() && !context.appState.recovery?.allowLoopbackLocalSession) {
    throw new HttpError(409, 'Integrated local dashboard startup is disabled.');
  }
  if (authenticator.mode !== 'token') {
    throw new HttpError(409, 'Integrated local startup is unavailable in OIDC mode.');
  }
  const secretStore = context.appState.secretStore;
  if (!secretStore) throw new HttpError(503, 'Managed secret storage is unavailable.');
  if (!isDirectLoopbackRequest(context.req)) {
    throw new HttpError(403, 'Integrated local startup requires a direct loopback connection without a proxy.');
  }
  const origin = typeof context.req.headers.origin === 'string' ? context.req.headers.origin : '';
  if (!origin || !isLoopbackBrowserOrigin(origin) || context.req.headers['x-requested-with'] !== 'forwarder-dashboard') {
    throw new HttpError(403, 'Integrated local startup requires the trusted dashboard origin.');
  }
  return secretStore;
}

function isRecoveryLocalSessionBootstrap(context: RequestContext): boolean {
  return context.appState.recovery?.allowLoopbackLocalSession === true;
}

// skipcq: JS-0116 - retain native Promise return, rejection, and adoption timing for existing callers.
async function authorizeLocalSessionInitialization(
  context: RequestContext,
  actor: AuthenticatedActor,
  tokenWasConfigured: boolean
): Promise<boolean> {
  if (tokenWasConfigured) return true;
  if (isRecoveryLocalSessionBootstrap(context)) {
    addLog(`[CRITICAL] request_id=${context.requestId} Recovery-mode loopback session initialized without an audit trail.`, {
      request_id: context.requestId,
      event: 'recovery_local_session_bootstrap',
    });
    return true;
  }
  return authorizeMutationAudit(context, actor, 'POST', '/api/local-session');
}

async function localSessionHandler(
  context: RequestContext,
  authenticator: DashboardAuthenticator
): Promise<void> {
  try {
    const secretStore = requireLocalSessionSecretStore(context, authenticator);
    const tokenWasConfigured = authenticator.isConfigured();
    if (tokenWasConfigured) {
      const actor = await authenticator.authenticate(context.req.headers.authorization, context.req.headers);
      if (actor?.role !== 'admin' || !actor.id.startsWith('token:')) {
        throw new HttpError(401, 'A durable administrator bearer is required to create a local session.');
      }
      if (!authenticator.issueLocalAdminSession) {
        throw new HttpError(409, 'Integrated local sessions are unavailable for this authentication mode.');
      }
      const session = authenticator.issueLocalAdminSession();
      addLog(`[SECURITY] request_id=${context.requestId} Ephemeral local dashboard session initialized.`);
      sendJson(context.res, 201, {
        token: session.token,
        role: 'admin',
        localStartup: true,
        generatedAdminToken: false,
        expiresInSeconds: session.expiresInSeconds,
        requestId: context.requestId,
      });
      return;
    }
    if (!isRecoveryLocalSessionBootstrap(context)) {
      throw new HttpError(409, 'Create and save the administrator token before starting a local session.');
    }
    const actor: AuthenticatedActor = { role: 'admin', id: 'startup:local-browser' };
    if (!(await authorizeLocalSessionInitialization(context, actor, tokenWasConfigured))) return;
    const token = await secretStore.createDashboardAdminToken();
    addLog(`[SECURITY] request_id=${context.requestId} Integrated local dashboard access initialized.`);
    sendJson(context.res, 201, {
      token,
      role: 'admin',
      localStartup: true,
      generatedAdminToken: true,
      requestId: context.requestId,
    });
  } catch (error) {
    sendError(context, error instanceof HttpError ? error : new HttpError(409, errorMessage(error)));
  }
}

function recoveryAllowsRoute(method: string, url: string): boolean {
  return new Set([
    'GET /api/recovery',
    'GET /api/config',
    'POST /api/config',
    'GET /api/secrets',
    'POST /api/secrets',
    'GET /api/runtime-settings',
    'POST /api/runtime-settings',
    'POST /api/factory-reset',
    'POST /api/workflow/history/reset',
    'POST /api/restart',
  ]).has(`${method} ${url}`);
}

function handleOptions(res: http.ServerResponse): void {
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Authorization, Content-Type, X-Requested-With, X-Destructive-Confirmation, X-UI-Search, If-Match, X-Operator-Job-ID'
  );
  res.writeHead(204);
  res.end();
}

async function serveSpaFallback(res: http.ServerResponse): Promise<void> {
  try {
    const content = await fsPromises.readFile(path.join(STATIC_ROOT, 'index.html'));
    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Length': String(content.length),
      'Cache-Control': 'no-cache',
    });
    res.end(content);
  } catch {
    const content = Buffer.from(`<!DOCTYPE html>
<html>
<head><title>Dashboard Dev Mode</title></head>
<body style="font-family:sans-serif;background:#0d1117;color:#c9d1d9;padding:2rem;">
  <h1>Dashboard Development Mode</h1>
  <p>Compile the React frontend with: <code>npm run build</code></p>
</body>
</html>`);
    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Length': String(content.length),
      'Cache-Control': 'no-cache',
    });
    res.end(content);
  }
}

function staticResponseBody(
  content: Buffer,
  mimeType: string,
  acceptedEncoding: string | string[] | undefined
): { body: Buffer; encoding?: 'gzip' } {
  const acceptsGzip = typeof acceptedEncoding === 'string'
    && acceptedEncoding.split(',').some(value => value.trim().split(';')[0] === 'gzip');
  const compressible = /^(?:text\/|application\/(?:javascript|json))/.test(mimeType);
  if (!acceptsGzip || !compressible || content.length < 1024) return { body: content };
  return { body: gzipSync(content, { level: 6 }), encoding: 'gzip' };
}

function staticFilePath(url: string): string | { status: 400 | 403; error: string } {
  let decodedPath: string;
  try {
    decodedPath = decodeURIComponent(url === '/' ? 'index.html' : url.replace(/^\/+/, ''));
  } catch {
    return { status: 400, error: 'Invalid URL encoding.' };
  }
  const absolutePath = path.resolve(STATIC_ROOT, decodedPath);
  if (absolutePath !== STATIC_ROOT && !absolutePath.startsWith(`${STATIC_ROOT}${path.sep}`)) return { status: 403, error: 'Invalid static file path.' };
  return absolutePath;
}

function staticResponseHeaders(mimeType: string, body: Buffer, versioned: boolean, encoding?: string): Record<string, string> {
  return {
    'Content-Type': mimeType,
    'Content-Length': String(body.length),
    'Cache-Control': versioned ? 'public, max-age=31536000, immutable' : 'no-cache',
    ...(encoding ? { 'Content-Encoding': encoding, Vary: 'Accept-Encoding' } : {}),
  };
}

async function serveStaticFile(res: http.ServerResponse, absolutePath: string, decodedPath: string, acceptEncoding: string | undefined): Promise<void> {
  const stats = await fsPromises.stat(absolutePath);
  if (!stats.isFile()) {
    await serveSpaFallback(res);
    return;
  }
  const mimeType = MIME_TYPES[path.extname(absolutePath).toLowerCase()] ?? 'application/octet-stream';
  const content = await fsPromises.readFile(absolutePath);
  const response = staticResponseBody(content, mimeType, acceptEncoding);
  const isVersionedAsset = decodedPath.startsWith(`assets${path.sep}`) || decodedPath.startsWith('assets/');
  res.writeHead(200, staticResponseHeaders(mimeType, response.body, isVersionedAsset, response.encoding));
  res.end(response.body);
}

async function serveStatic(context: RequestContext, url: string): Promise<void> {
  const absolutePath = staticFilePath(url);
  if (typeof absolutePath !== 'string') {
    sendJson(context.res, absolutePath.status, { error: absolutePath.error, requestId: context.requestId });
    return;
  }
  try {
    await serveStaticFile(context.res, absolutePath, decodeURIComponent(url === '/' ? 'index.html' : url.replace(/^\/+/, '')), context.req.headers['accept-encoding']);
  } catch {
    await serveSpaFallback(context.res);
  }
}

async function handlePublicApiRequest(
  context: RequestContext,
  authenticator: DashboardAuthenticator,
  method: string,
  url: string
): Promise<boolean> {
  if (method === 'GET' && url === '/api/bootstrap/status') {
    bootstrapStatusHandler(context, authenticator);
    return true;
  }
  if (method === 'POST' && url === '/api/bootstrap') {
    await bootstrapHandler(context, authenticator);
    return true;
  }
  if (method === 'POST' && url === '/api/local-session') {
    await localSessionHandler(context, authenticator);
    return true;
  }
  return false;
}

async function invokeApiHandler(
  context: RequestContext,
  method: string,
  handler: ApiHandler
): Promise<void> {
  if (method === 'GET') {
    await handler(context);
    return;
  }
  // These two handlers check the startup gate after their bound receipt lookup,
  // allowing completion-only replays while their own maintenance hold remains active.
  try { if (!restartReceiptLookup(context)) assertStartupMutationAllowed(context, method); }
  catch (error) { sendError(context, error); return; }
  if (mutationInProgress) {
    sendJson(context.res, 409, {
      error: 'Another control-plane mutation is already in progress.',
      requestId: context.requestId,
    });
    return;
  }
  mutationInProgress = true;
  try {
    await handler(context);
  } finally {
    mutationInProgress = false;
  }
}

function assertBodyMutationAllowed(req: http.IncomingMessage): void {
  const context = requestContexts.get(req);
  if (context && !restartReceiptLookup(context)) assertStartupMutationAllowed(context, req.method || 'GET');
}

function restartReceiptLookup(context: RequestContext): boolean {
  return context.req.method === 'POST' && ['/api/backups/restore', '/api/factory-reset'].includes(context.parsedUrl.pathname);
}

function assertStartupMutationAllowed(context: RequestContext, method: string): void {
  const authority = context.appState.startupAuthority;
  if (method === 'GET' || !authority || authority.canMutate()) return;
  const route = `${method} ${context.parsedUrl.pathname}`;
  // Explicit repairs do not authorize trading, workflow changes, resets or imports.
  if (route === 'POST /api/restart') return;
  if (context.appState.recovery?.active && new Set([
    'POST /api/config', 'POST /api/secrets', 'POST /api/runtime-settings',
  ]).has(route)) return;
  const status = authority.snapshot();
  throw new HttpError(503, `Startup authorization is ${status.phase}; control-plane changes are blocked: ${
    status.reason || status.mutationHolds.join(', ') || status.pendingGates.join(', ')
  }.`);
}

async function handleAuthenticatedApiRequest(
  context: RequestContext,
  authenticator: DashboardAuthenticator,
  method: string,
  url: string
): Promise<void> {
  if (await handlePublicApiRequest(context, authenticator, method, url)) return;
  if (!(await authenticateApiRequest(context, authenticator, method, url))) return;
  if (context.appState.recovery?.active && !recoveryAllowsRoute(method, url)) {
    sendJson(context.res, 503, {
      error: 'Recovery mode only permits managed runtime-settings and secret repair followed by a restart.',
      requestId: context.requestId,
    });
    return;
  }
  const handler = API_ROUTES.get(`${method} ${url}`);
  if (!handler) {
    sendJson(context.res, 404, { error: 'API endpoint not found.', requestId: context.requestId });
    return;
  }
  await invokeApiHandler(context, method, handler);
}

function bearerCredential(header: string | undefined): string | null {
  if (typeof header !== 'string') return null;
  const match = /^Bearer ([A-Za-z0-9_-]{20,256})$/.exec(header);
  return match?.[1] ?? null;
}

async function authenticateInternalViewerRequest(context: RequestContext): Promise<boolean> {
  const secrets = context.appState.telegramViewerSecrets;
  if (!secrets) {
    sendJson(context.res, 503, { error: 'Telegram viewer service authentication is unavailable.', requestId: context.requestId });
    return false;
  }
  const expected = await secrets.serviceToken();
  const candidate = bearerCredential(
    typeof context.req.headers.authorization === 'string' ? context.req.headers.authorization : undefined,
  );
  if (!expected || !constantTimeStringEqual(expected, candidate)) {
    context.res.setHeader('WWW-Authenticate', 'Bearer realm="tsx-internal-viewer"');
    sendJson(context.res, 401, { error: 'Valid viewer service token required.', requestId: context.requestId });
    return false;
  }
  return true;
}

function decodedViewerId(encoded: string): string {
  try {
    return decodeURIComponent(encoded);
  } catch {
    throw new HttpError(400, 'Viewer resource identifier is malformed.');
  }
}

async function internalViewerPayload(context: RequestContext, relativePath: string): Promise<unknown> {
  const query = context.parsedUrl.searchParams;
  const limit = query.get('limit') ?? undefined;
  const offset = query.get('offset') ?? undefined;
  if (relativePath === '/config') {
    const settings = context.appState.telegramViewerSettings;
    if (!settings) throw new HttpError(503, 'Telegram viewer settings are unavailable.');
    return { settings: settings.snapshot() };
  }
  const collectionLoaders: Record<string, () => unknown> = {
    '/summary': () => viewerSummary(),
    '/system': () => viewerSystem(),
    '/accounts': () => viewerAccounts({ limit, offset }),
    '/positions': () => viewerPositions({ limit, offset }),
    '/orders': () => viewerOrders({ limit, offset }),
    '/trades': () => viewerTrades({ limit, offset }),
    '/performance': () => viewerPerformance({ days: query.get('days') ?? undefined }),
    '/risk': () => viewerRisk({ limit, offset }),
    '/incidents': () => viewerIncidents({ limit, offset }),
    '/events': () => listTradingNotificationEvents({ afterSeq: query.get('afterSeq') ?? undefined, limit }),
    '/test-events': () => listTelegramViewerTestEvents({ afterSeq: query.get('afterSeq') ?? undefined, limit }),
  };
  const collectionLoader = collectionLoaders[relativePath];
  if (collectionLoader) return collectionLoader();
  const detail = /^\/(accounts|positions|orders|trades)\/([^/]+)$/.exec(relativePath);
  if (detail) {
    const kind = detail[1];
    const rawId = detail[2];
    if (kind !== 'accounts' && kind !== 'positions' && kind !== 'orders' && kind !== 'trades') throw new HttpError(404, 'Internal viewer endpoint not found.');
    if (rawId === undefined) throw new HttpError(404, 'Viewer resource not found.');
    const id = decodedViewerId(rawId);
    const detailLoaders = {
      accounts: viewerAccounts,
      positions: viewerPositions,
      orders: viewerOrders,
      trades: viewerTrades,
    };
    const payload = await detailLoaders[kind]({ id });
    const value = (payload as Record<string, unknown>)[kind.slice(0, -1)];
    if (!value) throw new HttpError(404, 'Viewer resource not found.');
    return payload;
  }
  throw new HttpError(404, 'Internal viewer endpoint not found.');
}

async function handleInternalViewerRequest(context: RequestContext, method: string, url: string): Promise<void> {
  if (method !== 'GET') {
    context.res.setHeader('Allow', 'GET');
    sendJson(context.res, 405, { error: 'Internal viewer API is read-only.', requestId: context.requestId });
    return;
  }
  if (!(await authenticateInternalViewerRequest(context))) return;
  try {
    const payload = await internalViewerPayload(context, url.slice('/internal/viewer/v1'.length));
    sendJson(context.res, 200, payload);
  } catch (error) {
    sendError(context, error instanceof HttpError ? error : new HttpError(400, errorMessage(error)));
  }
}

async function handleRequest(
  req: http.IncomingMessage,
  res: http.ServerResponse,
  appState: WebServerState,
  authenticator: DashboardAuthenticator
): Promise<void> {
  const requestId = randomUUID();
  res.setHeader('X-Request-Id', requestId);
  const parsedUrl = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  const url = parsedUrl.pathname;
  const method = req.method || 'GET';
  const origin = typeof req.headers.origin === 'string' ? req.headers.origin : undefined;
  const context: RequestContext = { req, res, requestId, parsedUrl, appState, authenticator };
  requestContexts.set(req, context);
  setSecurityHeaders(res, origin);
  if (!isAllowedOrigin(origin)) {
    sendJson(res, 403, { error: 'Origin is not allowed.', requestId });
    return;
  }
  if (method === 'OPTIONS') {
    handleOptions(res);
    return;
  }
  if (url === '/internal/viewer/v1' || url.startsWith('/internal/viewer/v1/')) {
    await handleInternalViewerRequest(context, method, url);
    return;
  }
  if (!url.startsWith('/api/')) {
    await serveStatic(context, url);
    return;
  }
  await handleAuthenticatedApiRequest(context, authenticator, method, url);
}

export function startWebServer(
  port: number,
  appState: WebServerState,
  host = process.env.WEB_HOST?.trim() || '127.0.0.1'
): http.Server {
  const authenticator = appState.authenticator ?? dashboardAuthenticatorFromEnvironment();
  server = http.createServer((req, res) => {
    handleRequest(req, res, appState, authenticator).catch((error) => {
      addLog(`[ERROR] Unhandled dashboard request error: ${errorMessage(error)}`);
      if (!res.headersSent) sendJson(res, 500, { error: 'Unexpected server error.' });
      else res.destroy();
    });
  });
  server.requestTimeout = 15_000;
  server.headersTimeout = 10_000;
  server.keepAliveTimeout = 5_000;
  server.listen(port, host, () => {
    const address = server?.address();
    const listeningPort = typeof address === 'object' && address ? address.port : port;
    console.log(`[INFO] Web Control Dashboard listening on http://${host}:${listeningPort}`);
    if (appState.uiOperations && appState.requestRestart) {
      restartCoordinator(appState).reconcile().catch(error => {
        addLog(`[CRITICAL] Durable restart reconciliation failed: ${errorMessage(error)}`);
      });
    }
  });
  return server;
}

export function stopWebServer(): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    if (!server) {
      resolve();
      return;
    }
    server.close((error) => (error ? reject(error) : resolve()));
    server = null;
  });
}

// skipcq: JS-0116 - retain native Promise return, rejection, and adoption timing for existing callers.
async function accountEvidenceResult(kind: string, id: string, query: URLSearchParams) {
  if (kind === 'reservations') return uiAccountReservations(id, query);
  if (kind === 'history') return uiAccountHistory(id, query);
  return uiAccountEvidence(id);
}
