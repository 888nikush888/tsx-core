import { promises as fs } from 'node:fs';
import path from 'node:path';
import { configurationPathFromEnvironment } from './config.js';
import { withManagedConfigurationWrite } from './backup_generation.js';
import { configurationRevision } from './ui_configuration.js';
import { RUNTIME_INTEGER_RANGES, runtimeFieldGroup, runtimeFieldUnit } from './ui_runtime_contract.js';

export interface RuntimeSettings {
  enterpriseMode: boolean;
  dashboardAuthMode: 'token' | 'oidc' | 'tailscale';
  dashboardLocalTrust: boolean;
  dashboardAllowedOrigin: string;
  tailscaleServeTrustedProxy: boolean;
  tailscaleAdminUsers: string;
  tailscaleViewerUsers: string;
  oidcIssuer: string;
  oidcAudience: string;
  oidcJwksUrl: string;
  oidcAdminRole: string;
  oidcViewerRole: string;
  oidcRoleClaim: string;
  oidcMaxTokenAgeSeconds: number;
  auditWebhookUrl: string;
  alertWebhookUrl: string;
  auditRemoteRequired: boolean;
  auditWebhookTimeoutMs: number;
  alertWebhookTimeoutMs: number;
  auditLocalMaxBytes: number;
  backupOffsiteRequired: boolean;
  backupOffsiteUrlTemplate: string;
  backupOffsiteTimeoutMs: number;
  backupOffsiteMaxRecoveryBytes: number;
  backupOffsiteRetentionDays: number;
  backupIntervalMs: number;
  backupRetentionCount: number;
  dataRetentionDays: number;
  dataRetentionIntervalMs: number;
  dataRetentionBatchSize: number;
  dataMinFreeBytes: number;
  deliveryConfirmTimeoutMs: number;
  shutdownGraceMs: number;
  jsonLogging: boolean;
  isolateUnavailableMarketFailures: boolean;
}

export interface RuntimeSettingsRecoveryStatus {
  active: boolean;
  reason: string | null;
}

export interface RuntimeSettingsStoreOptions {
  recoverInvalidFile?: boolean;
}

export const DEFAULT_RUNTIME_SETTINGS: RuntimeSettings = {
  enterpriseMode: false,
  dashboardAuthMode: 'token',
  dashboardLocalTrust: true,
  dashboardAllowedOrigin: '',
  tailscaleServeTrustedProxy: false,
  tailscaleAdminUsers: '',
  tailscaleViewerUsers: '',
  oidcIssuer: '',
  oidcAudience: '',
  oidcJwksUrl: '',
  oidcAdminRole: 'forwarder-admin',
  oidcViewerRole: 'forwarder-viewer',
  oidcRoleClaim: 'roles',
  oidcMaxTokenAgeSeconds: 3_600,
  auditWebhookUrl: '',
  alertWebhookUrl: '',
  auditRemoteRequired: false,
  auditWebhookTimeoutMs: 10_000,
  alertWebhookTimeoutMs: 10_000,
  auditLocalMaxBytes: 64 * 1024 * 1024,
  backupOffsiteRequired: false,
  backupOffsiteUrlTemplate: '',
  backupOffsiteTimeoutMs: 60_000,
  backupOffsiteMaxRecoveryBytes: 2 * 1024 * 1024 * 1024,
  backupOffsiteRetentionDays: 0,
  backupIntervalMs: 15 * 60_000,
  backupRetentionCount: 672,
  dataRetentionDays: 90,
  dataRetentionIntervalMs: 6 * 60 * 60_000,
  dataRetentionBatchSize: 1_000,
  dataMinFreeBytes: 1024 * 1024 * 1024,
  deliveryConfirmTimeoutMs: 30_000,
  shutdownGraceMs: 30_000,
  jsonLogging: true,
  isolateUnavailableMarketFailures: false,
};

// A corrupted managed settings file must never silently re-enable the broad
// standalone local-trust flow. Recovery is intentionally token-only and keeps
// every optional external integration disabled until an operator repairs it.
const SAFE_RECOVERY_RUNTIME_SETTINGS: RuntimeSettings = {
  ...DEFAULT_RUNTIME_SETTINGS,
  dashboardLocalTrust: false,
};

const KEYS = new Set(Object.keys(DEFAULT_RUNTIME_SETTINGS));
const BOOLEAN_SETTING_NAMES = [
  'enterpriseMode',
  'dashboardLocalTrust',
  'tailscaleServeTrustedProxy',
  'auditRemoteRequired',
  'backupOffsiteRequired',
  'jsonLogging',
  'isolateUnavailableMarketFailures',
] as const;

type RuntimeSettingsRecord = Record<string, unknown>;

function integer(value: unknown, name: string, minimum: number, maximum: number): number {
  const range = RUNTIME_INTEGER_RANGES[name as keyof typeof RUNTIME_INTEGER_RANGES];
  if (range) [minimum, maximum] = range;
  if (!Number.isSafeInteger(value) || Number(value) < minimum || Number(value) > maximum) {
    throw new Error(`${name} must be an integer between ${minimum} and ${maximum}.`);
  }
  return Number(value);
}

function text(value: unknown, name: string, maximum = 2048): string {
  if (typeof value !== 'string' || value.length > maximum || /[\r\n\0]/.test(value)) {
    throw new Error(`${name} is invalid.`);
  }
  return value.trim();
}

function webUrl(value: unknown, name: string, required = false): string {
  const normalized = text(value, name);
  if (!normalized) {
    if (required) throw new Error(`${name} is required.`);
    return '';
  }
  const candidate = normalized.replace('{artifact}', 'artifact');
  const parsed = new URL(candidate);
  const loopback = ['127.0.0.1', '::1', 'localhost'].includes(parsed.hostname);
  if (parsed.username || parsed.password || parsed.hash) throw new Error(`${name} must not contain credentials or a fragment.`);
  if (parsed.protocol !== 'https:' && !(parsed.protocol === 'http:' && loopback)) {
    throw new Error(`${name} must use HTTPS except for loopback testing.`);
  }
  return normalized;
}

function identifier(value: unknown, name: string): string {
  const normalized = text(value, name, 256);
  if (!normalized) throw new Error(`${name} is required.`);
  return normalized;
}

function webOrigin(value: unknown): string {
  const normalized = webUrl(value, 'dashboardAllowedOrigin');
  if (!normalized) return '';
  const parsed = new URL(normalized);
  if (parsed.pathname !== '/' || parsed.search) {
    throw new Error('dashboardAllowedOrigin must contain only scheme, host and optional port.');
  }
  return parsed.origin;
}

function mergeRuntimeSettings(input: unknown): RuntimeSettingsRecord {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Runtime settings must be a JSON object.');
  const source = input as RuntimeSettingsRecord;
  const unknown = Object.keys(source).filter((key) => !KEYS.has(key));
  if (unknown.length > 0) throw new Error(`Unknown runtime setting(s): ${unknown.join(', ')}.`);
  return { ...DEFAULT_RUNTIME_SETTINGS, ...source } as RuntimeSettingsRecord;
}

function validateBooleanSettings(settings: RuntimeSettingsRecord): void {
  for (const name of BOOLEAN_SETTING_NAMES) {
    if (typeof settings[name] !== 'boolean') throw new Error(`${name} must be true or false.`);
  }
}

function validatedDashboardAuthMode(value: unknown): RuntimeSettings['dashboardAuthMode'] {
  if (value !== 'token' && value !== 'oidc' && value !== 'tailscale') {
    throw new Error('dashboardAuthMode must be token, oidc or tailscale.');
  }
  return value;
}

function tailscaleUsers(value: unknown, name: string, required = false): string {
  const normalized = text(value, name, 4_096);
  const users = normalized.split(',').map(item => item.trim().toLocaleLowerCase('en-US')).filter(Boolean);
  if (required && users.length === 0) throw new Error(`${name} must contain at least one Tailscale login.`);
  if (users.some(user => !/^[^\s,\0]{1,254}$/.test(user))) throw new Error(`${name} contains an invalid Tailscale login.`);
  if (new Set(users).size !== users.length) throw new Error(`${name} must not contain duplicate Tailscale logins.`);
  return users.join(',');
}

function validateTailscaleProfile(
  settings: RuntimeSettingsRecord,
  dashboardAuthMode: RuntimeSettings['dashboardAuthMode'],
  dashboardAllowedOrigin: string,
): { adminUsers: string; viewerUsers: string } {
  const required = dashboardAuthMode === 'tailscale';
  if (required) {
    if (settings.tailscaleServeTrustedProxy !== true) {
      throw new Error('Tailscale identity mode requires the explicit trusted Serve proxy boundary.');
    }
    if (settings.dashboardLocalTrust !== false) throw new Error('Tailscale identity mode must disable trusted local dashboard startup.');
    if (!dashboardAllowedOrigin) throw new Error('Tailscale identity mode requires dashboardAllowedOrigin.');
    const origin = new URL(dashboardAllowedOrigin);
    if (origin.protocol !== 'https:' || !origin.hostname.endsWith('.ts.net')) {
      throw new Error('Tailscale identity mode requires an HTTPS *.ts.net dashboard origin.');
    }
  }
  const adminUsers = tailscaleUsers(settings.tailscaleAdminUsers, 'tailscaleAdminUsers', required);
  const viewerUsers = tailscaleUsers(settings.tailscaleViewerUsers, 'tailscaleViewerUsers');
  const admins = new Set(adminUsers.split(',').filter(Boolean));
  if (viewerUsers.split(',').filter(Boolean).some(user => admins.has(user))) {
    throw new Error('A Tailscale login cannot be both administrator and viewer.');
  }
  return { adminUsers, viewerUsers };
}

function validateEnterpriseProfile(
  settings: RuntimeSettingsRecord,
  enterprise: boolean,
  dashboardAuthMode: RuntimeSettings['dashboardAuthMode']
): void {
  if (enterprise && dashboardAuthMode !== 'oidc') throw new Error('Enterprise mode requires OIDC dashboard authentication.');
  if (enterprise && settings.dashboardLocalTrust !== false) throw new Error('Enterprise mode must disable trusted local dashboard startup.');
  if (enterprise && settings.auditRemoteRequired !== true) throw new Error('Enterprise mode requires remote audit delivery.');
  if (enterprise && settings.backupOffsiteRequired !== true) throw new Error('Enterprise mode requires off-site backup replication.');
  if (enterprise && (!Number.isSafeInteger(settings.backupOffsiteRetentionDays) || Number(settings.backupOffsiteRetentionDays) < 30)) {
    throw new Error('Enterprise mode requires at least 30 days of confirmed off-site backup retention.');
  }
}

function validatedBackupUrl(settings: RuntimeSettingsRecord, enterprise: boolean): string {
  const required = enterprise || settings.backupOffsiteRequired === true;
  const backupUrl = webUrl(settings.backupOffsiteUrlTemplate, 'backupOffsiteUrlTemplate', required);
  if (backupUrl && (backupUrl.match(/\{artifact\}/g) || []).length !== 1) {
    throw new Error('backupOffsiteUrlTemplate must contain exactly one {artifact} placeholder.');
  }
  return backupUrl;
}

interface ValidatedOidcSettings {
  issuer: string;
  audience: string;
  jwksUrl: string;
  roleClaim: string;
}

function validatedOidcSettings(
  settings: RuntimeSettingsRecord,
  enterprise: boolean,
  dashboardAuthMode: RuntimeSettings['dashboardAuthMode']
): ValidatedOidcSettings {
  const required = enterprise || dashboardAuthMode === 'oidc';
  const roleClaim = identifier(settings.oidcRoleClaim, 'oidcRoleClaim');
  if (!/^[a-zA-Z][a-zA-Z0-9_.-]{0,63}$/.test(roleClaim)) throw new Error('oidcRoleClaim is invalid.');
  if (required) {
    return {
      issuer: webUrl(settings.oidcIssuer, 'oidcIssuer', true),
      audience: identifier(settings.oidcAudience, 'oidcAudience'),
      jwksUrl: webUrl(settings.oidcJwksUrl, 'oidcJwksUrl', true),
      roleClaim,
    };
  }
  return {
    issuer: text(settings.oidcIssuer, 'oidcIssuer'),
    audience: text(settings.oidcAudience, 'oidcAudience', 256),
    jwksUrl: text(settings.oidcJwksUrl, 'oidcJwksUrl'),
    roleClaim,
  };
}

export function validateRuntimeSettings(input: unknown): RuntimeSettings {
  const merged = mergeRuntimeSettings(input);
  validateBooleanSettings(merged);
  const enterprise = merged.enterpriseMode as boolean;
  const dashboardAuthMode = validatedDashboardAuthMode(merged.dashboardAuthMode);
  validateEnterpriseProfile(merged, enterprise, dashboardAuthMode);
  const backupUrl = validatedBackupUrl(merged, enterprise);
  const oidc = validatedOidcSettings(merged, enterprise, dashboardAuthMode);
  const dashboardAllowedOrigin = webOrigin(merged.dashboardAllowedOrigin);
  const tailscale = validateTailscaleProfile(merged, dashboardAuthMode, dashboardAllowedOrigin);
  if (merged.oidcAdminRole === merged.oidcViewerRole) {
    throw new Error('oidcAdminRole and oidcViewerRole must be different.');
  }
  const remoteAuditRequired = enterprise || merged.auditRemoteRequired === true;
  return {
    enterpriseMode: enterprise,
    dashboardAuthMode,
    dashboardLocalTrust: merged.dashboardLocalTrust as boolean,
    dashboardAllowedOrigin,
    tailscaleServeTrustedProxy: merged.tailscaleServeTrustedProxy as boolean,
    tailscaleAdminUsers: tailscale.adminUsers,
    tailscaleViewerUsers: tailscale.viewerUsers,
    oidcIssuer: oidc.issuer,
    oidcAudience: oidc.audience,
    oidcJwksUrl: oidc.jwksUrl,
    oidcAdminRole: identifier(merged.oidcAdminRole, 'oidcAdminRole'),
    oidcViewerRole: identifier(merged.oidcViewerRole, 'oidcViewerRole'),
    oidcRoleClaim: oidc.roleClaim,
    oidcMaxTokenAgeSeconds: integer(merged.oidcMaxTokenAgeSeconds, 'oidcMaxTokenAgeSeconds', 60, 86_400),
    auditWebhookUrl: webUrl(merged.auditWebhookUrl, 'auditWebhookUrl', remoteAuditRequired),
    alertWebhookUrl: webUrl(merged.alertWebhookUrl, 'alertWebhookUrl', enterprise),
    auditRemoteRequired: merged.auditRemoteRequired as boolean,
    auditWebhookTimeoutMs: integer(merged.auditWebhookTimeoutMs, 'auditWebhookTimeoutMs', 1_000, 30_000),
    alertWebhookTimeoutMs: integer(merged.alertWebhookTimeoutMs, 'alertWebhookTimeoutMs', 1_000, 60_000),
    auditLocalMaxBytes: integer(merged.auditLocalMaxBytes, 'auditLocalMaxBytes', 1024 * 1024, 1024 * 1024 * 1024),
    backupOffsiteRequired: merged.backupOffsiteRequired as boolean,
    backupOffsiteUrlTemplate: backupUrl,
    backupOffsiteTimeoutMs: integer(merged.backupOffsiteTimeoutMs, 'backupOffsiteTimeoutMs', 1_000, 5 * 60_000),
    backupOffsiteMaxRecoveryBytes: integer(merged.backupOffsiteMaxRecoveryBytes, 'backupOffsiteMaxRecoveryBytes', 1024 * 1024, 8 * 1024 * 1024 * 1024),
    backupOffsiteRetentionDays: integer(merged.backupOffsiteRetentionDays, 'backupOffsiteRetentionDays', 0, 3_650),
    backupIntervalMs: integer(merged.backupIntervalMs, 'backupIntervalMs', 60_000, 15 * 60_000),
    backupRetentionCount: integer(merged.backupRetentionCount, 'backupRetentionCount', 1, 10_000),
    dataRetentionDays: integer(merged.dataRetentionDays, 'dataRetentionDays', 1, 3_650),
    dataRetentionIntervalMs: integer(merged.dataRetentionIntervalMs, 'dataRetentionIntervalMs', 300_000, 86_400_000),
    dataRetentionBatchSize: integer(merged.dataRetentionBatchSize, 'dataRetentionBatchSize', 100, 10_000),
    dataMinFreeBytes: integer(merged.dataMinFreeBytes, 'dataMinFreeBytes', 64 * 1024 * 1024, 1024 * 1024 * 1024 * 1024),
    deliveryConfirmTimeoutMs: integer(merged.deliveryConfirmTimeoutMs, 'deliveryConfirmTimeoutMs', 1_000, 300_000),
    shutdownGraceMs: integer(merged.shutdownGraceMs, 'shutdownGraceMs', 1_000, 120_000),
    jsonLogging: merged.jsonLogging as boolean,
    isolateUnavailableMarketFailures: merged.isolateUnavailableMarketFailures as boolean,
  };
}

const ENVIRONMENT_MAPPING: Record<keyof RuntimeSettings, string> = {
  enterpriseMode: 'ENTERPRISE_MODE',
  dashboardAuthMode: 'DASHBOARD_AUTH_MODE',
  dashboardLocalTrust: 'DASHBOARD_LOCAL_TRUST',
  dashboardAllowedOrigin: 'DASHBOARD_ALLOWED_ORIGIN',
  tailscaleServeTrustedProxy: 'TAILSCALE_SERVE_TRUSTED_PROXY',
  tailscaleAdminUsers: 'TAILSCALE_ADMIN_USERS',
  tailscaleViewerUsers: 'TAILSCALE_VIEWER_USERS',
  oidcIssuer: 'DASHBOARD_OIDC_ISSUER',
  oidcAudience: 'DASHBOARD_OIDC_AUDIENCE',
  oidcJwksUrl: 'DASHBOARD_OIDC_JWKS_URL',
  oidcAdminRole: 'DASHBOARD_OIDC_ADMIN_ROLE',
  oidcViewerRole: 'DASHBOARD_OIDC_VIEWER_ROLE',
  oidcRoleClaim: 'DASHBOARD_OIDC_ROLE_CLAIM',
  oidcMaxTokenAgeSeconds: 'DASHBOARD_OIDC_MAX_TOKEN_AGE_SECONDS',
  auditWebhookUrl: 'AUDIT_WEBHOOK_URL',
  alertWebhookUrl: 'ALERT_WEBHOOK_URL',
  auditRemoteRequired: 'AUDIT_REMOTE_REQUIRED',
  auditWebhookTimeoutMs: 'AUDIT_WEBHOOK_TIMEOUT_MS',
  alertWebhookTimeoutMs: 'ALERT_WEBHOOK_TIMEOUT_MS',
  auditLocalMaxBytes: 'AUDIT_LOCAL_MAX_BYTES',
  backupOffsiteRequired: 'BACKUP_OFFSITE_REQUIRED',
  backupOffsiteUrlTemplate: 'BACKUP_OFFSITE_URL_TEMPLATE',
  backupOffsiteTimeoutMs: 'BACKUP_OFFSITE_TIMEOUT_MS',
  backupOffsiteMaxRecoveryBytes: 'BACKUP_OFFSITE_MAX_RECOVERY_BYTES',
  backupOffsiteRetentionDays: 'BACKUP_OFFSITE_RETENTION_DAYS',
  backupIntervalMs: 'BACKUP_INTERVAL_MS',
  backupRetentionCount: 'BACKUP_RETENTION_COUNT',
  dataRetentionDays: 'DATA_RETENTION_DAYS',
  dataRetentionIntervalMs: 'DATA_RETENTION_INTERVAL_MS',
  dataRetentionBatchSize: 'DATA_RETENTION_BATCH_SIZE',
  dataMinFreeBytes: 'DATA_MIN_FREE_BYTES',
  deliveryConfirmTimeoutMs: 'DELIVERY_CONFIRM_TIMEOUT_MS',
  shutdownGraceMs: 'SHUTDOWN_GRACE_MS',
  jsonLogging: 'JSON_LOGGING',
  isolateUnavailableMarketFailures: 'TRADING_ISOLATE_UNAVAILABLE_MARKET_FAILURES',
};

async function syncDirectory(directory: string): Promise<void> {
  const handle = await fs.open(directory, 'r');
  try {
    await handle.sync();
  } catch (error: unknown) {
    if (!['EINVAL', 'ENOTSUP', 'EISDIR', 'EPERM'].includes((error as { code?: string } | null | undefined)?.code ?? '')) throw error;
  } finally {
    await handle.close();
  }
}

export class ManagedRuntimeSettingsStore {
  private settings = structuredClone(DEFAULT_RUNTIME_SETTINGS);
  private recoveryReason: string | null = null;
  private active: RuntimeSettings | null = null;
  private updates: Promise<unknown> = Promise.resolve();

  constructor(
    private readonly filePath: string,
    private readonly env: NodeJS.ProcessEnv = process.env
  ) {}

  async initialize(options: RuntimeSettingsStoreOptions = {}): Promise<void> {
    const resolved = path.resolve(this.filePath);
    await fs.mkdir(path.dirname(resolved), { recursive: true, mode: 0o700 });
    try {
      const stats = await fs.lstat(resolved);
      if (!stats.isFile() || stats.isSymbolicLink() || stats.size > 128 * 1024) {
        throw new Error('Runtime settings must be a small regular file.');
      }
      this.settings = validateRuntimeSettings(JSON.parse(await fs.readFile(resolved, 'utf8')));
    } catch (error: unknown) {
      if ((error as { code?: unknown } | null | undefined)?.code === 'ENOENT') {
        await this.write(DEFAULT_RUNTIME_SETTINGS);
        return;
      }
      if (!options.recoverInvalidFile) throw error;
      this.settings = structuredClone(SAFE_RECOVERY_RUNTIME_SETTINGS);
      this.recoveryReason = error instanceof Error ? (error as { message?: string }).message : 'Managed runtime settings could not be read.';
    }
  }

  snapshot(): RuntimeSettings {
    return structuredClone(this.settings);
  }

  recoveryStatus(): RuntimeSettingsRecoveryStatus {
    return { active: this.recoveryReason !== null, reason: this.recoveryReason };
  }

  // skipcq: JS-0116 - retain native Promise return, rejection, and adoption timing for existing callers.
  async set(input: unknown, baseRevision?: string): Promise<RuntimeSettings> {
    const pending = this.updates.then(async () => {
      if (baseRevision !== undefined && baseRevision !== configurationRevision(this.settings)) {
        throw new Error('Runtime settings changed. Reload and compare before saving.');
      }
      const candidate = validateRuntimeSettings(input && typeof input === 'object' && !Array.isArray(input) ? { ...this.settings, ...input } : input);
      await this.write(candidate);
      this.recoveryReason = null;
      return this.snapshot();
    });
    this.updates = pending.catch(() => undefined);
    return pending;
  }

  describe() {
    return {
      revision: configurationRevision(this.settings), active: structuredClone(this.active),
      source: this.recoveryReason ? 'safe-recovery-defaults' : 'managed-runtime-store',
      precedence: 'Managed settings replace mapped environment values when applied at startup.',
      parameters: Object.entries(DEFAULT_RUNTIME_SETTINGS).map(([key, defaultValue]) => ({
        path: key, group: runtimeFieldGroup(key), type: typeof defaultValue, unit: runtimeFieldUnit(key), default: defaultValue,
        range: RUNTIME_INTEGER_RANGES[key as keyof typeof RUNTIME_INTEGER_RANGES] ?? null,
        values: key === 'dashboardAuthMode' ? ['token', 'oidc', 'tailscale'] : null,
        maxLength: runtimeFieldMaxLength(key),
        nullable: false, emptyMeaning: typeof defaultValue === 'string' ? 'Clears optional values; required profile values are validated together.' : null,
        secret: false, editable: true, source: this.recoveryReason ? 'safe-recovery-defaults' : 'managed-runtime-store', environmentName: ENVIRONMENT_MAPPING[key as keyof RuntimeSettings],
        effect: 'Stored now; mapped values applied at startup. Access session revocation may take effect immediately.',
        requiresRestart: true,
      })),
      restartRequired: this.active === null || configurationRevision(this.active) !== configurationRevision(this.settings),
    };
  }

  async reset(): Promise<void> {
    await this.write(DEFAULT_RUNTIME_SETTINGS);
    this.recoveryReason = null;
  }

  applyToEnvironment(): void {
    for (const [key, environmentName] of Object.entries(ENVIRONMENT_MAPPING) as Array<[keyof RuntimeSettings, string]>) {
      const value = this.settings[key];
      if (value === '') {
        if (!Reflect.deleteProperty(this.env, environmentName)) {
          throw new TypeError(`${environmentName} could not be removed from the environment.`);
        }
      } else this.env[environmentName] = String(value);
    }
    this.active = this.snapshot();
  }

  private async write(settings: RuntimeSettings): Promise<void> {
    const content = `${JSON.stringify(settings, null, 2)}\n`;
    await withManagedConfigurationWrite(configurationPathFromEnvironment(this.env), this.filePath, content,
      () => this.writeFile(content));
    this.settings = JSON.parse(content) as RuntimeSettings;
  }

  private async writeFile(content: string): Promise<void> {
    const destination = path.resolve(this.filePath);
    const temporary = `${destination}.${process.pid}.${Date.now()}.tmp`;
    let handle: fs.FileHandle | undefined;
    try {
      handle = await fs.open(temporary, 'wx', 0o600);
      await handle.writeFile(content, 'utf8');
      await handle.sync();
      await handle.close();
      handle = undefined;
      await fs.rename(temporary, destination);
      await syncDirectory(path.dirname(destination));
    } catch (error) {
      await handle?.close().catch(() => undefined);
      await fs.unlink(temporary).catch(() => undefined);
      throw error;
    }
  }
}

export function managedRuntimeSettingsFromEnvironment(
  env: NodeJS.ProcessEnv = process.env
): ManagedRuntimeSettingsStore {
  return new ManagedRuntimeSettingsStore(
    managedRuntimeSettingsPathFromEnvironment(env),
    env
  );
}

export function managedRuntimeSettingsPathFromEnvironment(env: NodeJS.ProcessEnv = process.env): string {
  return path.resolve(env.RUNTIME_SETTINGS_PATH || path.join(process.cwd(), 'config', 'runtime-settings.json'));
}

function runtimeFieldMaxLength(key: string): number {
  if (/tailscale(Admin|Viewer)Users/.test(key)) return 4096;
  return /oidc(AdminRole|ViewerRole|Audience|RoleClaim)/.test(key) ? 256 : 2048;
}
