import assert from 'assert';
import { once } from 'events';
import { startMetricsServer, stopMetricsServer } from '../src/metrics.js';
import { MetricsTracker } from '../src/metrics_tracker.js';

const EMPTY_OUTBOX = { pending: 0, preparing: 0, sending: 0, completed: 4, failed: 1, unknown: 2 };
const HEALTHY_OPERATIONAL_METRICS = {
  databaseHealthy: true,
  isRunning: false,
  connectionState: 'disconnected',
  queuePaused: false,
  outbox: { ...EMPTY_OUTBOX },
  oldestPendingOutboxAgeSeconds: 15,
  aiRequestsToday: 3,
  aiUsedTokensToday: 120,
  aiReservedTokensToday: 40,
  lastForwardedAt: 1_700_000_000_000,
  backupHealthy: true,
  backupLastSuccessAt: 1_700_000_100_000,
  backupOffsiteHealthy: true,
  backupOffsiteRequired: true,
  backupOffsiteLastSuccessAt: 1_700_000_150_000,
  backupConfigurationCoherentAt: 1_700_000_101_000,
  backupRestoreEligibleAt: 1_700_000_090_000,
  backupRestoreEligibilityCheckedAt: 1_700_000_102_000,
  backupRestoreDrillAt: 1_700_000_080_000,
  retentionHealthy: true,
  retentionLastSuccessAt: 1_700_000_200_000,
  retentionDeletedTotal: 12,
  retentionBacklog: false,
  databaseAllocatedBytes: 8192,
  databaseReusableBytes: 4096,
  diskAvailableBytes: 2_000_000_000,
  diskCapacityHealthy: true,
  auditHealthy: true,
  auditRemoteRequired: true,
  auditLastRemoteSuccessAt: 1_700_000_250_000,
  clockHealthy: true,
  clockDriftMilliseconds: 4,
  clockMaxDriftMilliseconds: 1000,
  clockCheckedAt: 1_700_000_255_000,
  tradingHealthy: true,
  tradingExecutionEnabled: true,
  tradingLiveEnabled: false,
  tradingKillSwitchActive: false,
  tradingEnabledRoutes: 2,
  tradingOpenPositions: 1,
  tradingPendingIntents: 1,
  tradingUnknownOrders: 0,
  tradingUnprotectedPositions: 0,
  tradingUnacknowledgedCriticalRiskEvents: 0,
  tradingIntentCount: 120,
  tradingFillCount: 240,
  tradingLatestReconciliationAt: 1_700_000_260_000,
  deliverySlo: {
    accepted: 11,
    attempts: 10,
    confirmed: 9,
    failed: 1,
    unknown: 0,
    latencyCount: 9,
    latencySumSeconds: 42,
    latencyBuckets: [
      { le: 1, count: 2 },
      { le: 5, count: 8 },
      { le: 60, count: 9 }
    ]
  }
};

async function testMetricsTracker() {
  let forwarded = 0;
  const trackerCallbacks = {
    totalForwardedCountCallback: () => forwarded,
    getQueueStateCallback: () => ({ running: 1, queued: 2, maxConcurrency: 3, paused: false })
  };
  const tracker = new MetricsTracker({ ...trackerCallbacks, intervalMs: 10, maxPoints: 3 });
  tracker.start();
  forwarded = 2;
  const sampleDeadline = Date.now() + 1_000;
  while (tracker.getHistory().length < 3 && Date.now() < sampleDeadline) {
    await new Promise(resolve => setTimeout(resolve, 10));
  }
  tracker.stop();
  const history = tracker.getHistory();
  assert.strictEqual(history.length, 3, 'History must enforce its configured memory bound');
  assert.ok(history.some(point => point.processedDelta === 2));
  assert.ok(history.every(point => point.cpuUsage >= 0 && point.memoryUsage > 0));
  assert.ok(history.every(point => !('internetSpeed' in point)), 'Fabricated bandwidth must not be emitted');

  assert.throws(() => new MetricsTracker({ ...trackerCallbacks, intervalMs: 9 }), /at least 10ms/);
  assert.throws(() => new MetricsTracker({ ...trackerCallbacks, intervalMs: 10.5 }), /at least 10ms/);
  assert.throws(() => new MetricsTracker({ ...trackerCallbacks, intervalMs: 10, maxPoints: 0 }), /between 1 and 10000/);
  assert.throws(() => new MetricsTracker({ ...trackerCallbacks, intervalMs: 10, maxPoints: 10_001 }), /between 1 and 10000/);
  assert.throws(() => new MetricsTracker({ ...trackerCallbacks, intervalMs: 10, maxPoints: 1.5 }), /between 1 and 10000/);

  const defaultTracker = new MetricsTracker(trackerCallbacks);
  defaultTracker.start();
  defaultTracker.start();
  defaultTracker.stop();
  defaultTracker.stop();
}

async function runTests() {
  let operational = { ...HEALTHY_OPERATIONAL_METRICS };
  let operationalFailure = null;
  const server = startMetricsServer(0, {
    totalForwardedCountCallback: () => 7,
    getQueueStateCallback: () => ({ running: 1, queued: 2, maxConcurrency: 3 }),
    // skipcq: JS-0116 - this fixture must reject asynchronously like the API it simulates.
    getOperationalMetricsCallback: async () => {
      if (operationalFailure !== null) throw operationalFailure;
      return operational;
    }
  });
  await once(server, 'listening');
  const address = server.address();
  assert.ok(address && typeof address === 'object');
  assert.strictEqual(address.address, '127.0.0.1', 'Metrics must bind to loopback by default');
  const baseUrl = `http://127.0.0.1:${address.port}`;

  let response = await fetch(`${baseUrl}/healthz`);
  assert.strictEqual(response.status, 200);
  assert.strictEqual((await response.json()).status, 'alive');

  response = await fetch(`${baseUrl}/not-a-metrics-endpoint`);
  assert.equal(response.status, 404, 'Unknown paths must not fall through to operational metrics.');
  assert.match(response.headers.get('content-type'), /^text\/plain;/);
  assert.equal(await response.text(), 'Not Found');

  response = await fetch(`${baseUrl}/readyz`);
  assert.strictEqual(response.status, 503, 'Disconnected routing must not report ready');
  operational = { ...operational, isRunning: true, connectionState: 'connected' };
  response = await fetch(`${baseUrl}/readyz`);
  assert.strictEqual(response.status, 200);
  const readiness = await response.json();
  assert.strictEqual(readiness.unresolvedDeliveries, 3);

  response = await fetch(`${baseUrl}/metrics`);
  assert.strictEqual(response.status, 200);
  const metrics = await response.text();
  assert.match(metrics, /tg_forwarder_total_forwarded 7/);
  assert.match(metrics, /tg_forwarder_connection_state\{state="connected"\} 1/);
  assert.match(metrics, /tg_forwarder_outbox_tasks\{status="unknown"\} 2/);
  assert.match(metrics, /tg_forwarder_readiness 1/);
  assert.match(metrics, /tg_forwarder_outbox_oldest_pending_age_seconds 15/);
  assert.match(metrics, /tg_forwarder_ai_reserved_tokens_today 40/);
  assert.match(metrics, /tg_forwarder_last_confirmed_delivery_timestamp_seconds 1700000000/);
  assert.match(metrics, /tg_forwarder_backup_healthy 1/);
  assert.match(metrics, /tg_forwarder_backup_last_success_timestamp_seconds 1700000100/);
  assert.match(metrics, /tg_forwarder_backup_configuration_coherent_timestamp_seconds 1700000101/);
  assert.match(metrics, /tg_forwarder_backup_restore_eligible_timestamp_seconds 1700000090/);
  assert.match(metrics, /tg_forwarder_backup_restore_eligibility_checked_timestamp_seconds 1700000102/);
  assert.match(metrics, /tg_forwarder_backup_restore_drill_timestamp_seconds 1700000080/);
  assert.ok(!metrics.includes('restore-verified'), 'Offsite integrity must not claim an actual restore drill.');
  assert.match(metrics, /tg_forwarder_backup_offsite_healthy 1/);
  assert.match(metrics, /tg_forwarder_backup_offsite_required 1/);
  assert.match(metrics, /tg_forwarder_backup_offsite_last_success_timestamp_seconds 1700000150/);
  assert.match(metrics, /tg_forwarder_retention_healthy 1/);
  assert.match(metrics, /tg_forwarder_retention_deleted_rows_total 12/);
  assert.match(metrics, /tg_forwarder_database_allocated_bytes 8192/);
  assert.match(metrics, /tg_forwarder_disk_capacity_healthy 1/);
  assert.match(metrics, /tg_forwarder_audit_healthy 1/);
  assert.match(metrics, /tg_forwarder_audit_last_remote_success_timestamp_seconds 1700000250/);
  assert.match(metrics, /tg_forwarder_clock_healthy 1/);
  assert.match(metrics, /tg_forwarder_clock_drift_milliseconds 4/);
  assert.match(metrics, /tg_forwarder_clock_max_drift_milliseconds 1000/);
  assert.match(metrics, /tg_forwarder_trading_healthy 1/);
  assert.match(metrics, /tg_forwarder_trading_enabled_routes 2/);
  assert.match(metrics, /tg_forwarder_trading_open_positions 1/);
  assert.match(metrics, /tg_forwarder_trading_intents_total 120/);
  assert.match(metrics, /tg_forwarder_trading_fills_total 240/);
  assert.match(metrics, /tg_forwarder_trading_last_reconciliation_timestamp_seconds 1700000260/);
  assert.match(metrics, /tg_forwarder_delivery_attempts_total 10/);
  assert.match(metrics, /tg_forwarder_delivery_confirmed_total 9/);
  assert.match(metrics, /tg_forwarder_delivery_latency_seconds_bucket\{le="5"\} 8/);
  assert.match(metrics, /tg_forwarder_delivery_latency_seconds_count 9/);

  operational = { ...operational, diskCapacityHealthy: false };
  response = await fetch(`${baseUrl}/readyz`);
  assert.strictEqual(response.status, 503, 'Low disk capacity must fail readiness');

  operational = { ...operational, diskCapacityHealthy: true, auditHealthy: false };
  response = await fetch(`${baseUrl}/readyz`);
  assert.strictEqual(response.status, 503, 'Audit delivery failure must fail readiness');

  operational = { ...operational, auditHealthy: true, tradingHealthy: false, tradingUnknownOrders: 1 };
  response = await fetch(`${baseUrl}/readyz`);
  assert.strictEqual(response.status, 503, 'Unknown trading outcomes must fail readiness');

  operational = { ...operational, tradingHealthy: true, tradingUnknownOrders: 0, clockHealthy: false };
  response = await fetch(`${baseUrl}/readyz`);
  assert.strictEqual(response.status, 503, 'Unsafe clock drift must fail readiness');

  response = await fetch(`${baseUrl}/metrics`, { method: 'POST' });
  assert.strictEqual(response.status, 405);
  operationalFailure = { message: 'fixture unavailable', context: { detail: 'internal-only' } };
  for (const endpoint of ['/readyz', '/metrics']) {
    response = await fetch(`${baseUrl}${endpoint}`);
    assert.equal(response.status, 503);
    assert.deepEqual(await response.json(), { status: 'unavailable', error: 'fixture unavailable' },
      'Operational failures must expose only their existing message, not arbitrary internal context.');
  }
  operationalFailure = 'internal-only';
  response = await fetch(`${baseUrl}/metrics`);
  assert.equal(response.status, 503);
  assert.deepEqual(await response.json(), { status: 'unavailable' });
  await stopMetricsServer();
  await testMetricsTracker();

  console.log('ALL HONEST OBSERVABILITY TESTS PASSED!');
}

await (async () => runTests())().catch(async error => {
  await (async () => stopMetricsServer())().catch(() => undefined);
  console.error(error);
  process.exitCode = 1;
});
