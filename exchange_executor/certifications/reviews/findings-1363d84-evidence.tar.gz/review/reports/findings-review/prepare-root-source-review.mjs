import fs from 'node:fs';
import cp from 'node:child_process';
import crypto from 'node:crypto';
import ts from 'typescript';
const base='1fd38d6af1bd51ac8b8f232d7142a90419123ef9';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const ref=path=>({path,sha256:sha(fs.readFileSync(path))});
const revision=cp.execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
const deltas=JSON.parse(fs.readFileSync('reports/findings-review/current-receipt-source-deltas.json')).deltas;
const rootPaths=deltas.filter(d=>!d.path.startsWith('tests/')&&!d.path.startsWith('frontend/')).map(d=>d.path);
fs.writeFileSync('reports/findings-review/root-reviewed-source.diff',cp.execFileSync('git',['diff',base,revision,'--',...rootPaths]));
const notes={
 'alert_relay':'Request callback now consumes rejected handler Promise and destroys the response; token, body, HTTPS and loopback guards remain unchanged.',
 'backup_evidence':'Unknown input narrowed before property access; artifact hash, timestamps, proof freshness and exact eligibility conjunction retained. Extracted eligibility tail retains short circuit order; backup matrix tests exercised.',
 'backup_generation':'Typed key callback and undefined error-code fallback retain fsync allowlist behavior; native async function contracts restored.',
 'ccxt_exchange':'Nullish details/recovery aliases and typed request array retain endpoint, side-effect and retry classification, including unresolved-order evidence.',
 'config':'Object.fromEntries preserves own __proto__ keys without prototype mutation; invalid entries removed with same diagnostics. Model scalar false/zero retain defaults; objects rejected. Special-key and model regressions pass.',
 'dashboard_auth':'Private session-enabled predicate moved to static with both call sites changed. Environment and token-generation checks retained; authenticate keeps native Promise rejection.',
 'db':'Dispatch start remains immediate inside ownership fence; Promise.resolve adopts returned work and catch remains attached. Status conditional retains mapping; for-of still rejects sparse noninteger IDs. getDb initialization moved before use.',
 'exchange_catalog':'Credential field type assertion emits equivalent explicit property initialization; validation and returned values retained.',
 'exchange_contract_validation':'Unicode flag on ASCII control rejection retains rejected codepoints; all scalar checks retained.',
 'exchange_history_contract':'Import hoisted and Unicode ASCII-control regex retained; continuation and deep equality checks unchanged.',
 'exchange_order_identity_contract':'Unicode flag retains ASCII control guard, whitespace and length validation.',
 'forwarder':'TDLib named imports refer to same APIs; initialization failure throws before startup. Scheduler captures hoisted declarations but invokes later; shutdown behavior retained. Backup/drill error callbacks remain native async.',
 'logger':'ANSI escape replacement gains Unicode flag without broadening ASCII escape grammar.',
 'mcp_repository':'Bare return becomes explicit undefined for resource-create preflight; other branches unchanged.',
 'mcp_server':'Named z export retains schema constructors. Empty-server close resolves then returns; native async boundaries retained.',
 'paper_exchange':'Stateless helpers moved to static and callers updated, including setBalance use in TradingWebControl. Exchange interface snapshot/openState methods remain instance async methods. Database transaction and accounting logic unchanged.',
 'queue':'Hoisted finish/onIdle functions retain captured waiter set and timer cleanup; timer callback runs after initialization, settled flag still prevents double resolution.',
 'retention':'Explicit undefined only after existing cleanup; native Promise rejection and running guard preserved.',
 'runtime_settings':'Nullish error-code fallback cannot match fsync allowlist; same unsupported-error behavior and native async contract.',
 'secret_store':'Private pending-transaction validator made static with call site updated; no instance state referenced. Fsync error-code fallback retains allowlist.',
 'signal_contract':'Unsafe validation-time empty match removed. Syntax validation only compiles; actual matching remains VM bounded. Separate subprocess regression checks compile-only behavior and original adversarial timeout matrix remains.',
 'signal_parser':'Abort function declaration captures same timer/signal; nullish aliases preserve optional error name/code accesses.',
 'tdlib_retry':'Abort callback changed to declaration without receiver use; timer cancellation and rejection reason preserved.',
 'telegram_login':'Private name/string validators static with both call sites updated; no instance state used and prompt lifecycle retained.',
 'telegram_viewer_secrets':'Nullish error-code fallback preserves fsync error allowlist.',
 'telegram_viewer_settings':'Nullish error-code fallback preserves fsync error allowlist.',
 'trade_journal':'Empty array early branches wrapped in Promise.resolve inside async functions; awaited results and rejection shape retained. SQL and mapping unchanged.',
 'trading_account_log_contract':'ASCII control regex gains Unicode flag; receipt iterable parentheses have no effect. Budget and scope checks unchanged.',
 'trading_credentials':'Private atomic writer static with all calls updated; paths still validated by callers. Fsync fallback retains errors; no credential-scope expansion.',
 'trading_decimal':'Local arithmetic identifiers renamed consistently; BigInt expressions, precision bounds, signs and rounding paths unchanged.',
 'trading_engine':'Stateless private helpers converted to static and internal call sites updated. Instance adapter/mutation boundaries remain. Explicit undefined retains return; trading-risk, lifecycle, emergency and reconciliation tests cover behavior.',
 'trading_fill_quantity_contract':'Arithmetic and market local variables renamed consistently; exact product, identity, market digest and dimensional checks retained.',
 'trading_fx_quotes':'Explicit undefined guard for constant third leg fails closed; fixed LEG_ORDER contains the supported USDC leg.',
 'trading_kraken_cashleg_repository':'Nullish fee alias preserves optional currency/cost comparisons and exact signed decimal checks.',
 'trading_money_value':'GCD local identifiers renamed consistently; Euclidean BigInt algorithm unchanged.',
 'trading_repository':'Unicode flag preserves ASCII control rejection for external account IDs.',
 'trading_web_control':'Private stateless helpers static with every internal use updated. Paper balance setter routed to same static implementation; transaction, epoch, exposure and confirmation checks preserved.',
 'ui_account_evidence':'Nullish row alias retains early no-row result, redaction, fingerprint and freshness checks.',
 'ui_operation_store':'Nullish error-code fallback retains fsync allowlist and no broader error swallowing.',
 'ui_paper_configuration':'Expected revision cached from plain JSON payload; same type/hash/current revision checks and conflict error.',
 'ui_parser_lab':'Nullish xmlParsing alias and typed local limits preserve defaults and validation; casts/parentheses do not introduce actions.',
 'ui_route_inventory':'Generated handler commitments regenerated from actual handlers; route capability export and inventory tests verify derived outputs.',
 'ui_workflow_models':'Existing required model cached locally; attach/schema/strategy/contract lifecycle routing retained.',
 'web_server':'Captured restore/reset callbacks explicitly called with appState receiver, verified by HTTP regressions. Delete handlers consistently async; confirmation still precedes mutation. Remaining typed aliases/parentheses preserve request scope and authorization.',
 'workflow_repository':'Sorted Object.entries handles normalized JSON own keys; own-entry dispatch excludes prototype keys. Nonnegative .at indexes and validated dense tiers preserve ordering. Legacy config is normalized before required-map access; migration/fallback/history tests pass.'
};
const reviews=[];
for(const d of deltas){
 if(d.path.startsWith('tests/')||d.path.startsWith('frontend/'))continue;
 const current=fs.readFileSync(d.path);if(sha(current)!==d.currentSha256)throw Error('Drift '+d.path);
 let rationale,evidence=[];
 if(d.path.startsWith('src/')){
  const before=cp.execFileSync('git',['show',base+':'+d.path],{encoding:'utf8'});
  const emit=s=>ts.transpileModule(s,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,removeComments:true}}).outputText;
  const identical=emit(before)===emit(current.toString('utf8'));
  rationale=identical?'Exact emitted JavaScript equality with the historical receipt source after removing TypeScript types/comments; native async boundaries and executable statements unchanged.':notes[d.path.slice(4,-3)];
  if(!rationale)throw Error('Missing source review '+d.path);
  evidence=[ref('reports/findings-review/backend-review-final-inventory.json'),ref('reports/findings-review/runtime-delta-without-generated.diff')];
 }else if(d.path.startsWith('exchange_executor/')||d.path==='docs/testing/ccxt-expansion-matrix.json'){
  rationale=d.path.includes('/tests/')?'Python test selector/assertion transformations individually reviewed; AST-equivalent predicates and assertions retained after local binding substitution. Full 548-test run bound to unchanged Python inventory.':'Candidate matrix changes one reviewed Bybit witness hash; all 103 existing decisions retained, Bybit remains quarantined. Executor pin approves that unchanged decision set only.';
  evidence=[ref('reports/findings-review/python-evidence-review.json')];
 }else if(d.path.startsWith('scripts/')){
  rationale=d.path.endsWith('sonar_scan_arguments.js')?'Escaped template literals emit exact former literal environment placeholders; no branch data interpolation into scanner arguments. Scanner scope regressions pass.':d.path.endsWith('run_staging_e2e.js')?'Named TDLib imports retain exported functions; null timer initialized before timeout setup, cleanup still clears handle. Staging contract regressions pass.':d.path.endsWith('export_deepsource_findings.js')?'Payload/identity null initialization preserves validation; total deliberately remains undefined first-page sentinel. Pagination and final re-read tests pass.':'Local explanatory suppression comments preserve existing control-character rejection or undefined first-page sentinel; executable validation unchanged.';
  evidence=[ref('reports/findings-review/final-v4-execution-completion.json')];
 }else if(d.path.startsWith('docs/ui-next/inventory/')){
  rationale='Generated route/capability commitments regenerated after handler review, with route inventory and capability export tests verifying consistency.';evidence=[ref('reports/findings-review/final-v4-execution-completion.json')];
 }else if(d.path==='Dockerfile'){
  rationale='Comment-only suppressions; base digest, Debian snapshot, apt commands and stages unchanged. Wording that explicit pins block security revisions is an imprecise documentation statement, not a runtime change.';
 }else if(['package.json','package-lock.json'].includes(d.path)){
  rationale='Only fast-uri override/locked package updated from3.1.7 to3.1.8 for published vulnerability fix. Frozen installs and both npm audits passed; latest Actions dependency scope scans passed.';
 }else throw Error('Unreviewed path '+d.path);
 evidence.push(ref('reports/findings-review/root-reviewed-source.diff'));
 reviews.push({path:d.path,currentSha256:d.currentSha256,reviewed:true,rationale,evidence});
}
fs.writeFileSync('reports/findings-review/root-source-review.json',JSON.stringify({revision,baseline:base,scope:'root backend/scripts/Python-and-generated-artifact review; frontend and Node tests require separate manifests',reviews},null,2)+'\n');
console.log(JSON.stringify({revision,reviewed:reviews.length}));
