import pathlib,json,ast,copy,subprocess,hashlib,tarfile,re,datetime
root=pathlib.Path.cwd();out=root/'reports/findings-review';r=json.loads((out/'python-evidence-review-observation.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for row in r['changes']:
 p=row['path'];a=ast.parse(subprocess.check_output(['git','show',r['base']+':'+p]));b=ast.parse((root/p).read_bytes());nxt=lambda t:sorted(ast.dump(n,include_attributes=False) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='next')
 row['nextExpressionMultisetPreserved']=nxt(a)==nxt(b)
 checks=[]
 for fn in [n for n in ast.walk(a) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]:
  matches=[n for n in ast.walk(b) if isinstance(n,type(fn)) and n.name==fn.name]
  if len(matches)!=1:continue
  new=matches[0]; bindings={}
  for n in ast.walk(new):
   if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='next':bindings[n.targets[0].id]=n.value
  class Inline(ast.NodeTransformer):
   def visit_Name(self,n):return copy.deepcopy(bindings[n.id]) if isinstance(n.ctx,ast.Load) and n.id in bindings else n
  def assertions(t):return sorted(ast.dump(Inline().visit(copy.deepcopy(n)),include_attributes=False) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr.startswith('assert'))
  checks.append({'function':fn.name,'assertionsEquivalentAfterInliningNextLocals':assertions(fn)==assertions(new)})
 row['assertionEquivalenceChecks']=checks
# exact matrix delta (not a new acceptance claim)
def delta(a,b,p=''):
 if type(a)!=type(b):return [{'path':p,'before':a,'after':b}]
 if isinstance(a,dict):return sum((delta(a.get(k),b.get(k),p+'/'+k) for k in sorted(a.keys()|b.keys())),[])
 if isinstance(a,list) and len(a)==len(b):return sum((delta(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [{'path':p,'before':a,'after':b}]
r['matrixExactDelta']=delta(r.pop('matrixBefore'),r.pop('matrixAfter'))
r['allMatrixReferencesMatch']=all(x['declared']==x['actual'] for x in r['matrixEvidence'])
for name in ['python-current-state.log','test_candidate_review_policy.log']:
 data=(out/name).read_bytes();text=data.decode('utf-8-sig');r['tests'].append({'log':'reports/findings-review/'+name,'sha256':sha(data),'summary':re.findall(r'Ran \d+ tests?[^\r\n]*',text),'result':'OK' if text.rstrip().endswith('OK') else 'INSPECT'})
r['testScope']='Fresh targeted 128 tests across all nine changed suites plus 3 candidate review policy tests; no fresh full Python/Node/frontend/provider suite claim.'
build=json.loads((out/'python-evidence-current-build-inputs.json').read_text());receipt=json.loads((root/'exchange_executor/certifications/hyperliquid.json').read_text());r['buildCommitmentDrift']={k:{'receipt':receipt[k],'actual':build[k],'match':receipt[k]==build[k]} for k in ['sourceTreeHash','nodeSourcesHash','testSourcesHash','fixturesHash']}
archive=root/'exchange_executor/certifications/reviews/fixer-1fd38d6a-evidence.tar.gz';member='next/reports/security-services/fixer-1fd38d6a-parity-supplement.json'
with tarfile.open(archive) as t: pdata=t.extractfile(member).read(); parity=json.loads(pdata)
witnesses=[]
for row in parity['rows']:
 for w in row['witnessBindings']:
  actual=sha((root/w['path']).read_bytes());witnesses.append({'category':row['category'],'check':row['check'],'path':w['path'],'receiptWitnessSha256':w['sha256'],'currentSha256':actual,'unchanged':actual==w['sha256']})
r['parityWitnessComparison']={'archive':str(archive.relative_to(root)).replace('\\','/'),'archiveSha256':sha(archive.read_bytes()),'member':member,'memberSha256':sha(pdata),'requirementRows':len(parity['rows']),'referenceCount':len(witnesses),'changedReferences':sum(not w['unchanged'] for w in witnesses),'changedPaths':sorted({w['path'] for w in witnesses if not w['unchanged']}),'bindings':witnesses,'qualification':'Byte comparison only. No renewed requirement coverage assertion.'}
r['issues']=[{'priority':'P1','path':'exchange_executor/ccxt_candidate_reviews.py','line':22,'finding':'Changed candidate assessment pin changes executable executor-tree commitment; operative Hyperliquid receipt and its authority pin remain bound to prior source. Actual certification_result fails closed with Implementation executor source drifted. All four Node complete-input commitments also differ.','requiredAction':'Renew offline implementation evidence against final frozen reviewed inputs, retain exact existing exchange/scope and providerAcceptanceVerified=false, independently review new receipt before updating authority pin, then run actual production gate. Do not merely replace hashes.'},{'priority':'P3','path':'Dockerfile','line':7,'finding':'Snapshot-based apt determinism rationale is appropriate with fixed base digest, architecture and build args; explicit package pins would block snapshot security revisions is overstated. The snapshot timestamp itself must be updated for newer security packages; explicit pins can be updated together.','requiredAction':'Use factual comment: package candidates derive from pinned base and dated Debian snapshot; security updates require a reviewed snapshot bump. Same correction at line30.','primarySource':'https://snapshot.debian.org/'}]
r['renewalRequirements']=['Freeze final reviewed source and collect actual complete-source/runtime commitments before/after verification; identify all differences from receipt baseline, not only this Python diff.','Revalidate the 62 requirement rows and their 97 witnesses; review changed witness semantics individually. This report covers changed Python next-call assertions; other source/test changes belong to root review.','Run fresh offline full Python suite because executable executor-tree input and nine Python test files changed; preserve raw terminal logs and exact locked Python3.12/CCXT4.5.75 runtime binding. This targeted 131-test result is not a substitute for full-suite receipt claims.','Run required current Node/frontend build/tests against final inputs; inherit old results only where complete relevant input/runtime equality is demonstrable. No provider live run or scope expansion is required for the offline receipt.','Build and independently review complete-source/parity/execution evidence, deterministic archive and receipt; then explicitly update exact authority pin and run actual production verification gate. Existing stale evidence must not be described as freshly executed.']
r['reviewConclusion']='Python assertion changes preserve successful contracts and fail closed on missing fixtures; 103 candidate assessments and all referenced hashes verify with exactly one Bybit evidence hash changed and no decision/scope changes. Merge readiness remains blocked by stale implementation receipt. No operative files modified.'
(out/'python-evidence-review.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
print('next',all(x['nextExpressionMultisetPreserved'] for x in r['changes']),'assertions',all(c['assertionsEquivalentAfterInliningNextLocals'] for x in r['changes'] for c in x['assertionEquivalenceChecks']));print('matrixdelta',json.dumps(r['matrixExactDelta'],ensure_ascii=True));print('witness',r['parityWitnessComparison']['changedReferences'],r['parityWitnessComparison']['changedPaths']);print('reportSHA',sha((out/'python-evidence-review.json').read_bytes()))

