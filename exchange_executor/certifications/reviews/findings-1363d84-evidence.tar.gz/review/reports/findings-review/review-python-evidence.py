import pathlib, subprocess, sys, json, hashlib, datetime, ast
root=pathlib.Path.cwd(); out=root/'reports/findings-review'; sys.path.insert(0,str(root/'exchange_executor'))
import ccxt
from ccxt_candidate_reviews import _approved_assessments, _digest
from ccxt_certification import certification_result
from ccxt_certification_evidence import python_tree_hash
from ccxt_profiles import PROFILES
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=root)
base='486d175d2ed7a92783edac0882aa9a902bbc1450'
changed=git('diff','--name-only',base,'HEAD','--','exchange_executor').decode().splitlines()
rows=[]
for f in changed:
 old=git('show',base+':'+f); new=(root/f).read_bytes(); gb=git('show','HEAD:'+f)
 row={'path':f,'beforeSha256':sha(old),'currentSha256':sha(new),'rawEqualsGit':new==gb,'nlink':(root/f).stat().st_nlink}
 if f.endswith('.py'):
  a,b=ast.parse(old),ast.parse(new)
  nxt=lambda t:[ast.dump(x,include_attributes=False) for x in ast.walk(t) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='next']
  row['nextCallsBefore']=len(nxt(a));row['nextCallsAfter']=len(nxt(b));row['nextExpressionsPreserved']=nxt(a)==nxt(b)
  asserts=lambda t:[x for x in ast.walk(t) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr.startswith('assert')]
  row['assertionCallsBefore']=len(asserts(a));row['assertionCallsAfter']=len(asserts(b))
 rows.append(row)
m=json.loads((root/'docs/testing/ccxt-expansion-matrix.json').read_text(encoding='utf8'));oldm=json.loads(git('show',base+':docs/testing/ccxt-expansion-matrix.json'))
refs=[{'path':r['path'],'declared':r['sha256'],'actual':sha((root/r['path']).read_bytes())} for a in m['assessments'] for r in a.get('evidence',[])]
receipt=json.loads((root/'exchange_executor/certifications/hyperliquid.json').read_text(encoding='utf8'))
r=certification_result(root/'exchange_executor/certifications','hyperliquid','4.5.75',PROFILES['hyperliquid'])
report={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD').decode().strip(),'base':base,'python':sys.version,'pythonExecutable':sys.executable,'ccxt':ccxt.__version__,'changes':rows,'matrixApprovedCount':len(_approved_assessments(m)),'matrixAssessmentHash':_digest(m['assessments']),'matrixEvidence':refs,'matrixBefore':oldm,'matrixAfter':m,'receiptSha256':sha((root/'exchange_executor/certifications/hyperliquid.json').read_bytes()),'receiptResult':r.__dict__,'executorExpected':receipt['executorTreeHash'],'executorActual':python_tree_hash(root/'exchange_executor'),'sdkExpected':receipt['sdkTreeHash'],'sdkActual':python_tree_hash(pathlib.Path(ccxt.__file__).parent,sdk=True),'tests':[]}
for f in changed:
 if not f.startswith('exchange_executor/tests/') or f.endswith('test_current_state.py'):continue
 p=out/(pathlib.Path(f).stem+'.log')
 with p.open('wb') as log: run=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','exchange_executor/tests','-p',pathlib.Path(f).name,'-v'],stdout=log,stderr=subprocess.STDOUT,cwd=root)
 report['tests'].append({'file':f,'exitCode':run.returncode,'log':str(p.relative_to(root)).replace('\\','/'),'sha256':sha(p.read_bytes())})
 print(f,run.returncode,flush=True)
(out/'python-evidence-review-observation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
