"""Bind prior exact reviews and four independently reviewed additions; no adoption."""
from pathlib import Path
import json, hashlib, subprocess, tarfile, copy

R = Path('reports/findings-review')
sha = lambda b: hashlib.sha256(b).hexdigest()
ref = lambda p: {'path': p.as_posix(), 'sha256': sha(p.read_bytes())}
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert revision == '1363d8494d393da90f8c20e520f8c9fd45914015'
archive = Path('exchange_executor/certifications/reviews/findings-0f428ab-evidence.tar.gz')
assert sha(archive.read_bytes()) == 'ab4db2434e8d65b90cd3a7e63af05953372635cae9650a1f9d276ff2796dc56d'
member = 'review/reports/findings-review/final-v6-receipt-source-review.json'
with tarfile.open(archive) as handle:
    raw = handle.extractfile(member).read()
assert sha(raw) == 'e398a5930347e3903bbf02bac267012f2be091bd02529d586becfc5a539cce04'
base = json.loads(raw)
old = {row['path']: row for row in base['reviews']}
assert len(old) == len(base['reviews']) == 312
delta_path = R / 'final-v7-receipt-source-deltas.json'
deltas = json.loads(delta_path.read_bytes())
assert deltas['revision'] == revision and deltas['counts'] == {'inputs': 974, 'changedOrAddedOrRemoved': 316}
review_path = R / 'final-v7-new-frontend-tests-review.json'
review = json.loads(review_path.read_bytes())
node_path = R / 'final-v7-node-independent-review.json'
node = json.loads(node_path.read_bytes())
assert node['revision'] == revision and node['independent'] is True and node['status'] == 'pass' and not node['findings']
assert sha(Path(node['productionPath']).read_bytes()) == node['productionSha256']
assert not review['findings']
new = {row['path']: row for row in review['files']}
assert len(new) == len(review['files']) == 4
assert not set(new) & set(old)
assert set(old) | set(new) == {row['path'] for row in deltas['deltas']}
rows = []
for delta in deltas['deltas']:
    path = delta['path']
    assert sha(Path(path).read_bytes()) == delta['currentSha256']
    if path in old:
        prior = old[path]
        assert prior['reviewed'] is True and prior['currentSha256'] == delta['currentSha256']
        row = copy.deepcopy(prior)
    else:
        inspected = new[path]
        assert delta['status'] == 'added' and delta['beforeSha256'] is None
        assert inspected['sha256'] == delta['currentSha256']
        if path == node['path']:
            assert node['sha256'] == delta['currentSha256']
            rationale = 'Independent root review: ' + ' '.join(node['review'])
            evidence = [ref(node_path), ref(review_path)]
        else:
            assert inspected['status'] == 'pass' and 'independently reviewed' in inspected['authorship']
            rationale = 'Independent scoped semantic review: ' + ' '.join(inspected['assertions'])
            evidence = [ref(review_path)]
        row = {'path': path, 'currentSha256': delta['currentSha256'], 'reviewed': True,
               'rationale': rationale, 'evidence': evidence}
    for binding in row['evidence']:
        assert ref(Path(binding['path'])) == binding
    rows.append(row)
assert len(rows) == 316
result = {'revision': revision, 'deltas': ref(delta_path),
    'method': 'Reuse 312 individually reviewed baseline deltas only after exact current-byte verification; add four independently reviewed frontend tests. Historical review remains sealed at its own archive revision. No inferred semantic approval or operative adoption.',
    'priorSealedReview': {'archive': ref(archive), 'member': member, 'sha256': sha(raw)},
    'supplements': [ref(review_path), ref(node_path)],
    'frontendLintLog': ref(R / 'final-v7-frontend-lint.log'), 'reviews': rows}
destination = R / 'final-v7-receipt-source-review.json'
destination.open('x', encoding='utf-8', newline='\n').write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'manifest': ref(destination), 'reviewRows': len(rows)}))
