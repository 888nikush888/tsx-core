import fs from 'node:fs';
import cp from 'node:child_process';
import crypto from 'node:crypto';
import {collectBuildInputs} from '../../scripts/verify_exchange_implementation.js';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const revision=cp.execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
const inputs=collectBuildInputs(process.cwd());
const batch=cp.execFileSync('git',['cat-file','--batch'],{input:inputs.files.map(x=>`${revision}:${x.path}\n`).join(''),maxBuffer:64*1024*1024});
let position=0;
for(const row of inputs.files){const end=batch.indexOf(10,position);const header=batch.subarray(position,end).toString('utf8');const size=Number(header.split(' ')[2]);if(!Number.isSafeInteger(size))throw Error(header);const blob=batch.subarray(end+1,end+1+size);position=end+2+size;if(sha(blob)!==row.sha256||sha(fs.readFileSync(row.path))!==row.sha256||fs.statSync(row.path).nlink!==1)throw Error(`Input mismatch ${row.path}`);}
const report={observedAt:new Date().toISOString(),revision,inputs,rawEqualsGit:true,allInputsSingleLink:true,node:process.version};
fs.writeFileSync(`reports/findings-review/context-${process.argv[2]??'frozen'}.json`,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({revision,inputCount:inputs.files.length,sourceTreeHash:inputs.sourceTreeHash}));
