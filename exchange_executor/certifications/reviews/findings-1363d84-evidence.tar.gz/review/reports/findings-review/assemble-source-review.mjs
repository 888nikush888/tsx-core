import fs from 'node:fs';
import cp from 'node:child_process';
import crypto from 'node:crypto';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p));
const ref=path=>({path,sha256:sha(fs.readFileSync(path))});
const tag=process.argv[2];if(!/^[a-z0-9-]+$/.test(tag))throw Error('Invalid tag');
const revision=cp.execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
const deltaPath=`reports/findings-review/${tag}-receipt-source-deltas.json`;
const deltas=read(deltaPath);if(deltas.revision!==revision)throw Error('Stale delta');
const rootPath='reports/findings-review/root-source-review.json';
const nodePath='reports/findings-review/independent144-test-review.json';
const frontPath='reports/findings-review/frontend-final-complete-review.json';
const node=read(nodePath),front=read(frontPath);
if(node.unresolvedCoverageRegressions.length||front.unresolvedBlockers.length)throw Error('Unresolved review blockers');
const rows=[...read(rootPath).reviews.map(r=>({...r,evidence:[...r.evidence,ref(rootPath)]})),
 ...node.files.map(r=>({path:r.path,currentSha256:r.reviewedSha256,reviewed:true,rationale:r.rationale,evidence:[ref(nodePath)]})),
 ...front.files.map(r=>({path:r.path,currentSha256:r.currentSha256,reviewed:r.status==='reviewed',rationale:r.rationale,evidence:[ref(frontPath)]}))];
const map=new Map(rows.map(r=>[r.path,r]));if(map.size!==rows.length)throw Error('Duplicate review path');
const reviews=deltas.deltas.map(d=>{
 const r=map.get(d.path);if(!r||!r.reviewed||r.currentSha256!==d.currentSha256||sha(fs.readFileSync(d.path))!==r.currentSha256)throw Error('Missing or stale review '+d.path);
 if(!r.rationale||!r.evidence.length)throw Error('No evidence '+d.path);
 for(const e of r.evidence)if(sha(fs.readFileSync(e.path))!==e.sha256)throw Error('Stale reference '+e.path);
 return r;
});
const result={revision,deltas:ref(deltaPath),method:'Combine individual root, independent frontend and Node-test reviews only after exact current hash verification. Earlier reviews retain their actual revision; unchanged bytes are verified here.',reviews};
fs.writeFileSync('reports/findings-review/current-receipt-source-review.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({revision,deltaCount:reviews.length,reviewCount:rows.length}));
