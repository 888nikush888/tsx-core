"""Read-only closure check, not source approval or receipt adoption.

Usage: locked-python -B this.py reports/findings-review/final-v5-receipt-candidate-state.json
Historical archive members are sealed inheritance leaves, not interpreted as
current filesystem JSON. Output inventories exact files a new archive must carry
and historical archives that must remain available by their committed hashes.
"""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path.cwd().resolve()
sha = lambda data: hashlib.sha256(data).hexdigest()
files = {}
historical = {}
seen_reports = set()

def local(path):
    value = (ROOT / path).resolve()
    assert value.is_relative_to(ROOT), f'Reference escapes workspace: {path}'
    return value

def binding(value):
    if 'archive' in value:
        archive = value['archive']
        path = local(archive['path'])
        assert sha(path.read_bytes()) == archive['sha256'], path
        with tarfile.open(path) as handle:
            member = handle.getmember(value['member'])
            assert member.isfile() and not member.issym() and not member.islnk()
            raw = handle.extractfile(member).read()
        assert sha(raw) == value['sha256'], value['member']
        key = archive['path'] + '::' + value['member']
        historical[key] = value
        return
    path = local(value['path'])
    raw = path.read_bytes()
    assert sha(raw) == value['sha256'], path
    key = path.relative_to(ROOT).as_posix()
    if key in files:
        assert files[key] == value['sha256'], f'Conflicting commitments: {key}'
    files[key] = value['sha256']
    if key.startswith('reports/') and path.suffix == '.json' and key not in seen_reports:
        seen_reports.add(key)
        walk(json.loads(raw))

def walk(value):
    if isinstance(value, list):
        for item in value:
            walk(item)
    elif isinstance(value, dict):
        if 'sha256' in value and ('path' in value or 'archive' in value and 'member' in value):
            binding(value)
            # Other witness metadata may contain review/execution references.
            for key, item in value.items():
                if key not in ('archive', 'member', 'path', 'sha256'):
                    walk(item)
            return
        for item in value.values():
            walk(item)

state_path = local(sys.argv[1])
binding({'path': state_path.relative_to(ROOT).as_posix(), 'sha256': sha(state_path.read_bytes())})
print(json.dumps({'kind': 'current-reference-closure-with-sealed-historical-inheritance',
    'currentFiles': [{'path': path, 'sha256': digest} for path, digest in sorted(files.items())],
    'historicalLeaves': list(historical.values()), 'unresolvedReferences': 0,
    'historicalNestedReferencesReinterpretedAsCurrent': False,
    'sourceSemanticsApproved': False, 'operativeReceiptApproved': False,
    'remaining': 'This validates bindings only. Deterministic archive still must include every current file, preserve external historical archive commitments, and be built twice then re-read.'}, indent=2))
