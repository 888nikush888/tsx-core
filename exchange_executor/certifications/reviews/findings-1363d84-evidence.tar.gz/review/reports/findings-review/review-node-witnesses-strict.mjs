import fs from 'node:fs';
import cp from 'node:child_process';
import crypto from 'node:crypto';
import ts from '../../node_modules/typescript/lib/typescript.js';
const base = '486d175d2ed7a92783edac0882aa9a902bbc1450';
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const evidence = JSON.parse(fs.readFileSync('reports/findings-review/python-evidence-review.json'));
const paths = evidence.parityWitnessComparison.changedPaths.filter(path => path.endsWith('.js'));
const printer = ts.createPrinter({ removeComments: true });
function assertions(source, path) {
  const ast = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  const found = [];
  function walk(node) {
    if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression)
      && node.expression.expression.getText(ast) === 'assert') {
      found.push(printer.printNode(ts.EmitHint.Unspecified, node, ast));
    }
    ts.forEachChild(node, walk);
  }
  walk(ast);
  return found;
}
const result = paths.map(path => {
  const oldBytes = cp.execFileSync('git', ['show', `${base}:${path}`]);
  const currentBytes = fs.readFileSync(path);
  const old = assertions(oldBytes.toString('utf8'), path);
  const current = assertions(currentBytes.toString('utf8'), path);
  const remaining = [...current];
  const missing = [];
  for (const assertion of old) {
    const index = remaining.indexOf(assertion);
    if (index < 0) missing.push(assertion);
    else remaining.splice(index, 1);
  }
  return { path, base, previousSha256: sha(oldBytes), currentSha256: sha(currentBytes),
    previousAssertions: old.length, currentAssertions: current.length, missing, added: remaining,
    normalization: 'Formatting/comments only; async callbacks are not normalized.' };
});
if (!process.argv[2]) throw Error('Explicit output path required');
fs.writeFileSync(process.argv[2], JSON.stringify(result, null, 2) + '\n');
